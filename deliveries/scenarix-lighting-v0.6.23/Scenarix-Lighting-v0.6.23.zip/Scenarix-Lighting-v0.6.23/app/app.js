(function (window, document) {
  "use strict";

  const DEFAULT_STAGE_PRESETS = [
    {
      id: "default_mohammed_v",
      source: "default",
      name: "المسرح الوطني محمد الخامس",
      venue: "الرباط",
      width: 12,
      depth: 10,
      bars: 5,
      note: "موديل افتراضي قابل للتعديل حسب المعطيات التقنية الدقيقة للقاعة."
    },
    {
      id: "default_black_box",
      source: "default",
      name: "Black Box / قاعة سوداء",
      venue: "قاعة صغيرة",
      width: 8,
      depth: 8,
      bars: 4,
      note: "فضاء مرن للتجارب والعروض الصغيرة."
    },
    {
      id: "default_small_hall",
      source: "default",
      name: "قاعة صغيرة",
      venue: "قاعة متعددة الاستعمالات",
      width: 7,
      depth: 6,
      bars: 3,
      note: "مناسب للتداريب والعروض المحدودة."
    },
    {
      id: "default_medium_hall",
      source: "default",
      name: "خشبة متوسطة",
      venue: "قاعة متوسطة",
      width: 10,
      depth: 8,
      bars: 4,
      note: "موديل عام للعروض المتوسطة."
    },
    {
      id: "default_open_space",
      source: "default",
      name: "فضاء مفتوح",
      venue: "فضاء خارجي",
      width: 14,
      depth: 10,
      bars: 0,
      note: "بدون بارات ثابتة."
    }
  ];

  const FIXTURE_LIBRARY = [
    { type: "Horiziode 1kW", symbol: "Horiziode", mode: "Conventional", ch: 1, beam: 90, color: "#ffd36a", prefix: "HZ" },
    { type: "Svoboda 10 x 250W", symbol: "Svoboda", mode: "Conventional", ch: 1, beam: 30, color: "#ffd36a", prefix: "SV" },
    { type: "Découpe 1kW", symbol: "Profile", mode: "Conventional", ch: 1, beam: 25, color: "#ffffff", prefix: "D1" },
    { type: "Découpe 2kW", symbol: "Profile", mode: "Conventional", ch: 1, beam: 25, color: "#ffffff", prefix: "D2" },
    { type: "PC 2kW", symbol: "PC", mode: "Conventional", ch: 1, beam: 40, color: "#ffd36a", prefix: "PC2" },
    { type: "PAR 64", symbol: "PAR", mode: "Conventional", ch: 1, beam: 35, color: "#ffd36a", prefix: "P64" },
    { type: "PC 1kW", symbol: "PC", mode: "Conventional", ch: 1, beam: 40, color: "#ffd36a", prefix: "PC" },
    { type: "Fresnel 1kW", symbol: "Fresnel", mode: "Conventional", ch: 1, beam: 50, color: "#ffd36a", prefix: "FR" },
    { type: "Découpe 750W", symbol: "Profile", mode: "Conventional", ch: 1, beam: 25, color: "#ffffff", prefix: "DC" },
    { type: "PAR 64 CP62", symbol: "PAR", mode: "Conventional", ch: 1, beam: 35, color: "#ffd36a", prefix: "P" },
    { type: "Cycliode", symbol: "Flood", mode: "Conventional", ch: 1, beam: 80, color: "#8ecbff", prefix: "CY" },
    { type: "Poursuite", symbol: "Followspot", mode: "Manual", ch: 1, beam: 18, color: "#ffffff", prefix: "PO" },
    { type: "PAR LED RGBW", symbol: "LED PAR", mode: "RGBW 4ch", ch: 4, beam: 40, color: "#7aa2f7", prefix: "PL" },
    { type: "LED Bar RGB", symbol: "LED Bar", mode: "RGB 12ch", ch: 12, beam: 80, color: "#b48cff", prefix: "LB" },
    { type: "Moving Head Spot", symbol: "Moving Spot", mode: "Spot 16ch", ch: 16, beam: 18, color: "#ffffff", prefix: "MHS" },
    { type: "Moving Head Wash", symbol: "Moving Wash", mode: "Wash 14ch", ch: 14, beam: 55, color: "#8ecbff", prefix: "MHW" },
    { type: "Beam 7R", symbol: "Beam", mode: "Beam 16ch", ch: 16, beam: 10, color: "#ffffff", prefix: "BM" },
    { type: "Strobe LED", symbol: "Strobe", mode: "Strobe 6ch", ch: 6, beam: 75, color: "#ffffff", prefix: "ST" },
    { type: "Vidéo-projecteur", symbol: "Video", mode: "Video", ch: 0, beam: 30, color: "#9be7b2", prefix: "VP" }
  ];

  const SCENIC_LIBRARY = [
    { type: "Chair", label: "كرسي", w: 0.8, h: 0.8, color: "#7aa2f7" },
    { type: "Table", label: "طاولة", w: 1.6, h: 1, color: "#7aa2f7" },
    { type: "Door", label: "باب", w: 1, h: 2, color: "#7aa2f7" },
    { type: "Window", label: "نافذة", w: 1.4, h: 1, color: "#7aa2f7" },
    { type: "Screen", label: "شاشة", w: 3, h: 1.8, color: "#7aa2f7" },
    { type: "Platform", label: "منصة", w: 2.5, h: 1.5, color: "#7aa2f7" },
    { type: "Actor", label: "ممثل", w: 0.8, h: 1.2, color: "#7aa2f7" },
    { type: "FOHBar", label: "Perche FOH", w: 8, h: 0.18, color: "#9b59b6" },
    { type: "SideTowerJardin", label: "Tour Jardin", w: 0.35, h: 6, color: "#16a6b6" },
    { type: "SideTowerCour", label: "Tour Cour", w: 0.35, h: 6, color: "#16a6b6" },
    { type: "Cyclorama", label: "Cyclorama", w: 8, h: 0.18, color: "#9b59b6" },
    { type: "Zone", label: "منطقة لعب", w: 3, h: 2, color: "#d8b45b", kind: "zone" }
  ];

  const state = {
    projectInfo: {
      designer: "",
      title: "",
      company: "",
      director: "",
      scenographer: "",
      year: "",
      venue: ""
    },
    stage: {
      width: 12,
      depth: 10,
      bars: 5
    },
    layers: {
      grid: true,
      stage: true,
      bars: true,
      beams: true,
      labels: true,
      scenography: true,
      zones: true,
      drawing: true
    },
    ui: {
      symbolStyle: "technical",
      showFixtureBadges: true,
      snapToBars: true,
      refShowActors: true,
      refShowScenography: true,
      refShowMovement: true,
      refShowTargets: true,
      refOpacity: 0.55
    },
    controlBoard: {fixtureIds:null,groups:[]},
    initialFixtures: null,
    ambientLight: 20,
    fixtures: [],
    scenicItems: [],
    drawings: [],
    cues: [],
    directionPaths: [],
    lightingTargets: [],
    selection: {
      kind: null,
      id: null
    }
  };

  const canvas = {
    viewW: 1500,
    viewH: 860,
    marginX: 28,
    marginY: 34,
    scale: 50,
    scaleX: 50,
    scaleY: 50,
    x0: 80,
    y0: 70,
    stageW: 600,
    stageD: 500
  };

  let svg;
  let gridLayer;
  let stageLayer;
  let barLayer;
  let zoneLayer;
  let scenicLayer;
  let directionMovementLayer;
  let lightingTargetLayer;
  let drawingLayer;
  let beamLayer;
  let fixtureLayer;
  let labelLayer;
  let draggingObject = null;
  let draggingTargetFixture = null;
  let draggingDrawing = null;
  let dragOffset = { x: 0, y: 0 };
  let currentTool = "select";
  let drawingDraft = null;

  document.addEventListener("DOMContentLoaded", init);

  async function init() {
    await window.LightingReference?.ready;
    svg = $("#plot");
    gridLayer = $("#gridLayer");
    stageLayer = $("#stageLayer");
    barLayer = $("#barLayer");
    zoneLayer = $("#zoneLayer");
    scenicLayer = $("#scenicLayer");
    directionMovementLayer = $("directionMovementLayer");
    lightingTargetLayer = $("lightingTargetLayer");
    drawingLayer = $("#drawingLayer");
    beamLayer = $("#beamLayer");
    fixtureLayer = $("#fixtureLayer");
    labelLayer = $("#labelLayer");

    buildLibraries();
    buildStagePresetSelect();
    bindStagePresetControls();
    bindProjectScreen();
    bindStageControls();
    bindLayerControls();
    bindDirectionReferenceControls();
    bindSymbolControls();
    bindLibraryDrag();
    bindDrawingTools();
    bindWorkspaceEvents();
    bindTopActions();
    bindPropertyEvents();
    bindCueEvents();

    applyDirectionContext();
    updateProjectPreview();
    renderAll();
    window.dispatchEvent(new Event("lighting:ready"));

    window.addEventListener("beforeunload", saveLightingSceneToBridge);
    const backBtn = $("prevusceneHubButton");
    if (backBtn) backBtn.addEventListener("click", function(){ saveLightingSceneToBridge(); });
  }

  function buildLibraries() {
    const fixtureLibrary = $("#fixtureLibrary");
    fixtureLibrary.innerHTML = "";

    FIXTURE_LIBRARY.forEach(function (item) {
      const el = document.createElement("div");
      el.className = "library-item";
      el.draggable = true;
      el.dataset.kind = "fixture";
      el.dataset.type = item.type;
      el.innerHTML = item.symbol + "<small>" + item.ch + " DMX / " + item.mode + "</small>";
      const icon=svgEl("svg",{viewBox:"-42 -38 84 76",class:"library-fixture-icon","aria-hidden":"true"});icon.appendChild(technicalFixtureBody({type:item.type,color:item.color,mounting:"suspended"}));
      el.replaceChildren(icon);const caption=document.createElement("span");caption.textContent=item.type;el.append(caption);
      fixtureLibrary.appendChild(el);
    });

    const scenicLibrary = $("#scenicLibrary");
    scenicLibrary.innerHTML = "";

    SCENIC_LIBRARY.forEach(function (item) {
      const el = document.createElement("div");
      el.className = "library-item";
      el.draggable = true;
      el.dataset.kind = item.kind || "scenic";
      el.dataset.type = item.type;
      el.textContent = item.label;
      scenicLibrary.appendChild(el);
    });
  }

  function getUserStagePresets() {
    try {
      return JSON.parse(localStorage.getItem("scenarixLighting.stagePresets.v1") || "[]");
    } catch (error) {
      return [];
    }
  }

  function setUserStagePresets(items) {
    localStorage.setItem("scenarixLighting.stagePresets.v1", JSON.stringify(items));
  }

  function allStagePresets() {
    return DEFAULT_STAGE_PRESETS.concat(getUserStagePresets());
  }

  function buildStagePresetSelect() {
    const select = $("#stagePresetSelect");
    if (!select) return;

    select.innerHTML = "";

    const defaultsGroup = document.createElement("optgroup");
    defaultsGroup.label = "نماذج افتراضية";
    DEFAULT_STAGE_PRESETS.forEach(function (preset) {
      defaultsGroup.appendChild(stagePresetOption(preset));
    });
    select.appendChild(defaultsGroup);

    const userGroup = document.createElement("optgroup");
    userGroup.label = "نماذجي المحفوظة";

    const userPresets = getUserStagePresets();
    if (userPresets.length === 0) {
      const opt = document.createElement("option");
      opt.textContent = "لا توجد نماذج محفوظة بعد";
      opt.value = "";
      opt.disabled = true;
      userGroup.appendChild(opt);
    } else {
      userPresets.forEach(function (preset) {
        userGroup.appendChild(stagePresetOption(preset));
      });
    }

    select.appendChild(userGroup);
  }

  function stagePresetOption(preset) {
    const opt = document.createElement("option");
    opt.value = preset.id;
    opt.textContent = preset.name + " — " + preset.width + "m × " + preset.depth + "m — " + preset.bars + " barres";
    return opt;
  }

  function bindStagePresetControls() {
    const applyBtn = $("#applyStagePresetBtn");
    const saveBtn = $("#saveStagePresetBtn");
    const deleteBtn = $("#deleteStagePresetBtn");

    if (applyBtn) applyBtn.addEventListener("click", applySelectedStagePreset);
    if (saveBtn) saveBtn.addEventListener("click", saveCurrentStagePreset);
    if (deleteBtn) deleteBtn.addEventListener("click", deleteSelectedStagePreset);
  }

  function applySelectedStagePreset() {
    const id = valueOf("stagePresetSelect");
    if (!id) return;

    const preset = allStagePresets().find(function (item) {
      return item.id === id;
    });

    if (!preset) return;

    state.stage.width = Number(preset.width) || 12;
    state.stage.depth = Number(preset.depth) || 10;
    state.stage.bars = Math.max(0, Math.round(Number(preset.bars) || 0));

    setValue("stageWidthInput", state.stage.width);
    setValue("stageDepthInput", state.stage.depth);
    setValue("barsCountInput", state.stage.bars);

    if (preset.venue && !state.projectInfo.venue) {
      state.projectInfo.venue = preset.venue;
      setValue("venueName", preset.venue);
    }

    renderAll();
  }

  function saveCurrentStagePreset() {
    const name = valueOf("stagePresetNameInput");
    if (!name) {
      alert("أدخل اسما للموديل قبل الحفظ.");
      return;
    }

    state.stage.width = numberOf("stageWidthInput", state.stage.width || 12);
    state.stage.depth = numberOf("stageDepthInput", state.stage.depth || 10);
    state.stage.bars = Math.max(0, Math.round(numberOf("barsCountInput", state.stage.bars || 0)));

    const item = {
      id: "user_stage_" + Date.now(),
      source: "user",
      name: name,
      venue: valueOf("venueName") || state.projectInfo.venue || "",
      width: state.stage.width,
      depth: state.stage.depth,
      bars: state.stage.bars,
      note: "موديل محفوظ من طرف المستخدم."
    };

    const items = getUserStagePresets();
    items.push(item);
    setUserStagePresets(items);

    setValue("stagePresetNameInput", "");
    buildStagePresetSelect();
    setValue("stagePresetSelect", item.id);

    alert("تم حفظ الخشبة في مكتبتك المحلية.");
  }

  function deleteSelectedStagePreset() {
    const id = valueOf("stagePresetSelect");
    if (!id) return;

    const preset = allStagePresets().find(function (item) {
      return item.id === id;
    });

    if (!preset) return;

    if (preset.source === "default") {
      alert("لا يمكن حذف النماذج الافتراضية. يمكن فقط حذف النماذج التي حفظتها.");
      return;
    }

    if (!confirm("هل تريد حذف هذا الموديل من مكتبتك؟")) return;

    const items = getUserStagePresets().filter(function (item) {
      return item.id !== id;
    });

    setUserStagePresets(items);
    buildStagePresetSelect();
  }


  function bindDrawingTools() {
    document.querySelectorAll(".draw-tool").forEach(function (button) {
      button.addEventListener("click", function () {
        currentTool = button.dataset.tool || "select";
        document.querySelectorAll(".draw-tool").forEach(function (b) {
          b.classList.remove("active");
        });
        button.classList.add("active");
      });
    });

    const nineZonesBtn = $("#addNineZonesBtn");
    if (nineZonesBtn) nineZonesBtn.addEventListener("click", addNineZonesDrawing);

    const clearBtn = $("#clearDrawingsBtn");
    if (clearBtn) clearBtn.addEventListener("click", function () {
      if (!confirm("هل تريد مسح كل الرسوم والتعليقات دون حذف الأجهزة؟")) return;
      state.drawings = [];
      if (state.selection.kind === "drawing") {
        state.selection = { kind: null, id: null };
      }
      updatePropertiesPanel();
      renderAll();
    });
  }

  function addNineZonesDrawing() {
    const labels = [
      ["Fond Jardin", "Fond Centre", "Fond Cour"],
      ["Milieu Jardin", "Milieu Centre", "Milieu Cour"],
      ["Avant Jardin", "Avant Centre", "Avant Cour"]
    ];

    const colorV = "#2f80ed";
    const colorH1 = "#e25555";
    const colorH2 = "#2ba84a";

    addDrawingObject({
      type: "line",
      x1: state.stage.width / 3,
      y1: 0,
      x2: state.stage.width / 3,
      y2: state.stage.depth,
      color: colorV,
      strokeWidth: 1.5,
      dashed: true,
      note: "تقسيم عمودي"
    });

    addDrawingObject({
      type: "line",
      x1: (state.stage.width / 3) * 2,
      y1: 0,
      x2: (state.stage.width / 3) * 2,
      y2: state.stage.depth,
      color: "#ff8c1a",
      strokeWidth: 1.5,
      dashed: true,
      note: "تقسيم عمودي"
    });

    addDrawingObject({
      type: "line",
      x1: 0,
      y1: state.stage.depth / 3,
      x2: state.stage.width,
      y2: state.stage.depth / 3,
      color: colorH1,
      strokeWidth: 1.5,
      dashed: true,
      note: "تقسيم أفقي"
    });

    addDrawingObject({
      type: "line",
      x1: 0,
      y1: (state.stage.depth / 3) * 2,
      x2: state.stage.width,
      y2: (state.stage.depth / 3) * 2,
      color: colorH2,
      strokeWidth: 1.5,
      dashed: true,
      note: "تقسيم أفقي"
    });

    for (let row = 0; row < 3; row += 1) {
      for (let col = 0; col < 3; col += 1) {
        addDrawingObject({
          type: "text",
          x: (col + 0.5) * state.stage.width / 3,
          y: (row + 0.5) * state.stage.depth / 3,
          text: labels[row][col],
          color: "#111827",
          fill: "#ffffff",
          opacity: 0,
          strokeWidth: 1,
          fontSize: 18,
          dashed: false,
          note: "اسم منطقة لعب"
        });
      }
    }

    renderAll();
  }

  function addDrawingObject(object) {
    const base = {
      id: uid("dr"),
      type: object.type || "line",
      color: object.color || "#111827",
      fill: object.fill || "#ffffff",
      opacity: object.opacity ?? 0.18,
      strokeWidth: object.strokeWidth || 2,
      dashed: !!object.dashed,
      fontSize: object.fontSize || 18,
      text: object.text || "",
      note: object.note || ""
    };

    state.drawings.push(Object.assign(base, object));
  }

  function beginDrawing(event) {
    const start = clientToStageMeters(event.clientX, event.clientY);
    if (!start) return;

    if (currentTool === "text") {
      const text = prompt("اكتب النص الذي تريد إضافته:");
      if (!text) return;

      const object = {
        type: "text",
        x: start.x,
        y: start.y,
        text: text,
        color: "#111827",
        fill: "#ffffff",
        opacity: 0,
        strokeWidth: 1,
        fontSize: 18,
        dashed: false,
        note: ""
      };

      addDrawingObject(object);
      const created = state.drawings[state.drawings.length - 1];
      selectObject("drawing", created.id);
      currentTool = "select";
      activateSelectToolButton();
      return;
    }

    drawingDraft = {
      id: uid("dr"),
      type: currentTool,
      x1: start.x,
      y1: start.y,
      x2: start.x,
      y2: start.y,
      color: "#111827",
      fill: "#ffffff",
      opacity: 0.12,
      strokeWidth: 2,
      dashed: false,
      fontSize: 18,
      text: "",
      note: ""
    };

    state.drawings.push(drawingDraft);
    state.selection = { kind: "drawing", id: drawingDraft.id };
    renderAll();
  }

  function updateDrawingDraft(event) {
    if (!drawingDraft) return;

    const pos = clientToStageMeters(event.clientX, event.clientY);
    if (!pos) return;

    drawingDraft.x2 = pos.x;
    drawingDraft.y2 = pos.y;

    renderAll();
  }

  function endDrawingDraft() {
    if (!drawingDraft) return;

    normalizeDrawingObject(drawingDraft);
    drawingDraft = null;
    currentTool = "select";
    activateSelectToolButton();
    updatePropertiesPanel();
    renderAll();
  }

  function normalizeDrawingObject(object) {
    if (object.type === "rect" || object.type === "circle") {
      const x = Math.min(object.x1, object.x2);
      const y = Math.min(object.y1, object.y2);
      const width = Math.abs(object.x2 - object.x1);
      const height = Math.abs(object.y2 - object.y1);

      object.x = x;
      object.y = y;
      object.width = Math.max(0.1, width);
      object.height = Math.max(0.1, height);

      delete object.x1;
      delete object.y1;
      delete object.x2;
      delete object.y2;
    }
  }

  function activateSelectToolButton() {
    document.querySelectorAll(".draw-tool").forEach(function (button) {
      button.classList.toggle("active", button.dataset.tool === "select");
    });
  }

  function renderDrawings() {
    state.drawings.forEach(function (object) {
      const g = svgEl("g", {
        class: "drawing-object",
        "data-id": object.id
      });

      const selected = state.selection.kind === "drawing" && state.selection.id === object.id;

      if (object.type === "line" || object.type === "arrow") {
        const x1 = mx(object.x1);
        const y1 = my(object.y1);
        const x2 = mx(object.x2);
        const y2 = my(object.y2);

        g.appendChild(svgEl("line", {
          x1: x1,
          y1: y1,
          x2: x2,
          y2: y2,
          stroke: object.color,
          "stroke-width": object.strokeWidth,
          "stroke-dasharray": object.dashed ? "8 6" : "",
          "stroke-linecap": "round"
        }));

        if (object.type === "arrow") {
          g.appendChild(arrowHead(x1, y1, x2, y2, object.color, object.strokeWidth));
        }

        if (selected) {
          g.appendChild(selectionBoxFromPoints(x1, y1, x2, y2));
        }
      }

      if (object.type === "rect") {
        const x = mx(object.x);
        const y = my(object.y);
        const w = object.width * canvas.scaleX;
        const h = object.height * canvas.scaleY;

        g.appendChild(svgEl("rect", {
          x: x,
          y: y,
          width: w,
          height: h,
          rx: 3,
          fill: object.fill,
          opacity: object.opacity,
          stroke: object.color,
          "stroke-width": object.strokeWidth,
          "stroke-dasharray": object.dashed ? "8 6" : ""
        }));

        if (selected) {
          g.appendChild(svgEl("rect", {
            class: "selected-ring",
            x: x - 6,
            y: y - 6,
            width: w + 12,
            height: h + 12,
            rx: 6
          }));
        }
      }

      if (object.type === "circle") {
        const x = mx(object.x);
        const y = my(object.y);
        const w = object.width * canvas.scaleX;
        const h = object.height * canvas.scaleY;

        g.appendChild(svgEl("ellipse", {
          cx: x + w / 2,
          cy: y + h / 2,
          rx: w / 2,
          ry: h / 2,
          fill: object.fill,
          opacity: object.opacity,
          stroke: object.color,
          "stroke-width": object.strokeWidth,
          "stroke-dasharray": object.dashed ? "8 6" : ""
        }));

        if (selected) {
          g.appendChild(svgEl("rect", {
            class: "selected-ring",
            x: x - 6,
            y: y - 6,
            width: w + 12,
            height: h + 12,
            rx: 6
          }));
        }
      }

      if (object.type === "text") {
        const x = mx(object.x);
        const y = my(object.y);

        g.appendChild(svgEl("text", {
          x: x,
          y: y,
          "text-anchor": "middle",
          "dominant-baseline": "middle",
          fill: object.color,
          "font-size": object.fontSize,
          "font-family": "Tahoma, Arial, sans-serif",
          "paint-order": "stroke",
          stroke: object.fill || "#ffffff",
          "stroke-width": object.opacity > 0 ? 0 : 3
        }, object.text || "نص"));

        if (selected) {
          g.appendChild(svgEl("rect", {
            class: "selected-ring",
            x: x - 55,
            y: y - object.fontSize,
            width: 110,
            height: object.fontSize * 1.6,
            rx: 6
          }));
        }
      }

      attachDrawingHandlers(g, object);
      drawingLayer.appendChild(g);
    });
  }

  function arrowHead(x1, y1, x2, y2, color, strokeWidth) {
    const angle = Math.atan2(y2 - y1, x2 - x1);
    const size = 10 + Number(strokeWidth || 2) * 1.5;

    const p1x = x2 - size * Math.cos(angle - Math.PI / 6);
    const p1y = y2 - size * Math.sin(angle - Math.PI / 6);
    const p2x = x2 - size * Math.cos(angle + Math.PI / 6);
    const p2y = y2 - size * Math.sin(angle + Math.PI / 6);

    return svgEl("polygon", {
      points: x2 + "," + y2 + " " + p1x + "," + p1y + " " + p2x + "," + p2y,
      fill: color
    });
  }

  function selectionBoxFromPoints(x1, y1, x2, y2) {
    const x = Math.min(x1, x2) - 6;
    const y = Math.min(y1, y2) - 6;
    const w = Math.abs(x2 - x1) + 12;
    const h = Math.abs(y2 - y1) + 12;

    return svgEl("rect", {
      class: "selected-ring",
      x: x,
      y: y,
      width: Math.max(18, w),
      height: Math.max(18, h),
      rx: 6
    });
  }

  function attachDrawingHandlers(g, object) {
    g.addEventListener("pointerdown", function (event) {
      if (currentTool !== "select") return;
      event.stopPropagation();

      selectObject("drawing", object.id);

      const pos = clientToStageMeters(event.clientX, event.clientY);
      if (!pos) return;

      draggingDrawing = object;
      dragOffset = drawingDragOffset(object, pos);
    });
  }

  function drawingDragOffset(object, pos) {
    if (object.type === "line" || object.type === "arrow") {
      return { x: pos.x - object.x1, y: pos.y - object.y1 };
    }

    return { x: pos.x - object.x, y: pos.y - object.y };
  }

  function moveDrawingObject(object, pos) {
    if (object.type === "line" || object.type === "arrow") {
      const dx = pos.x - dragOffset.x - object.x1;
      const dy = pos.y - dragOffset.y - object.y1;

      object.x1 = clamp(object.x1 + dx, 0, state.stage.width);
      object.y1 = clamp(object.y1 + dy, 0, state.stage.depth);
      object.x2 = clamp(object.x2 + dx, 0, state.stage.width);
      object.y2 = clamp(object.y2 + dy, 0, state.stage.depth);
      return;
    }

    object.x = clamp(pos.x - dragOffset.x, 0, state.stage.width);
    object.y = clamp(pos.y - dragOffset.y, 0, state.stage.depth);
  }


  function lightingSceneSnapshot() {
    return {
      controlBoard: JSON.parse(JSON.stringify(state.controlBoard || {fixtureIds:null,groups:[]})),
      fixtures: JSON.parse(JSON.stringify(state.fixtures || [])),
      initialFixtures: state.initialFixtures ? JSON.parse(JSON.stringify(state.initialFixtures)) : null,
      ambientLight: Number(state.ambientLight ?? 20),
      scenicItems: JSON.parse(JSON.stringify((state.scenicItems || []).filter(function(item){ return !item.importedFromDirection; }))),
      drawings: JSON.parse(JSON.stringify(state.drawings || [])),
      cues: JSON.parse(JSON.stringify(state.cues || [])),
      layers: JSON.parse(JSON.stringify(state.layers || {})),
      ui: JSON.parse(JSON.stringify(state.ui || {})),
      bars: Number(state.stage.bars) || 0
    };
  }

  function saveLightingSceneToBridge() {
    const bridge = window.LightingReference;
    if (!bridge) return;
    const ctx = bridge.readContext();
    const sceneId = ctx && ctx.currentScene && ctx.currentScene.id;
    if (!sceneId) return;
    const lightingByScene = Object.assign({}, ctx.lightingByScene || {});
    lightingByScene[sceneId] = lightingSceneSnapshot();
    if(ctx.directionState)ctx.directionState.lightingByScene=lightingByScene;
    bridge.updateContext({ lightingByScene: lightingByScene, directionState:ctx.directionState });
  }

  function applyDirectionContext() {
    const bridge = window.LightingReference;
    if (!bridge) return;
    const ctx = bridge.readContext();
    if (!ctx || !["direction","lighting"].includes(ctx.source) || !ctx.currentScene) return;

    state.projectInfo.title = state.projectInfo.title || (ctx.project && ctx.project.title) || "";
    state.projectInfo.director = state.projectInfo.director || (ctx.project && ctx.project.director) || "";
    state.projectInfo.venue = state.projectInfo.venue || (ctx.project && ctx.project.theatre) || "";
    state.stage.width = Number(ctx.stage && ctx.stage.width) || 10;
    state.stage.depth = Math.max(1, Number(ctx.stage && ctx.stage.depth) || 6);

    state.stage.height=Number(ctx.stage?.height)||4;
    state.fixtures=[];state.scenicItems=[];state.drawings=[];state.cues=[];state.initialFixtures=null;state.ambientLight=20;state.controlBoard={fixtureIds:null,groups:[]};
    const saved = ctx.lightingByScene && ctx.lightingByScene[ctx.currentScene.id];
    if (saved) {
      state.controlBoard=saved.controlBoard||{fixtureIds:null,groups:[]};
      state.initialFixtures=saved.initialFixtures||null;state.ambientLight=Number(saved.ambientLight??20);
      state.fixtures = Array.isArray(saved.fixtures) ? saved.fixtures : [];
      state.scenicItems = Array.isArray(saved.scenicItems) ? saved.scenicItems : [];
      state.drawings = Array.isArray(saved.drawings) ? saved.drawings : [];
      state.cues = Array.isArray(saved.cues) ? saved.cues : [];
      state.layers = Object.assign(state.layers, saved.layers || {});
      state.ui = Object.assign(state.ui || {}, saved.ui || {});
      if (Number.isFinite(Number(saved.bars))) state.stage.bars = Number(saved.bars);
    }

    const technical = (state.scenicItems || []).filter(function(item){ return !item.importedFromDirection; });
    const references = Array.isArray(ctx.references) ? ctx.references.map(function(item){
      return Object.assign({}, item, { referenceLocked: true, importedFromDirection: true, kind: "scenic" });
    }) : [];
    state.scenicItems = technical.concat(references);
    state.directionPaths = Array.isArray(ctx.movementReferences) ? ctx.movementReferences : [];
    state.lightingTargets = Array.isArray(ctx.lightingTargets) ? ctx.lightingTargets : [];

    setValue("showTitle", state.projectInfo.title);
    setValue("directorName", state.projectInfo.director);
    setValue("venueName", state.projectInfo.venue);
    setValue("stageWidthInput", state.stage.width);
    setValue("stageDepthInput", state.stage.depth);

    const projectScreen = $("projectScreen");
    if (projectScreen) projectScreen.classList.add("hidden");
    const bar = $("directionContextBar");
    if (bar) {
      bar.classList.remove("hidden");
      $("directionContextProject").textContent = state.projectInfo.title || "PREVUSCENE";
      $("directionContextScene").textContent = ((ctx.currentScene.actTitle ? ctx.currentScene.actTitle + " — " : "") + (ctx.currentScene.title || "مشهد"));
    }
  }

  function bindDirectionReferenceControls() {
    const pairs=[['refShowActors','refShowActors'],['refShowScenography','refShowScenography'],['refShowMovement','refShowMovement'],['refShowTargets','refShowTargets']];
    pairs.forEach(function(pair){const el=$(pair[0]);if(!el)return;el.checked=state.ui[pair[1]]!==false;el.addEventListener('change',function(){state.ui[pair[1]]=el.checked;renderAll();});});
    const op=$('refOpacity'),out=$('refOpacityValue');
    if(op){op.value=Math.round((Number(state.ui.refOpacity)||.55)*100);if(out)out.textContent=op.value+'%';op.addEventListener('input',function(){state.ui.refOpacity=Math.max(.15,Math.min(1,Number(op.value)/100));if(out)out.textContent=op.value+'%';renderAll();});}
  }

  function bindProjectScreen() {
    $("#startProjectBtn").addEventListener("click", function () {
      readProjectForm();
      $("#projectScreen").classList.add("hidden");
      updateProjectPreview();
      renderAll();
    });

    $("#editProjectBtn").addEventListener("click", function () {
      fillProjectForm();
      $("#projectScreen").classList.remove("hidden");
    });
  }

  function bindStageControls() {
    $("#applyStageBtn").addEventListener("click", function () {
      state.stage.width = numberOf("stageWidthInput", 12);
      state.stage.depth = numberOf("stageDepthInput", 10);
      state.stage.bars = Math.max(0, Math.round(numberOf("barsCountInput", 5)));
      renderAll();
    });
  }

  function bindLayerControls() {
    document.querySelectorAll(".layerToggle").forEach(function (input) {
      input.addEventListener("change", function () {
        state.layers[input.dataset.layer] = input.checked;
        renderAll();
      });
    });
  }


  function bindSymbolControls() {
    const styleSelect = $("#symbolStyleSelect");
    const badgesInput = $("#showFixtureBadgesInput");
    const snapInput = $("#snapToBarsInput");

    if (styleSelect) {
      styleSelect.value = state.ui.symbolStyle;
      styleSelect.addEventListener("change", function () {
        state.ui.symbolStyle = styleSelect.value;
        renderAll();
      });
    }

    if (badgesInput) {
      badgesInput.checked = !!state.ui.showFixtureBadges;
      badgesInput.addEventListener("change", function () {
        state.ui.showFixtureBadges = badgesInput.checked;
        renderAll();
      });
    }

    if (snapInput) {
      snapInput.checked = !!state.ui.snapToBars;
      snapInput.addEventListener("change", function () {
        state.ui.snapToBars = snapInput.checked;
      });
    }
  }


  function bindLibraryDrag() {
    document.querySelectorAll(".library-item").forEach(function (item) {
      item.addEventListener("dragstart", function (event) {
        event.dataTransfer.setData("application/json", JSON.stringify({
          kind: item.dataset.kind,
          type: item.dataset.type
        }));
        event.dataTransfer.effectAllowed = "copy";
      });
    });

    svg.addEventListener("dragover", function (event) {
      event.preventDefault();
    });

    svg.addEventListener("drop", function (event) {
      event.preventDefault();

      let data = null;
      try {
        data = JSON.parse(event.dataTransfer.getData("application/json"));
      } catch (error) {
        return;
      }

      const pos = clientToStageMeters(event.clientX, event.clientY);
      if (!pos || !data) return;

      if (data.kind === "fixture") {
        addFixture(data.type, pos.x, pos.y);
      } else {
        addScenicItem(data.type, pos.x, pos.y, data.kind === "zone");
      }
    });
  }

  function bindWorkspaceEvents() {
    svg.addEventListener("pointermove", function (event) {
      if (drawingDraft) {
        updateDrawingDraft(event);
        return;
      }

      if (draggingDrawing) {
        const pos = clientToStageMeters(event.clientX, event.clientY);
        if (!pos) return;
        moveDrawingObject(draggingDrawing, pos);
        renderAll();
        return;
      }

      if (draggingTargetFixture) {
        const pos = clientToStageMeters(event.clientX, event.clientY);
        if (!pos) return;
        draggingTargetFixture.targetMode='fixed';draggingTargetFixture.targetObjectId=null;draggingTargetFixture.directionMode='free';
        draggingTargetFixture.targetX = clamp(pos.x, 0, state.stage.width);
        draggingTargetFixture.targetY = clamp(pos.y, 0, state.stage.depth);
        syncFixtureTargetGeometry(draggingTargetFixture);
        renderAll();
        updatePropertiesPanel();
        return;
      }

      if (!draggingObject) return;

      const pos = clientToStageMeters(event.clientX, event.clientY);
      if (!pos) return;

      draggingObject.x = clamp(pos.x - dragOffset.x, 0, state.stage.width);
      draggingObject.y = clamp(pos.y - dragOffset.y, 0, state.stage.depth);

      if (state.fixtures.some(function (fixture) { return fixture.id === draggingObject.id; })) {
        applySnapToBars(draggingObject);
        updateSmartFixturePosition(draggingObject);
      }

      renderAll();
    });

    svg.addEventListener("pointerup", function () {
      endDrawingDraft();
      draggingObject = null;
      draggingTargetFixture = null;
      draggingDrawing = null;
    });

    svg.addEventListener("pointercancel", function () {
      drawingDraft = null;
      draggingObject = null;
      draggingTargetFixture = null;
      draggingDrawing = null;
    });

    svg.addEventListener("pointerdown", function (event) {
      if (currentTool !== "select") {
        beginDrawing(event);
        return;
      }

      if (event.target === svg || event.target.closest("#stageLayer")) {
        clearSelection();
      }
    });
  }

  function bindTopActions() {
    $("#newProjectBtn").addEventListener("click", function () {
      if (!confirm("هل تريد إنشاء مشروع جديد؟")) return;

      state.projectInfo = {
        designer: "",
        title: "",
        company: "",
        director: "",
        scenographer: "",
        year: "",
        venue: ""
      };
      state.stage = { width: 12, depth: 10, bars: 5 };
      state.layers = {
        grid: true,
        stage: true,
        bars: true,
        beams: true,
        labels: true,
        scenography: true,
        zones: true,
        drawing: true
      };
      state.ui = {
        symbolStyle: "technical",
        showFixtureBadges: true,
        snapToBars: true
      };
      state.referenceProject = null;
      state.lightingProjectId = crypto.randomUUID();
      state.fixtures = [];
      state.scenicItems = [];
      state.drawings = [];
      state.cues = [];
      state.controlBoard={fixtureIds:null,groups:[]};
      state.initialFixtures = null;
      state.ambientLight = 20;
      state.directionPaths = [];
      state.lightingTargets = [];
      state.editingCueId = null;
      state.cueBeforeEdit = null;
      window.LightingWorkspace?.detach();
      window.LightControls?.reset();
      window.LightingReference?.clear();
      state.selection = { kind: null, id: null };

      syncControlsFromState();
      $("#projectScreen").classList.remove("hidden");
      renderAll();
    });

    $("#saveLocalBtn").addEventListener("click", function () {
      localStorage.setItem("scenarixLighting.project.v1", JSON.stringify(state));
      alert("تم حفظ المشروع محليا داخل المتصفح.");
    });

    $("#loadLocalBtn").addEventListener("click", function () {
      const raw = localStorage.getItem("scenarixLighting.project.v1");

      if (!raw) {
        alert("لا يوجد حفظ محلي.");
        return;
      }

      loadState(JSON.parse(raw));
    });

    $("#exportJsonBtn").addEventListener("click", exportJson);
    $("#importJsonInput").addEventListener("change", importJson);
    $("#exportPngBtn").addEventListener("click", exportPng);

    $("#printPdfBtn").addEventListener("click", function () {
      updatePrintHeader();
      window.print();
    });

    $("#duplicateObjectBtn").addEventListener("click", duplicateSelectedObject);
    $("#deleteObjectBtn").addEventListener("click", deleteSelectedObject);
    $("#clearSelectionBtn").addEventListener("click", clearSelection);

    $("#autoPatchBtn").addEventListener("click", autoPatch);
    $("#exportPatchCsvBtn").addEventListener("click", exportPatchCsv);

    $("#toggleLeftPanelBtn").addEventListener("click", function () {
      document.body.classList.toggle("left-collapsed");
      document.body.classList.remove("focus-workspace");
    });

    $("#toggleRightPanelBtn").addEventListener("click", function () {
      document.body.classList.toggle("right-collapsed");
      document.body.classList.remove("focus-workspace");
    });

    $("#focusWorkspaceBtn").addEventListener("click", function () {
      document.body.classList.toggle("focus-workspace");
      if (document.body.classList.contains("focus-workspace")) {
        document.body.classList.remove("left-collapsed", "right-collapsed");
      }
    });
  }

  function bindPropertyEvents() {
    [
      "propType", "propLabel", "propMode", "propPosition", "propMounting",
      "propChannel", "propDimmer", "propDmxChannels",
      "propUniverse", "propDmxStart", "propColor", "propGel",
      "propDirectionMode", "propRotation", "propBeamAngle", "propBeamLength",
      "propTargetX", "propTargetY", "propFootprintScale", "propBeamViewMode",
      "propFootprintDiameter", "propFootprintIntensity",
      "propShowBeam", "propShowFootprint", "propNote"
    ].forEach(function (id) {
      const el = $("#" + id);
      if (!el) return;
      el.addEventListener("input", writeSelectedFixtureFromPanel);
      el.addEventListener("change", writeSelectedFixtureFromPanel);
    });

    [
      "scenicPropType", "scenicPropLabel", "scenicPropWidth",
      "scenicPropHeight", "scenicPropRotation", "scenicPropColor",
      "scenicPropNote"
    ].forEach(function (id) {
      const el = $("#" + id);
      if (!el) return;
      el.addEventListener("input", writeSelectedScenicFromPanel);
      el.addEventListener("change", writeSelectedScenicFromPanel);
    });

    [
      "drawPropText", "drawPropColor", "drawPropFill", "drawPropOpacity",
      "drawPropStrokeWidth", "drawPropFontSize", "drawPropDashed", "drawPropNote"
    ].forEach(function (id) {
      const el = $("#" + id);
      if (!el) return;
      el.addEventListener("input", writeSelectedDrawingFromPanel);
      el.addEventListener("change", writeSelectedDrawingFromPanel);
    });
  }

  function bindCueEvents() {
    $("#addCueBtn").addEventListener("click", function () {
      const cue = {
        id: state.editingCueId || uid("cue"),
        start: Math.max(0,Number(valueOf("cueStart"))||0),
        fixtures: JSON.parse(JSON.stringify(state.fixtures)),
        number: valueOf("cueNumber") || String(state.cues.length + 1),
        title: valueOf("cueTitle") || "Cue",
        fadeIn: valueOf("cueFadeIn"),
        fadeOut: valueOf("cueFadeOut"),
        duration: valueOf("cueDuration"),
        note: valueOf("cueNote")
      };

      state.cues=state.cues.filter(c=>c.id!==state.editingCueId);state.editingCueId=null;state.cueBeforeEdit=null;
      state.cues.push(cue);

      ["cueNumber", "cueTitle", "cueFadeIn", "cueFadeOut", "cueDuration", "cueNote"].forEach(function (id) {
        setValue(id, "");
      });

      renderAll();
    });
  }

  function readProjectForm() {
    state.projectInfo.designer = valueOf("designerName");
    state.projectInfo.title = valueOf("showTitle");
    state.projectInfo.company = valueOf("companyName");
    state.projectInfo.director = valueOf("directorName");
    state.projectInfo.scenographer = valueOf("scenographerName");
    state.projectInfo.year = valueOf("productionYear");
    state.projectInfo.venue = valueOf("venueName");
  }

  function fillProjectForm() {
    setValue("designerName", state.projectInfo.designer);
    setValue("showTitle", state.projectInfo.title);
    setValue("companyName", state.projectInfo.company);
    setValue("directorName", state.projectInfo.director);
    setValue("scenographerName", state.projectInfo.scenographer);
    setValue("productionYear", state.projectInfo.year);
    setValue("venueName", state.projectInfo.venue);
  }

  function updateProjectPreview() {
    const title = state.projectInfo.title || "Plan Feu";
    const designer = state.projectInfo.designer || "مصمم الإضاءة غير محدد";
    const company = state.projectInfo.company || "الفرقة غير محددة";
    const year = state.projectInfo.year || "";
    const venue = state.projectInfo.venue || "";

    $("#projectTitlePreview").textContent = title;
    $("#projectMetaPreview").textContent = designer + " — " + company + (venue ? " — " + venue : "") + (year ? " — " + year : "");

    updatePrintHeader();
  }

  function updatePrintHeader() {
    const title = state.projectInfo.title || "Plan Feu";
    const meta = [
      state.projectInfo.designer ? "تصميم الإضاءة: " + state.projectInfo.designer : "",
      state.projectInfo.company ? "الفرقة: " + state.projectInfo.company : "",
      state.projectInfo.director ? "إخراج: " + state.projectInfo.director : "",
      state.projectInfo.scenographer ? "سينوغرافيا: " + state.projectInfo.scenographer : "",
      state.projectInfo.year ? "السنة: " + state.projectInfo.year : "",
      state.projectInfo.venue ? "الفضاء: " + state.projectInfo.venue : ""
    ].filter(Boolean).join(" — ");

    $("#printTitle").textContent = title;
    $("#printMeta").textContent = meta || "معطيات المشروع";
  }

  function addFixture(type, x, y) {
    const lib = FIXTURE_LIBRARY.find(function (item) {
      return item.type === type;
    }) || FIXTURE_LIBRARY[0];

    const count = state.fixtures.length + 1;

    const fixture = {
      id: uid("fx"),
      type: lib.type,
      symbol: lib.symbol,
      mode: lib.mode,
      label: lib.prefix + count,
      position: suggestedPosition(y),
      mounting: valueOf("newFixtureMounting") && valueOf("newFixtureMounting")!=="auto" ? valueOf("newFixtureMounting") : suggestedMounting(y),
      x: clamp(x, 0, state.stage.width),
      y: clamp(y, 0, state.stage.depth),
      rotation: 0,
      color: lib.color,
      gel: "",
      channel: count,
      dimmer: "",
      universe: 1,
      dmxStart: "",
      dmxChannels: lib.ch,
      directionMode: "free",
      beamAngle: lib.beam,
      beamLength: Math.min(7, state.stage.depth),
      targetX: null,
      targetY: null,
      footprintScale: 0.75,
      beamViewMode: "both",
      footprintDiameter: 2,
      footprintIntensity: 65,
      showBeam: true,
      showFootprint: true,
      note: ""
    };

    applySnapToBars(fixture);
    updateSmartFixturePosition(fixture);
    state.fixtures.push(fixture);
    selectObject("fixture", fixture.id);
  }

  function addScenicItem(type, x, y, isZone) {
    const lib = SCENIC_LIBRARY.find(function (item) {
      return item.type === type;
    }) || SCENIC_LIBRARY[0];

    const count = state.scenicItems.length + 1;

    const item = {
      id: uid("sc"),
      kind: isZone ? "zone" : "scenic",
      type: lib.type,
      label: lib.label + " " + count,
      x: clamp(x, 0, state.stage.width),
      y: clamp(y, 0, state.stage.depth),
      width: lib.w,
      height: lib.h,
      rotation: 0,
      color: lib.color,
      note: ""
    };

    state.scenicItems.push(item);
    selectObject(item.kind, item.id);
  }

  function selectObject(kind, id) {
    state.selection = { kind: kind, id: id };
    updatePropertiesPanel();
    renderAll();
  }

  function clearSelection() {
    state.selection = { kind: null, id: null };
    updatePropertiesPanel();
    renderAll();
  }

  function duplicateSelectedObject() {
    const selected = getSelectedObject();
    if (!selected) return;
    if (selected.object && selected.object.referenceLocked) { alert("هذا عنصر مرجعي قادم من تطبيق الإخراج ولا يمكن نسخه هنا."); return; }

    const clone = JSON.parse(JSON.stringify(selected.object));
    clone.id = uid(selected.kind === "fixture" ? "fx" : "sc");
    clone.label = (selected.object.label || selected.object.type) + "_copy";
    clone.x = clamp(clone.x + 0.5, 0, state.stage.width);
    clone.y = clamp(clone.y + 0.5, 0, state.stage.depth);

    if (selected.kind === "fixture") {
      updateSmartFixturePosition(clone);
      state.fixtures.push(clone);
      selectObject("fixture", clone.id);
    } else if (selected.kind === "drawing") {
      offsetDrawingClone(clone);
      state.drawings.push(clone);
      selectObject("drawing", clone.id);
    } else {
      state.scenicItems.push(clone);
      selectObject(clone.kind, clone.id);
    }
  }

  function offsetDrawingClone(object) {
    if (object.type === "line" || object.type === "arrow") {
      object.x1 = clamp(object.x1 + 0.4, 0, state.stage.width);
      object.y1 = clamp(object.y1 + 0.4, 0, state.stage.depth);
      object.x2 = clamp(object.x2 + 0.4, 0, state.stage.width);
      object.y2 = clamp(object.y2 + 0.4, 0, state.stage.depth);
      return;
    }

    object.x = clamp((object.x || 0) + 0.4, 0, state.stage.width);
    object.y = clamp((object.y || 0) + 0.4, 0, state.stage.depth);
  }

  function deleteSelectedObject() {
    if (!state.selection.id) return;
    const selectedNow = getSelectedObject();
    if (selectedNow && selectedNow.object && selectedNow.object.referenceLocked) { alert("هذا عنصر مرجعي قادم من تطبيق الإخراج ولا يمكن حذفه هنا."); return; }

    if (state.selection.kind === "fixture") {
      state.fixtures = state.fixtures.filter(function (item) {
        return item.id !== state.selection.id;
      });
    } else if (state.selection.kind === "drawing") {
      state.drawings = state.drawings.filter(function (item) {
        return item.id !== state.selection.id;
      });
    } else {
      state.scenicItems = state.scenicItems.filter(function (item) {
        return item.id !== state.selection.id;
      });
    }

    clearSelection();
  }

  function getSelectedObject() {
    if (!state.selection.id) return null;

    if (state.selection.kind === "fixture") {
      const fixture = state.fixtures.find(function (item) {
        return item.id === state.selection.id;
      });
      return fixture ? { kind: "fixture", object: fixture } : null;
    }

    if (state.selection.kind === "drawing") {
      const drawing = state.drawings.find(function (item) {
        return item.id === state.selection.id;
      });
      return drawing ? { kind: "drawing", object: drawing } : null;
    }

    const scenic = state.scenicItems.find(function (item) {
      return item.id === state.selection.id;
    });

    return scenic ? { kind: scenic.kind, object: scenic } : null;
  }

  function writeSelectedFixtureFromPanel(event) {
    const changedField=event?.target?.id;
    const selected = getSelectedObject();
    if (!selected || selected.kind !== "fixture") return;

    const f = selected.object;

    f.type = valueOf("propType");
    f.label = valueOf("propLabel");
    f.mode = valueOf("propMode");
    f.position = valueOf("propPosition");
    f.mounting = valueOf("propMounting") || "suspended";
    updateSmartFixturePosition(f);
    f.channel = valueOf("propChannel");
    f.dimmer = valueOf("propDimmer");
    f.dmxChannels = Math.max(0, Number(valueOf("propDmxChannels")) || 0);
    f.universe = Math.max(1, Number(valueOf("propUniverse")) || 1);
    f.dmxStart = valueOf("propDmxStart") ? Math.max(1, Number(valueOf("propDmxStart")) || 1) : "";
    f.color = valueOf("propColor") || "#ffd36a";
    f.gel = valueOf("propGel");
    const oldDirectionMode = f.directionMode || "free";
    const oldRotation = Number(f.rotation) || 0;
    const oldBeamLength = Number(f.beamLength) || 7;
    const oldTargetX = hasTargetNumber(f.targetX) ? Number(f.targetX) : null;
    const oldTargetY = hasTargetNumber(f.targetY) ? Number(f.targetY) : null;

    f.directionMode = valueOf("propDirectionMode") || "free";
    const requestedRotation = Number(valueOf("propRotation"));
    const requestedBeamLength = Number(valueOf("propBeamLength"));
    const requestedTargetX = optionalNumber(valueOf("propTargetX"));
    const requestedTargetY = optionalNumber(valueOf("propTargetY"));

    f.rotation = changedField==="propRotation"&&Number.isFinite(requestedRotation) ? requestedRotation : oldRotation;
    f.beamAngle = Number(valueOf("propBeamAngle")) || 35;
    f.beamLength = changedField==="propBeamLength"&&Number.isFinite(requestedBeamLength) && requestedBeamLength > 0 ? requestedBeamLength : oldBeamLength;
    f.targetX = changedField==="propTargetX"&&requestedTargetX !== null ? clamp(requestedTargetX, 0, state.stage.width) : oldTargetX;
    f.targetY = changedField==="propTargetY"&&requestedTargetY !== null ? clamp(requestedTargetY, 0, state.stage.depth) : oldTargetY;
    f.footprintScale = clamp(Number(valueOf("propFootprintScale")) || f.footprintScale || 0.75, 0.35, 1.5);
    f.footprintDiameter = Math.max(0.3, Number(valueOf("propFootprintDiameter")) || f.footprintDiameter || 2);
    f.footprintIntensity = clamp(Number(valueOf("propFootprintIntensity")) || 0, 0, 100);
    f.intensity=f.footprintIntensity;
    f.showBeam = $("#propShowBeam").checked;
    f.showFootprint = $("#propShowFootprint") ? $("#propShowFootprint").checked : (f.showFootprint !== false);
    f.note = valueOf("propNote");

    const directionChanged = f.directionMode !== oldDirectionMode;
    const rotationChanged = Math.abs(f.rotation - oldRotation) > 0.0001;
    const lengthChanged = Math.abs(f.beamLength - oldBeamLength) > 0.0001;
    const targetChanged = (requestedTargetX !== null && (oldTargetX === null || Math.abs(f.targetX-oldTargetX)>0.0001)) ||
      (requestedTargetY !== null && (oldTargetY === null || Math.abs(f.targetY-oldTargetY)>0.0001));

    if(directionChanged||rotationChanged||lengthChanged||targetChanged){f.targetMode='fixed';f.targetObjectId=null;}
    if (directionChanged) {
      applyDirectionPreset(f);
      initialiseTargetFromBeam(f, true);
    } else if (f.directionMode !== "douche") {
      if (rotationChanged || lengthChanged) initialiseTargetFromBeam(f, true);
      else if (targetChanged) syncFixtureTargetGeometry(f);
    }
    if (f.directionMode === "douche") f.mounting = "suspended";

    setValue("propDmxEnd", dmxEnd(f) || "");
    $("#rotationValue").textContent = (Math.round(f.rotation*10)/10) + "°";
    $("#beamAngleValue").textContent = f.beamAngle + "°";
    $("#beamLengthValue").textContent = f.beamLength + "m";
    $("#footprintDiameterValue").textContent = f.footprintDiameter.toFixed(1) + "m";
    $("#footprintIntensityValue").textContent = Math.round(f.footprintIntensity) + "%";
    setValue("propTargetX",f.targetX);setValue("propTargetY",f.targetY);
    syncFixtureDirectionControls(f);

    renderAll();
  }

  function writeSelectedScenicFromPanel() {
    const selected = getSelectedObject();
    if (!selected || selected.kind === "fixture") return;

    const item = selected.object;
    if (item.referenceLocked) return;
    item.type = valueOf("scenicPropType");
    item.label = valueOf("scenicPropLabel");
    item.width = numberOf("scenicPropWidth", item.width || 1);
    item.height = numberOf("scenicPropHeight", item.height || 1);
    item.rotation = Number(valueOf("scenicPropRotation")) || 0;
    item.color = valueOf("scenicPropColor") || "#7aa2f7";
    item.note = valueOf("scenicPropNote");

    $("#scenicRotationValue").textContent = item.rotation + "°";

    renderAll();
  }


  function writeSelectedDrawingFromPanel() {
    const selected = getSelectedObject();
    if (!selected || selected.kind !== "drawing") return;

    const object = selected.object;
    object.text = valueOf("drawPropText");
    object.color = valueOf("drawPropColor") || "#111827";
    object.fill = valueOf("drawPropFill") || "#ffffff";
    object.opacity = Math.max(0, Math.min(1, Number(valueOf("drawPropOpacity")) || 0));
    object.strokeWidth = Math.max(1, Number(valueOf("drawPropStrokeWidth")) || 2);
    object.fontSize = Math.max(8, Number(valueOf("drawPropFontSize")) || 18);
    object.dashed = $("#drawPropDashed").checked;
    object.note = valueOf("drawPropNote");

    renderAll();
  }


  function updatePropertiesPanel() {
    const selected = getSelectedObject();
    const fixtureBox = $("#fixtureProperties");
    const scenicBox = $("#scenicProperties");
    const drawingBox = $("#drawingProperties");
    const msg = $("#noSelectionMsg");

    fixtureBox.classList.add("hidden");
    scenicBox.classList.add("hidden");
    drawingBox.classList.add("hidden");
    msg.classList.remove("hidden");
    ["scenicPropType","scenicPropLabel","scenicPropWidth","scenicPropHeight","scenicPropRotation","scenicPropColor","scenicPropNote"].forEach(function(id){ const el=$(id); if(el) el.disabled=false; });

    if (!selected) return;

    msg.classList.add("hidden");

    if (selected.kind === "fixture") {
      const f = selected.object;
      fixtureBox.classList.remove("hidden");

      setValue("propType", f.type);
      setValue("propLabel", f.label);
      setValue("propMode", f.mode || "");
      updateSmartFixturePosition(f);
      setValue("propPosition", f.position || "");
      setValue("propSmartPosition", f.smartPosition || "");
      setValue("propSmartCoordinates", f.smartCoordinates || "");
      setValue("propMounting", f.mounting || "suspended");
      setValue("propChannel", f.channel);
      setValue("propDimmer", f.dimmer);
      setValue("propDmxChannels", f.dmxChannels);
      setValue("propUniverse", f.universe || 1);
      setValue("propDmxStart", f.dmxStart);
      setValue("propDmxEnd", dmxEnd(f) || "");
      setValue("propColor", f.color);
      setValue("propGel", f.gel);
      f.directionMode = f.directionMode || "free";
      ensureFixtureTarget(f);
      f.footprintScale = clamp(Number(f.footprintScale) || 0.75, 0.35, 1.5);
      f.beamViewMode = f.beamViewMode || "both";
      f.footprintDiameter = Math.max(0.3, Number(f.footprintDiameter) || 2);
      f.footprintIntensity = clamp(Number(f.intensity ?? f.footprintIntensity ?? 65), 0, 100);
      setValue("propDirectionMode", f.directionMode);
      setValue("propRotation", f.rotation);
      setValue("propBeamAngle", f.beamAngle);
      setValue("propBeamLength", f.beamLength);
      setValue("propTargetX", Number(f.targetX).toFixed(2));
      setValue("propTargetY", Number(f.targetY).toFixed(2));
      setValue("propFootprintScale", f.footprintScale);
      setValue("propBeamViewMode", f.beamViewMode);
      setValue("propFootprintDiameter", f.footprintDiameter);
      setValue("propFootprintIntensity", f.footprintIntensity);
      $("#propShowBeam").checked = f.showBeam !== false;
      if ($("#propShowFootprint")) $("#propShowFootprint").checked = f.showFootprint !== false;
      setValue("propNote", f.note);

      $("#rotationValue").textContent = (Math.round(f.rotation*10)/10) + "°";
      $("#beamAngleValue").textContent = f.beamAngle + "°";
      $("#beamLengthValue").textContent = f.beamLength + "m";
      $("#footprintDiameterValue").textContent = f.footprintDiameter.toFixed(1) + "m";
      $("#footprintIntensityValue").textContent = Math.round(f.footprintIntensity) + "%";
      syncFixtureDirectionControls(f);
    } else if (selected.kind === "drawing") {
      const object = selected.object;
      drawingBox.classList.remove("hidden");

      setValue("drawPropType", object.type);
      setValue("drawPropText", object.text || "");
      setValue("drawPropColor", object.color || "#111827");
      setValue("drawPropFill", object.fill || "#ffffff");
      setValue("drawPropOpacity", object.opacity ?? 0.18);
      setValue("drawPropStrokeWidth", object.strokeWidth || 2);
      setValue("drawPropFontSize", object.fontSize || 18);
      $("#drawPropDashed").checked = !!object.dashed;
      setValue("drawPropNote", object.note || "");
    } else {
      const item = selected.object;
      scenicBox.classList.remove("hidden");

      setValue("scenicPropType", item.type);
      setValue("scenicPropLabel", item.label);
      setValue("scenicPropWidth", item.width);
      setValue("scenicPropHeight", item.height);
      setValue("scenicPropRotation", item.rotation);
      setValue("scenicPropColor", item.color);
      setValue("scenicPropNote", item.note);

      $("#scenicRotationValue").textContent = item.rotation + "°";
    }
  }

  function directionReferenceOpacity(){return Math.max(.15,Math.min(1,Number(state.ui.refOpacity)||.55));}

  function renderDirectionMovements(){
    if(state.ui.refShowMovement===false)return;
    const opacity=directionReferenceOpacity();
    (state.directionPaths||[]).forEach(function(p){
      const x1=mx(p.x1),y1=my(p.y1),x2=mx(p.x2),y2=my(p.y2),dx=x2-x1,dy=y2-y1,len=Math.max(1,Math.hypot(dx,dy)),nx=-dy/len,ny=dx/len;
      const off=(Number(p.curve)||0)*((canvas.scaleX+canvas.scaleY)/2),shape=p.pathShape||'curve';
      let d;
      if(shape==='straight')d='M'+x1+' '+y1+' L'+x2+' '+y2;
      else if(shape==='elbow'){const xm=(x1+x2)/2;d='M'+x1+' '+y1+' L'+xm+' '+y1+' L'+xm+' '+y2+' L'+x2+' '+y2;}
      else if(shape==='sCurve'){const c1x=x1+dx/3+nx*off,c1y=y1+dy/3+ny*off,c2x=x1+2*dx/3-nx*off,c2y=y1+2*dy/3-ny*off;d='M'+x1+' '+y1+' C'+c1x+' '+c1y+' '+c2x+' '+c2y+' '+x2+' '+y2;}
      else {const cx=(x1+x2)/2+nx*off,cy=(y1+y2)/2+ny*off;d='M'+x1+' '+y1+' Q'+cx+' '+cy+' '+x2+' '+y2;}
      directionMovementLayer.appendChild(svgEl('path',{d:d,fill:'none',stroke:p.color||'#c98212','stroke-width':3,'stroke-dasharray':'9 6',opacity:opacity,'pointer-events':'none'}));
      directionMovementLayer.appendChild(svgEl('circle',{cx:x1,cy:y1,r:5,fill:p.color||'#c98212',opacity:opacity,'pointer-events':'none'}));
      directionMovementLayer.appendChild(svgEl('circle',{cx:x2,cy:y2,r:5,fill:p.color||'#c98212',opacity:opacity,'pointer-events':'none'}));
      directionMovementLayer.appendChild(svgEl('text',{x:(x1+x2)/2,y:(y1+y2)/2-8,'text-anchor':'middle',class:'direction-movement-label',opacity:opacity},(p.code||'M')+(p.actorLabel?' · '+p.actorLabel:'')));
    });
  }

  function renderLightingTargets(){
    if(state.ui.refShowTargets===false)return;
    const opacity=directionReferenceOpacity();
    (state.lightingTargets||[]).forEach(function(t){
      const x=mx(t.x),y=my(t.y),r=Math.max(10,(Number(t.radius)||1)*((canvas.scaleX+canvas.scaleY)/2));
      lightingTargetLayer.appendChild(svgEl('circle',{cx:x,cy:y,r:r,fill:t.color||'#ffd76a','fill-opacity':.09*opacity,stroke:t.color||'#ffd76a','stroke-width':3,'stroke-dasharray':'10 6',opacity:opacity,'pointer-events':'none'}));
      lightingTargetLayer.appendChild(svgEl('circle',{cx:x,cy:y,r:4,fill:t.color||'#ffd76a',opacity:opacity,'pointer-events':'none'}));
      lightingTargetLayer.appendChild(svgEl('text',{x:x,y:y-r-8,'text-anchor':'middle',class:'lighting-target-label',opacity:opacity},'◎ '+(t.label||'هدف ضوئي')+' · '+Math.round(Number(t.intensity)||0)+'%'));
    });
  }

  function renderAll() {
    calculateCanvas();
    document.querySelectorAll(".layerToggle").forEach(input=>{
      input.checked=!!state.layers[input.dataset.layer];
    });
    const displayHint=$("#beamDisplayHint");
    if(displayHint) displayHint.hidden=!!state.layers.beams;

    [gridLayer, stageLayer, barLayer, zoneLayer, scenicLayer, directionMovementLayer, lightingTargetLayer, drawingLayer, beamLayer, fixtureLayer, labelLayer].forEach(clear);

    if (state.layers.grid) renderGrid();
    if (state.layers.stage) renderStage();
    if (state.layers.bars) renderBars();
    if (state.layers.zones) renderZones();
    if (state.layers.scenography) renderScenicItems();
    renderDirectionMovements();
    renderLightingTargets();
    if (state.layers.drawing) renderDrawings();
    if (state.layers.beams) renderBeams();

    renderFixtures();

    if (state.layers.labels) renderLabels();

    renderFixtureTable();
    renderPatchTables();
    renderCueTables();
    updatePrintHeader();
    saveLightingSceneToBridge();
    window.dispatchEvent(new Event("lighting:changed"));
  }

  function calculateCanvas() {
    const availableW = canvas.viewW - canvas.marginX * 2;
    const availableH = canvas.viewH - canvas.marginY * 2;

    canvas.scaleX = availableW / state.stage.width;
    canvas.scaleY = availableH / state.stage.depth;
    canvas.scale = Math.min(canvas.scaleX, canvas.scaleY);

    canvas.stageW = state.stage.width * canvas.scaleX;
    canvas.stageD = state.stage.depth * canvas.scaleY;

    canvas.x0 = canvas.marginX;
    canvas.y0 = canvas.marginY;
  }

  function renderGrid() {
    for (let x = 0; x <= state.stage.width; x += 1) {
      const px = mx(x);
      gridLayer.appendChild(svgEl("line", {
        x1: px,
        y1: canvas.y0,
        x2: px,
        y2: canvas.y0 + canvas.stageD,
        stroke: x % 5 === 0 ? "#3b4352" : "#252b35",
        "stroke-width": x % 5 === 0 ? 1.2 : 0.8
      }));
    }

    for (let y = 0; y <= state.stage.depth; y += 1) {
      const py = my(y);
      gridLayer.appendChild(svgEl("line", {
        x1: canvas.x0,
        y1: py,
        x2: canvas.x0 + canvas.stageW,
        y2: py,
        stroke: y % 5 === 0 ? "#3b4352" : "#252b35",
        "stroke-width": y % 5 === 0 ? 1.2 : 0.8
      }));
    }
  }

  function renderStage() {
    stageLayer.appendChild(svgEl("rect", {
      x: canvas.x0,
      y: canvas.y0,
      width: canvas.stageW,
      height: canvas.stageD,
      rx: 10,
      fill: "#f8f6ed",
      stroke: "#111827",
      "stroke-width": 3
    }));

    stageLayer.appendChild(svgEl("text", {
      x: canvas.x0 + canvas.stageW / 2,
      y: canvas.y0 - 12,
      "text-anchor": "middle",
      class: "stage-label"
    }, "عمق الخشبة " + state.stage.depth + "m"));

    stageLayer.appendChild(svgEl("text", {
      x: canvas.x0 + canvas.stageW / 2,
      y: canvas.y0 + canvas.stageD + 24,
      "text-anchor": "middle",
      class: "stage-label"
    }, "الجمهور / مقدمة الخشبة — العرض " + state.stage.width + "m"));
  }

  function renderBars() {
    for (let i = 1; i <= state.stage.bars; i += 1) {
      const yMeters = (state.stage.depth / (state.stage.bars + 1)) * i;
      const y = my(yMeters);

      barLayer.appendChild(svgEl("line", {
        x1: canvas.x0 + 10,
        y1: y,
        x2: canvas.x0 + canvas.stageW - 10,
        y2: y,
        stroke: "#8a5a00",
        "stroke-width": 2.5,
        "stroke-dasharray": "8 5"
      }));

      barLayer.appendChild(svgEl("text", {
        x: canvas.x0 + 18,
        y: y - 6,
        class: "stage-label"
      }, "Perche " + i));
    }
  }

  function renderZones() {
    state.scenicItems.filter(function (item) {
      return item.kind === "zone";
    }).forEach(function (item) {
      const g = svgEl("g", { class: "object-symbol" + (item.referenceLocked ? " reference-locked" : "") });
      const x = mx(item.x);
      const y = my(item.y);
      const w = item.width * canvas.scaleX;
      const h = item.height * canvas.scaleY;
      const selected = state.selection.id === item.id;

      const inner = svgEl("g", { transform: "translate(" + x + " " + y + ") rotate(" + (item.referenceKind==='actor'?0:item.rotation) + ")" });
      inner.appendChild(svgEl("rect", {
        x: -w / 2,
        y: -h / 2,
        width: w,
        height: h,
        rx: 12,
        fill: item.color,
        opacity: 0.22,
        stroke: item.color,
        "stroke-width": 2,
        "stroke-dasharray": "7 5"
      }));

      if (selected) {
        inner.appendChild(svgEl("rect", {
          class: "selected-ring",
          x: -w / 2 - 6,
          y: -h / 2 - 6,
          width: w + 12,
          height: h + 12,
          rx: 15
        }));
      }

      g.appendChild(inner);
      g.appendChild(svgEl("text", {
        x: x,
        y: y + 4,
        "text-anchor": "middle",
        class: "zone-label"
      }, item.label || "Zone"));

      attachDragHandlers(g, item, item.kind);
      zoneLayer.appendChild(g);
    });
  }

  function renderScenicItems() {
    state.scenicItems.filter(function (item) {
      if(item.kind === "zone") return false;
      if(item.importedFromDirection && item.referenceKind==='actor' && state.ui.refShowActors===false) return false;
      if(item.importedFromDirection && item.referenceKind!=='actor' && state.ui.refShowScenography===false) return false;
      return true;
    }).forEach(function (item) {
      const g = svgEl("g", { class: "object-symbol" + (item.referenceLocked ? " reference-locked" : "") });
      if(item.importedFromDirection) g.setAttribute('opacity', directionReferenceOpacity());
      const x = mx(item.x);
      const y = my(item.y);
      const selected = state.selection.id === item.id;

      const inner = svgEl("g", { transform: "translate(" + x + " " + y + ") rotate(" + (item.referenceKind==='actor'?0:item.rotation) + ")" });
      let illustrated=false;
      if(item.referenceKind==='actor'&&item.sourceObject&&window.ActorArtwork){
        const art=svgEl('g',{transform:'scale('+canvas.scaleX/100+' '+canvas.scaleY/100+')',class:'direction-actor-artwork','data-source-id':item.sourceId});
        art.style.setProperty('--shirt-color',item.sourceObject.color||'#168bc2');
        illustrated=ActorArtwork.draw(art,{...item.sourceObject,actorVisual:item.sourceObject.actorVisual||'illustrated'},svgEl);
        if(illustrated)inner.append(art);
      }
      if(!illustrated)drawScenicShape(inner, item);

      if (selected) {
        inner.appendChild(svgEl("rect", {
          class: "selected-ring",
          x: -item.width * canvas.scaleX / 2 - 7,
          y: -item.height * canvas.scaleY / 2 - 7,
          width: item.width * canvas.scaleX + 14,
          height: item.height * canvas.scaleY + 14,
          rx: 10
        }));
      }

      g.appendChild(inner);
      g.appendChild(svgEl("text", {
        x: item.referenceKind==='actor'?x:x + 18,
        y: item.referenceKind==='actor'?y-item.height*canvas.scaleY/2-12:y - 16,
        "text-anchor":item.referenceKind==='actor'?'middle':'start',
        class: "scenic-label"
      }, item.label || item.type));
      if (item.referenceLocked && item.referenceKind!=='actor') g.appendChild(svgEl("text", { x: x + 18, y: y + 1, class: "reference-lock-mark" }, "مرجع الإخراج"));

      attachDragHandlers(g, item, item.kind);
      scenicLayer.appendChild(g);
    });
  }

  function drawScenicShape(parent, item) {
    const w = item.width * canvas.scaleX;
    const h = item.height * canvas.scaleY;
    const c = item.color;
    const t = String(item.type || "").toLowerCase();

    if (t.includes("fohbar")) {
      parent.appendChild(svgEl("line", { x1: -w / 2, y1: 0, x2: w / 2, y2: 0, stroke: c, "stroke-width": 5, "stroke-linecap": "round" }));
      parent.appendChild(svgEl("text", { x: 0, y: -10, "text-anchor": "middle", class: "stage-label" }, "Perche FOH"));
      return;
    }

    if (t.includes("sidetower")) {
      parent.appendChild(svgEl("line", { x1: 0, y1: -h / 2, x2: 0, y2: h / 2, stroke: c, "stroke-width": 5, "stroke-linecap": "round" }));
      for (let yy = -h / 2; yy <= h / 2; yy += Math.max(28, h / 5)) {
        parent.appendChild(svgEl("circle", { cx: 0, cy: yy, r: 5, fill: "#ffffff", stroke: "#111827", "stroke-width": 2 }));
      }
      return;
    }

    if (t.includes("cyclorama")) {
      parent.appendChild(svgEl("line", { x1: -w / 2, y1: 0, x2: w / 2, y2: 0, stroke: c, "stroke-width": 5, "stroke-linecap": "round" }));
      parent.appendChild(svgEl("text", { x: 0, y: -10, "text-anchor": "middle", class: "stage-label" }, "Cyclorama"));
      return;
    }

    if (t.includes("chair")) {
      parent.appendChild(svgEl("rect", { x: -w / 2, y: -h / 2, width: w, height: h, rx: 5, fill: "none", stroke: c, "stroke-width": 3 }));
      parent.appendChild(svgEl("line", { x1: -w / 2, y1: 0, x2: w / 2, y2: 0, stroke: c, "stroke-width": 2 }));
      return;
    }

    if (t.includes("table")) {
      parent.appendChild(svgEl("rect", { x: -w / 2, y: -h / 2, width: w, height: h, rx: 10, fill: c, opacity: 0.25, stroke: c, "stroke-width": 3 }));
      return;
    }

    if (t.includes("door")) {
      parent.appendChild(svgEl("rect", { x: -w / 2, y: -h / 2, width: w, height: h, fill: "none", stroke: c, "stroke-width": 4 }));
      parent.appendChild(svgEl("path", { d: "M " + (-w / 2) + " " + (h / 2) + " Q " + (w / 4) + " " + (h / 3) + " " + (w / 2) + " " + (-h / 2), fill: "none", stroke: c, "stroke-width": 2, "stroke-dasharray": "5 4" }));
      return;
    }

    if (t.includes("window")) {
      parent.appendChild(svgEl("rect", { x: -w / 2, y: -h / 2, width: w, height: h, fill: "none", stroke: c, "stroke-width": 3 }));
      parent.appendChild(svgEl("line", { x1: 0, y1: -h / 2, x2: 0, y2: h / 2, stroke: c, "stroke-width": 2 }));
      parent.appendChild(svgEl("line", { x1: -w / 2, y1: 0, x2: w / 2, y2: 0, stroke: c, "stroke-width": 2 }));
      return;
    }

    if (t.includes("screen")) {
      parent.appendChild(svgEl("rect", { x: -w / 2, y: -h / 2, width: w, height: h, rx: 4, fill: "#111827", stroke: c, "stroke-width": 3 }));
      return;
    }

    if (t.includes("platform")) {
      parent.appendChild(svgEl("polygon", { points: (-w / 2) + "," + (h / 2) + " " + (-w / 2 + 14) + "," + (-h / 2) + " " + (w / 2) + "," + (-h / 2) + " " + (w / 2 - 14) + "," + (h / 2), fill: c, opacity: 0.25, stroke: c, "stroke-width": 3 }));
      return;
    }

    if (t.includes("actor")) {
      parent.appendChild(svgEl("circle", { cx: 0, cy: -h * 0.2, r: Math.min(w, h) * 0.18, fill: c, opacity: 0.9 }));
      parent.appendChild(svgEl("line", { x1: 0, y1: -h * 0.05, x2: 0, y2: h * 0.28, stroke: c, "stroke-width": 4 }));
      parent.appendChild(svgEl("line", { x1: -w * 0.32, y1: h * 0.05, x2: w * 0.32, y2: h * 0.05, stroke: c, "stroke-width": 3 }));
      parent.appendChild(svgEl("line", { x1: 0, y1: h * 0.28, x2: -w * 0.25, y2: h * 0.5, stroke: c, "stroke-width": 3 }));
      parent.appendChild(svgEl("line", { x1: 0, y1: h * 0.28, x2: w * 0.25, y2: h * 0.5, stroke: c, "stroke-width": 3 }));
      return;
    }

    parent.appendChild(svgEl("rect", { x: -w / 2, y: -h / 2, width: w, height: h, rx: 6, fill: c, opacity: 0.25, stroke: c, "stroke-width": 3 }));
  }

  function renderBeams() {
    (window.LightingWorkspace?.sampleFixtures()||state.fixtures).forEach(function (f) {
      const showCone = f.showBeam !== false && LightTimeline.level(f)>0;
      const showFootprint = f.showFootprint !== false && LightTimeline.level(f)>0;
      if (!showCone && !showFootprint) return;
      ensureFixtureTarget(f);
      if ((f.directionMode || "free") === "douche") {
        const d = Math.max(0.3, Number(f.footprintDiameter) || 2);
        const intensity = clamp(Number(f.intensity ?? f.footprintIntensity ?? 65), 0, 100);
        const cx = mx(f.x), cy = my(f.y);
        if (showFootprint) {
          beamLayer.appendChild(svgEl("ellipse", {cx,cy,rx:d*canvas.scaleX/2,ry:d*canvas.scaleY/2,fill:f.color,opacity:0.08+(intensity/100)*0.34,stroke:f.color,"stroke-width":1.6}));
          beamLayer.appendChild(svgEl("ellipse", {cx,cy,rx:d*canvas.scaleX*0.36,ry:d*canvas.scaleY*0.36,fill:"none",stroke:f.color,opacity:0.55,"stroke-width":1,"stroke-dasharray":"4 4"}));
        }
        return;
      }
      if (showCone) {
        beamLayer.appendChild(svgEl("polygon", {points:beamPolygon(f),fill:f.color,opacity:0.14,stroke:f.color,"stroke-width":1.2}));
      }
      const fp = directionalFootprint(f);
      if (fp && showFootprint) {
        beamLayer.appendChild(svgEl("ellipse", {cx:fp.cx,cy:fp.cy,rx:fp.rx,ry:fp.ry,transform:"rotate("+fp.rotation+" "+fp.cx+" "+fp.cy+")",fill:f.color,opacity:fp.opacity,stroke:f.color,"stroke-width":1.5}));
        beamLayer.appendChild(svgEl("ellipse", {cx:fp.cx,cy:fp.cy,rx:fp.rx*0.72,ry:fp.ry*0.72,transform:"rotate("+fp.rotation+" "+fp.cx+" "+fp.cy+")",fill:"none",stroke:f.color,opacity:0.5,"stroke-width":1,"stroke-dasharray":"4 4"}));
      }
      if (state.selection.kind === "fixture" && state.selection.id === f.id && f.directionMode !== "douche" && f.targetMode !== "element") {
        const tx=mx(f.targetX), ty=my(f.targetY);
        const g=svgEl("g", {class:"light-target-handle", style:"cursor:move"});
        g.appendChild(svgEl("circle", {cx:tx,cy:ty,r:9,fill:"#ffffff",stroke:f.color,"stroke-width":2.5}));
        g.appendChild(svgEl("line", {x1:tx-13,y1:ty,x2:tx+13,y2:ty,stroke:f.color,"stroke-width":1.5}));
        g.appendChild(svgEl("line", {x1:tx,y1:ty-13,x2:tx,y2:ty+13,stroke:f.color,"stroke-width":1.5}));
        g.addEventListener("pointerdown", function(ev){ev.stopPropagation(); draggingTargetFixture=state.fixtures.find(original=>original.id===f.id)||null;});
        beamLayer.appendChild(g);
      }
    });
  }

  function renderFixtures() {
    state.fixtures.forEach(function (f) {
      const g = svgEl("g", { class: "object-symbol" });
      const x = mx(f.x);
      const y = my(f.y);
      const selected = state.selection.kind === "fixture" && state.selection.id === f.id;

      // The fixture artwork is authored with its lens/aperture on the local +X axis.
      // PREVUSCENE beam rotation uses 0° = downstage (+Y), 90° = screen-right (+X).
      // Convert between the two so the visible lens always points along the light axis.
      const visualRotation = (90 - (Number(f.rotation) || 0));
      const rotated = svgEl("g", { transform: "translate(" + x + " " + y + ") rotate(" + visualRotation + ")" });

      if (selected) {
        rotated.appendChild(svgEl("circle", { class: "selected-ring", cx: 0, cy: 0, r: 24 }));
      }

      rotated.appendChild(fixtureBody(f));
      if ((f.directionMode || "free") === "douche") {
        rotated.appendChild(svgEl("circle", { cx: 0, cy: 0, r: 21, fill: "none", stroke: f.color, "stroke-width": 1.5, "stroke-dasharray": "3 3" }));
        rotated.appendChild(svgEl("text", { x: 0, y: 4, "text-anchor": "middle", fill: f.color, "font-size": 10, "font-weight": 700 }, "D"));
      } else {
        // Explicit lens-axis marker: the opening and the beam now share the same direction.
        rotated.appendChild(svgEl("line", { x1: 16, y1: 0, x2: 34, y2: 0, stroke: f.color, "stroke-width": 3, "stroke-linecap": "round" }));
        rotated.appendChild(svgEl("polygon", { points: "28,-5 28,5 37,0", fill: f.color }));
      }

      g.appendChild(rotated);

      if (state.ui.showFixtureBadges) {
        g.appendChild(fixtureNumberBadge(f, x, y));
        g.appendChild(fixtureMiniBadge(f, x, y));
      }

      attachDragHandlers(g, f, "fixture");
      fixtureLayer.appendChild(g);
    });
  }

  function renderLabels() {
    state.fixtures.forEach(function (f) {
      labelLayer.appendChild(svgEl("text", {
        x: mx(f.x) + 25,
        y: my(f.y) - 18,
        class: "fixture-label"
      }, f.label || f.type));
    });
  }


  function fixtureNumberBadge(f, x, y) {
    const g = svgEl("g", { class: "fixture-badge" });
    const number = String(f.label || "").replace(/^[A-Za-z]+/, "") || String(f.channel || "");
    g.appendChild(svgEl("circle", { cx: x + 22, cy: y - 22, r: 10 }));
    g.appendChild(svgEl("text", { x: x + 22, y: y - 22 }, number));
    return g;
  }

  function fixtureMiniBadge(f, x, y) {
    const g = svgEl("g", { class: "fixture-mini-badge" });
    const label = f.label || f.type || "";
    const w = Math.max(34, Math.min(68, label.length * 7 + 14));
    g.appendChild(svgEl("rect", { x: x - w / 2, y: y + 26, width: w, height: 18, rx: 4 }));
    g.appendChild(svgEl("text", { x: x, y: y + 35 }, label));
    return g;
  }


  function attachDragHandlers(g, object, kind) {
    g.addEventListener("pointerdown", function (event) {
      event.stopPropagation();
      selectObject(kind, object.id);
      if (object.referenceLocked) return;

      const pos = clientToStageMeters(event.clientX, event.clientY);
      if (pos) {
        draggingObject = object;
        dragOffset.x = pos.x - object.x;
        dragOffset.y = pos.y - object.y;
      }
    });
  }

  function fixtureBody(f) {
    if (state.ui.symbolStyle === "simple") {
      return simpleFixtureBody(f);
    }

    return technicalFixtureBody(f);
  }

  function simpleFixtureBody(f) {
    const t = String(f.type || "").toLowerCase();

    if (t.includes("led bar")) {
      return svgEl("rect", { x: -25, y: -8, width: 50, height: 16, rx: 4, fill: "#111827", stroke: f.color, "stroke-width": 2 });
    }

    if (t.includes("moving")) {
      const g = svgEl("g");
      g.appendChild(svgEl("rect", { x: -16, y: -14, width: 32, height: 28, rx: 8, fill: "#111827", stroke: f.color, "stroke-width": 2 }));
      g.appendChild(svgEl("circle", { cx: 0, cy: 0, r: 8, fill: f.color, opacity: 0.85 }));
      return g;
    }

    if (t.includes("découpe")) {
      return svgEl("polygon", { points: "-16,-15 16,-15 22,15 -22,15", fill: "#111827", stroke: f.color, "stroke-width": 2 });
    }

    if (t.includes("par")) {
      return svgEl("circle", { cx: 0, cy: 0, r: 16, fill: "#111827", stroke: f.color, "stroke-width": 2 });
    }

    if (t.includes("vidéo")) {
      return svgEl("rect", { x: -19, y: -14, width: 38, height: 28, rx: 5, fill: "#111827", stroke: f.color, "stroke-width": 2 });
    }

    if (t.includes("strobe")) {
      const g = svgEl("g");
      g.appendChild(svgEl("rect", { x: -18, y: -10, width: 36, height: 20, rx: 4, fill: "#111827", stroke: f.color, "stroke-width": 2 }));
      g.appendChild(svgEl("path", { d: "M -8 -7 L 2 -7 L -4 2 L 7 2 L -5 12", fill: "none", stroke: f.color, "stroke-width": 2 }));
      return g;
    }

    if (t.includes("beam")) {
      return svgEl("polygon", { points: "0,-18 18,0 0,18 -18,0", fill: "#111827", stroke: f.color, "stroke-width": 2 });
    }

    return svgEl("rect", { x: -16, y: -14, width: 32, height: 28, rx: 6, fill: "#111827", stroke: f.color, "stroke-width": 2 });
  }

  function technicalFixtureBody(f) {
    const t = String(f.type || "").toLowerCase();
    const g = svgEl("g");

    drawMountingSymbol(g, f);

    if (t.includes("led bar")) {
      g.appendChild(svgEl("rect", { x: -30, y: -8, width: 60, height: 16, rx: 3, fill: "#f8fafc", stroke: "#111827", "stroke-width": 2 }));
      for (let i = -22; i <= 22; i += 11) {
        g.appendChild(svgEl("circle", { cx: i, cy: 0, r: 3, fill: f.color, stroke: "#111827", "stroke-width": 0.8 }));
      }
      return g;
    }

    if (t.includes("moving")) {
      g.appendChild(svgEl("rect", { x: -18, y: -16, width: 36, height: 12, rx: 3, fill: "#e5e7eb", stroke: "#111827", "stroke-width": 2 }));
      g.appendChild(svgEl("path", { d: "M -14 -4 Q -18 8 -8 16 M 14 -4 Q 18 8 8 16", fill: "none", stroke: "#111827", "stroke-width": 2 }));
      g.appendChild(svgEl("ellipse", { cx: 0, cy: 12, rx: 16, ry: 12, fill: "#f8fafc", stroke: "#111827", "stroke-width": 2 }));
      g.appendChild(svgEl("circle", { cx: 0, cy: 16, r: 6, fill: f.color, stroke: "#111827", "stroke-width": 1.5 }));
      return g;
    }

    if (t.includes("découpe") || t.includes("profile")) {
      g.appendChild(svgEl("path", { d: "M -24 -12 L 10 -12 L 24 -5 L 24 5 L 10 12 L -24 12 Z", fill: "#f8fafc", stroke: "#111827", "stroke-width": 2 }));
      g.appendChild(svgEl("rect", { x: 20, y: -8, width: 7, height: 16, fill: f.color, stroke: "#111827", "stroke-width": 1.5 }));
      g.appendChild(svgEl("line", { x1: -16, y1: -16, x2: 12, y2: -16, stroke: "#111827", "stroke-width": 1.5 }));
      return g;
    }

    if (t.includes("fresnel") || t.includes("pc")) {
      g.appendChild(svgEl("rect", { x: -22, y: -13, width: 34, height: 26, rx: 5, fill: "#f8fafc", stroke: "#111827", "stroke-width": 2 }));
      g.appendChild(svgEl("circle", { cx: 17, cy: 0, r: 11, fill: f.color, opacity: 0.85, stroke: "#111827", "stroke-width": 1.5 }));
      g.appendChild(svgEl("path", { d: "M -18 -17 Q -4 -25 10 -17", fill: "none", stroke: "#111827", "stroke-width": 2 }));
      return g;
    }

    if (t.includes("par")) {
      g.appendChild(svgEl("ellipse", { cx: 0, cy: 0, rx: 19, ry: 14, fill: "#f8fafc", stroke: "#111827", "stroke-width": 2 }));
      g.appendChild(svgEl("circle", { cx: 7, cy: 0, r: 10, fill: f.color, opacity: 0.85, stroke: "#111827", "stroke-width": 1.5 }));
      g.appendChild(svgEl("rect", { x: -26, y: -6, width: 12, height: 12, fill: "#f8fafc", stroke: "#111827", "stroke-width": 1.5 }));
      return g;
    }

    if (t.includes("vidéo")) {
      g.appendChild(svgEl("rect", { x: -24, y: -14, width: 42, height: 28, rx: 4, fill: "#f8fafc", stroke: "#111827", "stroke-width": 2 }));
      g.appendChild(svgEl("circle", { cx: 21, cy: 0, r: 8, fill: f.color, stroke: "#111827", "stroke-width": 1.5 }));
      return g;
    }

    if (t.includes("strobe")) {
      g.appendChild(svgEl("rect", { x: -24, y: -12, width: 48, height: 24, rx: 3, fill: "#f8fafc", stroke: "#111827", "stroke-width": 2 }));
      g.appendChild(svgEl("path", { d: "M -8 -8 L 4 -8 L -3 1 L 10 1 L -6 13", fill: "none", stroke: f.color, "stroke-width": 2.5 }));
      return g;
    }

    if (t.includes("beam")) {
      g.appendChild(svgEl("polygon", { points: "0,-20 22,0 0,20 -22,0", fill: "#f8fafc", stroke: "#111827", "stroke-width": 2 }));
      g.appendChild(svgEl("circle", { cx: 7, cy: 0, r: 7, fill: f.color, stroke: "#111827", "stroke-width": 1.5 }));
      return g;
    }

    g.appendChild(svgEl("rect", { x: -20, y: -13, width: 40, height: 26, rx: 5, fill: "#f8fafc", stroke: "#111827", "stroke-width": 2 }));
    g.appendChild(svgEl("circle", { cx: 12, cy: 0, r: 9, fill: f.color, stroke: "#111827", "stroke-width": 1.5 }));
    return g;
  }

  function drawMountingSymbol(g, f) {
    const mounting = f.mounting || "suspended";

    if (mounting === "floor") {
      g.appendChild(svgEl("path", { class: "fixture-stand", d: "M 0 -20 L 0 -32 M -16 -32 L 16 -32 M -12 -32 L -22 -42 M 12 -32 L 22 -42" }));
      return;
    }

    if (mounting === "side_jardin" || mounting === "side_cour") {
      g.appendChild(svgEl("line", { class: "fixture-mount-line", x1: -28, y1: -22, x2: -28, y2: 22 }));
      g.appendChild(svgEl("circle", { cx: -28, cy: 0, r: 4, fill: "#d71920", stroke: "#ffffff", "stroke-width": 1.5 }));
      return;
    }

    if (mounting === "foh") {
      g.appendChild(svgEl("path", { class: "fixture-stand", d: "M -18 -24 L 18 -24 M 0 -24 L 0 -16" }));
      return;
    }

    g.appendChild(svgEl("circle", { cx: 0, cy: -24, r: 4, fill: "#d71920", stroke: "#ffffff", "stroke-width": 1.5 }));
    g.appendChild(svgEl("line", { class: "fixture-mount-line", x1: 0, y1: -20, x2: 0, y2: -14 }));
  }

  function applyDirectionPreset(f) {
    const mode = f.directionMode || "free";
    if (mode === "face") f.rotation = 180;
    else if (mode === "contre") f.rotation = 0;
    else if (mode === "jardin") f.rotation = 90;
    else if (mode === "cour") f.rotation = 270;
    else if (mode === "douche") {
      f.rotation = 0;
      f.mounting = "suspended";
      if (!f.footprintDiameter) f.footprintDiameter = 2;
      if (!f.footprintIntensity) f.footprintIntensity = 65;
      if (typeof f.showFootprint !== "boolean") f.showFootprint = true;
    }
    setValue("propRotation", f.rotation);
    setValue("propMounting", f.mounting || "suspended");
  }

  function syncFixtureDirectionControls(f) {
    const douche = (f.directionMode || "free") === "douche";
    const directional = $("#directionalBeamControls");
    const doucheBox = $("#doucheControls");
    const showLabel = $("#showBeamLabel");
    if (directional) directional.classList.toggle("hidden", douche);
    if (doucheBox) doucheBox.classList.toggle("hidden", !douche);
    if (showLabel) showLabel.textContent = "إظهار المخروط الضوئي";
    // A vertical beam has no triangular projection in the top view.
    $("#propShowBeam").disabled = douche;
  }

  function hasTargetNumber(value) {
    if (value === null || value === undefined) return false;
    if (typeof value === "string" && value.trim() === "") return false;
    return Number.isFinite(Number(value));
  }

  function optionalNumber(value) {
    if (value === null || value === undefined) return null;
    if (typeof value === "string" && value.trim() === "") return null;
    const n = Number(value);
    return Number.isFinite(n) ? n : null;
  }

  function ensureFixtureTarget(f) {
    if (!hasTargetNumber(f.targetX) || !hasTargetNumber(f.targetY)) initialiseTargetFromBeam(f, false);
  }

  function initialiseTargetFromBeam(f, force) {
    if (!force && hasTargetNumber(f.targetX) && hasTargetNumber(f.targetY)) return;
    const len=Math.max(0.5,Number(f.beamLength)||3);
    const a=degToRad(Number(f.rotation)||0);
    f.targetX=clamp(Number(f.x)+Math.sin(a)*len,0,state.stage.width);
    f.targetY=clamp(Number(f.y)+Math.cos(a)*len,0,state.stage.depth);
  }

  function syncFixtureTargetGeometry(f) {
    if ((f.directionMode||"free") === "douche") return;
    ensureFixtureTarget(f);
    const dx=Number(f.targetX)-Number(f.x), dy=Number(f.targetY)-Number(f.y);
    const distance=Math.max(0.1,Math.hypot(dx,dy));
    f.beamLength=Math.round(distance*100)/100;
    f.rotation=(Math.atan2(dx,dy)*180/Math.PI+360)%360;
    setValue("propBeamLength", f.beamLength);
    setValue("propRotation", Math.round(f.rotation));
    const rv=$("#rotationValue"), bl=$("#beamLengthValue");
    if(rv) rv.textContent=Math.round(f.rotation)+"°";
    if(bl) bl.textContent=f.beamLength.toFixed(1)+"m";
  }

  function unifiedBeamGeometry(f) {
    ensureFixtureTarget(f);

    const ox = Number(f.x);
    const oy = Number(f.y);
    const tx = Number(f.targetX);
    const ty = Number(f.targetY);
    const dx = tx - ox;
    const dy = ty - oy;
    const distance = Math.max(0.1, Math.hypot(dx, dy));

    const ux = dx / distance;
    const uy = dy / distance;
    const px = -uy;
    const py = ux;

    const halfAngle = degToRad(Math.max(5, Number(f.beamAngle) || 35) / 2);
    const scale = clamp(Number(f.footprintScale) || 0.75, 0.35, 1.5);
    // One shared aperture value drives BOTH the cone opening and the footprint width.
    const halfWidthMeters = Math.max(0.15, distance * Math.tan(halfAngle) * scale);

    const leftStage = { x: tx + px * halfWidthMeters, y: ty + py * halfWidthMeters };
    const rightStage = { x: tx - px * halfWidthMeters, y: ty - py * halfWidthMeters };

    const origin = { x: mx(ox), y: my(oy) };
    const target = { x: mx(tx), y: my(ty) };
    const left = { x: mx(leftStage.x), y: my(leftStage.y) };
    const right = { x: mx(rightStage.x), y: my(rightStage.y) };

    const minorRadius = Math.max(6, Math.hypot(left.x - target.x, left.y - target.y));
    const axisPxX = target.x - origin.x;
    const axisPxY = target.y - origin.y;
    const axisAngle = Math.atan2(axisPxY, axisPxX) * 180 / Math.PI;

    let elongation = 1.35;
    const mode = f.directionMode || "free";
    if (mode === "contre") elongation = 1.45;
    else if (mode === "jardin" || mode === "cour") elongation = 1.55;
    else if (mode === "face") elongation = 1.4;

    return {
      origin: origin,
      target: target,
      left: left,
      right: right,
      minorRadius: minorRadius,
      majorRadius: Math.max(minorRadius, minorRadius * elongation),
      ellipseRotation: axisAngle,
      opacity: 0.14 + (clamp(Number(f.intensity ?? f.footprintIntensity ?? 65), 0, 100) / 100) * 0.16
    };
  }

  function directionalFootprint(f) {
    const mode = f.directionMode || "free";
    if (mode === "douche") return null;
    const g = unifiedBeamGeometry(f);
    return {
      cx: g.target.x,
      cy: g.target.y,
      // Major axis follows the beam; minor axis is EXACTLY the cone opening half-width.
      rx: g.majorRadius,
      ry: g.minorRadius,
      rotation: g.ellipseRotation,
      opacity: g.opacity
    };
  }

  function beamPolygon(f) {
    const g = unifiedBeamGeometry(f);
    return g.origin.x + "," + g.origin.y + " " + g.left.x + "," + g.left.y + " " + g.right.x + "," + g.right.y;
  }

  function autoPatch() {
    let universe = Math.max(1, Number(valueOf("autoUniverse")) || 1);
    let addr = clamp(Number(valueOf("autoDmxStart")) || 1, 1, 512);

    state.fixtures.forEach(function (f) {
      const ch = Math.max(0, Number(f.dmxChannels) || 0);

      if (ch === 0) {
        f.universe = "";
        f.dmxStart = "";
        return;
      }

      if (addr + ch - 1 > 512) {
        universe += 1;
        addr = 1;
      }

      f.universe = universe;
      f.dmxStart = addr;
      addr += ch;
    });

    renderAll();
  }

  function dmxEnd(f) {
    const start = Number(f.dmxStart);
    const ch = Number(f.dmxChannels);

    if (!start || !ch) return "";
    return start + ch - 1;
  }

  function patchWarning(f) {
    const end = dmxEnd(f);

    if (!f.dmxChannels || Number(f.dmxChannels) === 0) return "غير DMX";
    if (!f.dmxStart) return "غير مرقّم";
    if (end > 512) return "يتجاوز 512";

    const overlaps = state.fixtures.filter(function (o) {
      return o.id !== f.id &&
        o.universe == f.universe &&
        o.dmxStart &&
        dmxEnd(o) &&
        !(dmxEnd(f) < Number(o.dmxStart) || Number(f.dmxStart) > dmxEnd(o));
    });

    return overlaps.length ? "تداخل" : "";
  }

  function renderPatchTables() {
    const body = $("#patchTable tbody");
    const print = $("#patchTablePrint tbody");
    body.innerHTML = "";
    print.innerHTML = "";

    let used = 0;
    let warnings = 0;

    state.fixtures.forEach(function (f) {
      const end = dmxEnd(f);
      const warn = patchWarning(f);

      if (Number(f.dmxChannels) > 0) used += Number(f.dmxChannels);
      if (warn) warnings += 1;

      const tr = document.createElement("tr");
      tr.innerHTML = "<td>" + esc(f.label) + "</td><td>" + esc(f.universe || "") + "</td><td>" + esc(f.dmxStart || "") + "</td><td>" + esc(end || "") + "</td><td class=\"" + (warn ? "warn" : "ok") + "\">" + esc(warn || "OK") + "</td>";
      tr.addEventListener("click", function () {
        selectObject("fixture", f.id);
      });
      body.appendChild(tr);

      const pr = document.createElement("tr");
      pr.innerHTML = "<td>" + esc(f.label) + "</td><td>" + esc(f.type) + "</td><td>" + esc(f.mode || "") + "</td><td>" + esc(f.universe || "") + "</td><td>" + esc(f.dmxStart || "") + "</td><td>" + esc(end || "") + "</td><td>" + esc(f.dmxChannels || "") + "</td><td>" + esc(warn || "OK") + "</td>";
      print.appendChild(pr);
    });

    $("#patchSummary").textContent = "عدد الأجهزة: " + state.fixtures.length + " — القنوات المستعملة: " + used + " — التنبيهات: " + warnings;
  }

  function exportPatchCsv() {
    const rows = [["Label", "Type", "Mode", "Universe", "DMX Start", "DMX End", "Channels", "Warning", "Position", "Gel"]];

    state.fixtures.forEach(function (f) {
      rows.push([f.label, f.type, f.mode || "", f.universe || "", f.dmxStart || "", dmxEnd(f) || "", f.dmxChannels || "", patchWarning(f) || "", f.smartPosition || f.position || "", f.gel || ""]);
    });

    const csv = rows.map(function (row) {
      return row.map(function (cell) {
        return '"' + String(cell).replaceAll('"', '""') + '"';
      }).join(",");
    }).join("\n");

    downloadBlob(new Blob([csv], { type: "text/csv;charset=utf-8" }), (state.projectInfo.title || "patch") + "_patch.csv");
  }

  function renderFixtureTable() {
    const tbody = $("#fixtureTable tbody");
    tbody.innerHTML = "";

    state.fixtures.forEach(function (f) {
      const tr = document.createElement("tr");
      tr.innerHTML =
        "<td>" + esc(f.label) + "</td>" +
        "<td>" + esc(f.type) + "</td>" +
        "<td>" + esc(f.smartPosition || f.position || "") + "</td>" +
        "<td>" + esc(f.channel || "") + "</td>" +
        "<td>" + esc(f.dimmer || "") + "</td>" +
        "<td>" + esc(f.universe || "") + "</td>" +
        "<td>" + esc(f.dmxStart || "") + "</td>" +
        "<td>" + esc(f.dmxChannels || "") + "</td>" +
        "<td><span style=\"display:inline-block;width:13px;height:13px;border-radius:50%;background:" + f.color + ";vertical-align:middle\"></span> " + esc(f.gel || "") + "</td>";

      tr.addEventListener("click", function () {
        selectObject("fixture", f.id);
      });

      tbody.appendChild(tr);
    });
  }

  function renderCueTables() {
    const small = $("#cueTable tbody");
    const print = $("#cueTablePrint tbody");
    small.innerHTML = "";
    print.innerHTML = "";

    state.cues.forEach(function (c) {
      const tr = document.createElement("tr");
      tr.innerHTML = "<td>" + esc(c.number) + "</td><td>" + esc(c.title) + "</td><td>"+esc(c.start||0)+" ث</td><td>"+esc(c.fadeIn||0)+" ث</td><td><span class=\"row-actions\"><button data-action=\"edit\">تعديل</button><button data-action=\"delete\">حذف</button></span></td>";

      tr.querySelector('[data-action="delete"]').addEventListener("click", function () {
        state.cues = state.cues.filter(function (item) {return item.id !== c.id;});
        renderAll();
      });

      tr.querySelector('[data-action="edit"]').addEventListener("click", function () {
        setValue("cueNumber", c.number);
        setValue("cueTitle", c.title);
        setValue("cueFadeIn", c.fadeIn);
        setValue("cueFadeOut", c.fadeOut);
        setValue("cueDuration", c.duration);
        setValue("cueNote", c.note);
        setValue("cueStart",c.start||0);state.editingCueId=c.id;state.cueBeforeEdit=JSON.parse(JSON.stringify(state.fixtures));if(c.fixtures){const states=new Map(c.fixtures.map(f=>[f.id,f]));state.fixtures=state.fixtures.map(f=>{const saved=states.get(f.id);return saved?{...saved,...Object.fromEntries(['x','y','height3D','mounting','type','symbol','label','channel','universe','dmxStart'].filter(k=>Object.hasOwn(f,k)).map(k=>[k,f[k]]))}:{...f,intensity:0,footprintIntensity:0};});}
        renderAll();
        updatePropertiesPanel();
      });

      small.appendChild(tr);

      const pr = document.createElement("tr");
      pr.innerHTML = "<td>" + esc(c.number) + "</td><td>" + esc(c.title) + "</td><td>" + esc(c.fadeIn) + "</td><td>" + esc(c.fadeOut) + "</td><td>" + esc(c.duration) + "</td><td>" + esc(c.note) + "</td>";
      print.appendChild(pr);
    });
  }

  function clientToStageMeters(clientX, clientY) {
    const pt = svg.createSVGPoint();
    pt.x = clientX;
    pt.y = clientY;

    const sp = pt.matrixTransform(svg.getScreenCTM().inverse());
    const x = (sp.x - canvas.x0) / canvas.scaleX;
    const y = (sp.y - canvas.y0) / canvas.scaleY;

    if (x < -0.2 || y < -0.2 || x > state.stage.width + 0.2 || y > state.stage.depth + 0.2) return null;

    return {
      x: clamp(x, 0, state.stage.width),
      y: clamp(y, 0, state.stage.depth)
    };
  }

  function exportJson() {
    readProjectForm();
    updateProjectPreview();

    downloadBlob(new Blob([JSON.stringify(state, null, 2)], { type: "application/json" }), safeFileName(state.projectInfo.title || "plan-feu") + ".json");
  }

  function importJson(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function () {
      try {
        loadState(JSON.parse(reader.result));
      } catch (error) {
        alert("ملف JSON غير صالح.");
      }
    };

    reader.readAsText(file);
    event.target.value = "";
  }

  function exportPng() {
    const old = { kind: state.selection.kind, id: state.selection.id };
    state.selection = { kind: null, id: null };
    renderAll();

    const clone = svg.cloneNode(true);
    clone.setAttribute("xmlns", "http://www.w3.org/2000/svg");

    const style = document.createElement("style");
    style.textContent = ".stage-label{font-size:13px;fill:#111827;font-weight:bold}.fixture-label,.scenic-label{font-size:12px;fill:#111827;stroke:#fff;stroke-width:3px;paint-order:stroke}.zone-label{font-size:13px;fill:#111827;stroke:#fff;stroke-width:3px;paint-order:stroke}.selected-ring{display:none}";
    clone.insertBefore(style, clone.firstChild);

    const xml = new XMLSerializer().serializeToString(clone);
    const url = URL.createObjectURL(new Blob([xml], { type: "image/svg+xml;charset=utf-8" }));
    const img = new Image();

    img.onload = function () {
      const c = document.createElement("canvas");
      c.width = canvas.viewW;
      c.height = canvas.viewH;

      const ctx = c.getContext("2d");
      ctx.fillStyle = "#fff";
      ctx.fillRect(0, 0, c.width, c.height);
      ctx.drawImage(img, 0, 0);

      URL.revokeObjectURL(url);

      c.toBlob(function (blob) {
        downloadBlob(blob, safeFileName(state.projectInfo.title || "plan-feu") + ".png");
      });

      state.selection = old;
      renderAll();
    };

    img.src = url;
  }

  function loadState(data) {
    if (!data || typeof data !== 'object' || Array.isArray(data)) throw new Error('ملف مشروع غير صالح.');
    if (data.stage && (!Number.isFinite(Number(data.stage.width)) || Number(data.stage.width)<=0 || !Number.isFinite(Number(data.stage.depth)) || Number(data.stage.depth)<=0 || !Number.isFinite(Number(data.stage.bars)) || Number(data.stage.bars)<0)) throw new Error('أبعاد الخشبة غير صالحة.');
    for (const key of ['fixtures','initialFixtures','scenicItems','drawings','cues','directionPaths','lightingTargets']) if(data[key]!=null&&!Array.isArray(data[key])) throw new Error('قائمة غير صالحة: '+key);
    for (const key of ['fixtures','initialFixtures']) {const ids=new Set();for(const f of data[key]||[]){if(!f||!f.id||ids.has(f.id)||!Number.isFinite(Number(f.x))||!Number.isFinite(Number(f.y)))throw new Error('بيانات أجهزة الإضاءة غير صالحة.');ids.add(f.id);}}
    window.LightingReference?.validateStored(data.referenceProject);
    state.referenceProject = data.referenceProject || null;
    state.lightingProjectId = data.lightingProjectId || crypto.randomUUID();
    state.initialFixtures = Array.isArray(data.initialFixtures) ? data.initialFixtures : null;
    state.ambientLight = Math.max(0, Math.min(100, Number(data.ambientLight ?? 20) || 0));
    state.directionPaths = Array.isArray(data.directionPaths) ? data.directionPaths : [];
    state.lightingTargets = Array.isArray(data.lightingTargets) ? data.lightingTargets : [];
    state.editingCueId = null;
    state.cueBeforeEdit = null;
    state.projectInfo = data.projectInfo || state.projectInfo;
    state.stage = data.stage || state.stage;
    state.layers = Object.assign(state.layers, data.layers || {});
    state.ui = Object.assign(state.ui || {}, data.ui || {});
    state.fixtures = Array.isArray(data.fixtures) ? data.fixtures : [];
    refreshAllSmartFixturePositions();
    state.scenicItems = Array.isArray(data.scenicItems) ? data.scenicItems : [];
    state.drawings = Array.isArray(data.drawings) ? data.drawings : [];
    state.controlBoard=data.controlBoard||{fixtureIds:null,groups:[]};
    state.cues = Array.isArray(data.cues) ? data.cues : [];
    state.selection = { kind: null, id: null };

    syncControlsFromState();
    $("projectScreen").classList.add("hidden");
    window.LightControls?.reset();
    window.LightingWorkspace?.resetTime();
    renderAll();
  }

  function syncControlsFromState() {
    buildStagePresetSelect();
    setValue("stageWidthInput", state.stage.width);
    setValue("stageDepthInput", state.stage.depth);
    setValue("barsCountInput", state.stage.bars);

    document.querySelectorAll(".layerToggle").forEach(function (input) {
      input.checked = !!state.layers[input.dataset.layer];
    });

    const styleSelect = $("#symbolStyleSelect");
    const badgesInput = $("#showFixtureBadgesInput");
    const snapInput = $("#snapToBarsInput");

    if (styleSelect) styleSelect.value = state.ui.symbolStyle || "technical";
    if (badgesInput) badgesInput.checked = state.ui.showFixtureBadges !== false;
    if (snapInput) snapInput.checked = state.ui.snapToBars !== false;
    const refA=$('refShowActors'),refS=$('refShowScenography'),refM=$('refShowMovement'),refT=$('refShowTargets'),refO=$('refOpacity'),refOV=$('refOpacityValue');
    if(refA)refA.checked=state.ui.refShowActors!==false;if(refS)refS.checked=state.ui.refShowScenography!==false;if(refM)refM.checked=state.ui.refShowMovement!==false;if(refT)refT.checked=state.ui.refShowTargets!==false;if(refO){refO.value=Math.round((Number(state.ui.refOpacity)||.55)*100);if(refOV)refOV.textContent=refO.value+'%';}

    fillProjectForm();
    updateProjectPreview();
    updatePropertiesPanel();
  }


  function stageHorizontalZone(x) {
    const w = Math.max(0.001, Number(state.stage.width) || 10);
    const nx = clamp(Number(x) || 0, 0, w) / w;
    if (nx < 1 / 3) return "Jardin";
    if (nx < 2 / 3) return "Centre";
    return "Cour";
  }

  function stageDepthZone(y) {
    const d = Math.max(0.001, Number(state.stage.depth) || 6);
    const ny = clamp(Number(y) || 0, 0, d) / d;
    if (ny < 1 / 3) return "Fond";
    if (ny < 2 / 3) return "Milieu";
    return "Avant";
  }

  function nearestPercheReference(fixture) {
    if (!fixture || state.stage.bars <= 0) return null;
    let best = null;
    let bestDistance = Infinity;
    for (let i = 1; i <= state.stage.bars; i += 1) {
      const by = (state.stage.depth / (state.stage.bars + 1)) * i;
      const dist = Math.abs(by - fixture.y);
      if (dist < bestDistance) {
        bestDistance = dist;
        best = { index: i, y: by, distance: dist };
      }
    }
    return best;
  }

  function updateSmartFixturePosition(fixture) {
    if (!fixture) return "";
    const lateral = stageHorizontalZone(fixture.x);
    const depth = stageDepthZone(fixture.y);
    const zone = depth + " " + lateral;
    const near = nearestPercheReference(fixture);
    let anchor = "";

    if (near && near.distance <= 0.36) {
      anchor = "Perche " + near.index;
    } else if (fixture.mounting === "foh") {
      anchor = "FOH";
    } else if (fixture.mounting === "floor") {
      anchor = "Sol";
    } else if (fixture.mounting === "side_jardin") {
      anchor = "Tour Jardin";
    } else if (fixture.mounting === "side_cour") {
      anchor = "Tour Cour";
    } else if (fixture.mounting === "fond") {
      anchor = "Fond";
    }

    fixture.smartPosition = (anchor ? anchor + " — " : "") + zone;
    fixture.smartCoordinates = "X " + Number(fixture.x).toFixed(2) + "m / Y " + Number(fixture.y).toFixed(2) + "m";
    return fixture.smartPosition;
  }

  function refreshAllSmartFixturePositions() {
    state.fixtures.forEach(updateSmartFixturePosition);
  }

  function applySnapToBars(fixture) {
    if (!state.ui.snapToBars || state.stage.bars <= 0 || (fixture.mounting && fixture.mounting !== "suspended")) return;

    let best = null;
    let bestDistance = Infinity;

    for (let i = 1; i <= state.stage.bars; i += 1) {
      const by = (state.stage.depth / (state.stage.bars + 1)) * i;
      const d = Math.abs(by - fixture.y);

      if (d < bestDistance) {
        bestDistance = d;
        best = { index: i, y: by };
      }
    }

    if (best && bestDistance <= 0.35) {
      fixture.y = best.y;
      fixture.position = "Perche " + best.index;
      if (!fixture.mounting || fixture.mounting === "suspended") {
        fixture.mounting = "suspended";
      }
    }
    updateSmartFixturePosition(fixture);
  }

  function suggestedMounting(y) {
    if (y < state.stage.depth * 0.12) return "fond";
    if (y > state.stage.depth * 0.88) return "foh";
    return "suspended";
  }


  function suggestedPosition(y) {
    if (state.stage.bars <= 0) return "";

    let best = 1;
    let dist = Infinity;

    for (let i = 1; i <= state.stage.bars; i += 1) {
      const by = (state.stage.depth / (state.stage.bars + 1)) * i;
      const d = Math.abs(by - y);

      if (d < dist) {
        best = i;
        dist = d;
      }
    }

    return "Perche " + best;
  }

  function mx(x) {
    return canvas.x0 + x * canvas.scaleX;
  }

  function my(y) {
    return canvas.y0 + y * canvas.scaleY;
  }

  function svgEl(name, attrs, text) {
    const el = document.createElementNS("http://www.w3.org/2000/svg", name);

    Object.keys(attrs || {}).forEach(function (key) {
      el.setAttribute(key, attrs[key]);
    });

    if (text !== undefined) {
      el.textContent = text;
    }

    return el;
  }

  function clear(el) {
    if (!el) return;
    while (el.firstChild) el.removeChild(el.firstChild);
  }

  function $(selector) {
    if (typeof selector !== "string") return null;
    // Accept either a normal CSS selector ("#plot", ".panel")
    // or a bare DOM id ("directionMovementLayer"). This keeps the
    // lighting workspace resilient when modules address shared layers by id.
    if (/^[A-Za-z_][A-Za-z0-9_:\-]*$/.test(selector)) {
      return document.getElementById(selector);
    }
    return document.querySelector(selector);
  }

  function valueOf(id) {
    const el = $("#" + id);
    return el ? el.value.trim() : "";
  }

  function numberOf(id, fallback) {
    const value = Number(valueOf(id));
    return Number.isFinite(value) && value > 0 ? value : fallback;
  }

  function setValue(id, value) {
    const el = $("#" + id);
    if (el) el.value = value ?? "";
  }

  function clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
  }

  function uid(prefix) {
    return prefix + "_" + Math.random().toString(36).slice(2, 10);
  }

  function degToRad(deg) {
    return deg * Math.PI / 180;
  }

  function safeFileName(name) {
    return String(name)
      .trim()
      .replace(/[\\/:*?"<>|]+/g, "-")
      .replace(/\s+/g, "_")
      .slice(0, 80) || "plan-feu";
  }

  function downloadBlob(blob, filename) {
    const a = document.createElement("a");
    const url = URL.createObjectURL(blob);

    a.href = url;
    a.download = filename;

    document.body.appendChild(a);
    a.click();
    a.remove();

    setTimeout(function () {
      URL.revokeObjectURL(url);
    }, 500);
  }

  function esc(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  window.LPF = {
    state: state, refreshProperties:updatePropertiesPanel,
    renderAll: renderAll,
    loadState, snapshot:lightingSceneSnapshot, save:saveLightingSceneToBridge, applyContext:applyDirectionContext,
    renderBeams:()=>{clear(beamLayer);if(state.layers.beams)renderBeams();}, selectFixture:id=>selectObject("fixture",id)
  };
})(window, document);
