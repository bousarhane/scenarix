const fs=require('node:fs'),path=require('node:path'),root=path.resolve(__dirname,'..');
function files(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(entry=>{const p=path.join(dir,entry.name);return entry.isDirectory()?files(p):/\.(html|js|css|json|png|svg)$/.test(p)?[p]:[];});}
const assets=['./index.html',...['app','preview','shared'].flatMap(name=>files(path.join(root,name))).map(p=>'./'+path.relative(root,p).replaceAll(path.sep,'/'))];
const code=`/* Own application assets only; lighting projects are never cached. */
const CACHE_NAME='scenarix-lighting-0.6.23';
const BASE=new URL('./',self.location.href);
const CORE_ASSETS=${JSON.stringify(assets)}.map(p=>new URL(p,BASE).href);
const allowed=new Set(CORE_ASSETS);
self.addEventListener('install',event=>event.waitUntil((async()=>{const cache=await caches.open(CACHE_NAME);await cache.addAll(CORE_ASSETS);await self.skipWaiting();})()));
self.addEventListener('activate',event=>event.waitUntil((async()=>{for(const key of await caches.keys())if(key.startsWith('scenarix-lighting-')&&key!==CACHE_NAME)await caches.delete(key);await self.clients.claim();})()));
self.addEventListener('fetch',event=>{if(event.request.method!=='GET')return;const url=new URL(event.request.url);url.search='';url.hash='';if(!allowed.has(url.href))return;event.respondWith((async()=>{const cached=await(await caches.open(CACHE_NAME)).match(url.href);return cached||fetch(event.request);})());});
`;
fs.writeFileSync(path.join(root,'service-worker.js'),code);console.log('Cached assets: '+assets.length);
