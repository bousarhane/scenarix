(function(){'use strict';
 const $=id=>document.getElementById(id),make=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text)n.textContent=text;return n;};
 const sidebar=document.querySelector('.sidebar'),workspace=document.querySelector('.workspace-panel'),properties=document.querySelector('.properties');
 function fold(section,title){const details=make('details','panel fold-panel'),summary=make('summary',null,title);details.append(summary);for(const n of [...section.children])if(n.tagName!=='H3')details.append(n);section.replaceWith(details);return details;}
 const deviceSection=$('fixtureLibrary').closest('section');deviceSection.id='devicesPanel';deviceSection.querySelector('h3').textContent='الأجهزة';
 const search=make('input');search.id='fixtureSearch';search.type='search';search.placeholder='ابحث عن جهاز…';search.setAttribute('aria-label','البحث في الأجهزة');deviceSection.querySelector('h3').after(search);
 deviceSection.querySelector('.hint').textContent='اسحب الجهاز إلى الخشبة أو إلى بار التعليق.';
 sidebar.querySelector('.collapsed-title').after(deviceSection);
 const mounts=make('section','panel');mounts.id='mountsPanel';mounts.innerHTML='<h3>موقع الجهاز الجديد</h3><label>التركيب<select id="newFixtureMounting"><option value="auto">حسب مكان الإسقاط</option><option value="suspended">بار علوي</option><option value="floor">أرض الخشبة</option><option value="foh">أمامي — FOH</option><option value="side_jardin">جانبي Jardin</option><option value="side_cour">جانبي Cour</option><option value="fond">خلفي — Fond</option></select></label><p class="hint">اختر الموقع ثم اسحب الجهاز. يمكنك تعديل التركيب من خصائصه.</p>';
 deviceSection.after(mounts);
 for(const [id,title] of [['stagePresetSelect','نماذج القاعات'],['stageWidthInput','الخشبة والبارات'],['refShowActors','مرجع الإخراج'],['symbolStyleSelect','الرموز والالتصاق'],['scenicLibrary','رموز إضافية']])fold($(id).closest('section'),title);
 fold(document.querySelector('.layerToggle').closest('section'),'طبقات العرض').id='lightingLayers';fold($('addNineZonesBtn').closest('section'),'الرسم والتعليقات');
 // Keep each form element and its identifier: existing model/event bindings remain authoritative.
 const fixture=$('fixtureProperties');fixture.querySelector('h4').textContent='الجهاز المحدّد';
 const name=$('propLabel').closest('label');fixture.querySelector('h4').after(name);
 const patch=make('details','fixture-technical');patch.id='fixtureTechnical';patch.append(make('summary',null,'المعلومات التقنية · Patch / DMX'));
 for(const id of ['propType','propMode','propPosition','propSmartPosition','propSmartCoordinates','propGel','propNote'])patch.append($(id).closest('label'));
 for(const id of ['propChannel','propUniverse'])patch.append($(id).closest('.small-grid'));
 fixture.append(patch);
 const intensity=$('propFootprintIntensity').closest('label');intensity.firstChild.textContent='شدة الضوء ';$('propColor').closest('label').after(intensity);
 $('propMounting').closest('label').classList.add('mount-property');
 fold($('autoPatchBtn').closest('section'),'جدول Patch والتصدير');
 const cue=$('cueNumber').closest('section');cue.id='lightStatesPanel';cue.className='panel light-states';cue.querySelector('h3').textContent='الحالات الضوئية';
 const stateHeading=make('div','states-heading');stateHeading.append(cue.querySelector('h3'));const actions=make('div','states-actions');
 const fresh=make('button',null,'＋ حالة جديدة');fresh.id='newLightCueBtn';const cancel=make('button',null,'إلغاء التعديل');cancel.id='cancelLightStateBtn';cancel.hidden=true;const play=make('button',null,'▶ تشغيل المشهد');play.id='playLightStatesBtn';play.hidden=true;actions.append(fresh,cancel,play);stateHeading.append(actions);cue.prepend(stateHeading);
 const editor=make('div','cue-editor');editor.id='lightStateEditor';cue.append(editor);
 for(const id of ['cueNumber','cueTitle','cueStart','cueFadeIn','cueFadeOut','cueDuration'])editor.append($(id).closest('label'));
 $('cueFadeIn').closest('label').firstChild.textContent='تدرّج الدخول (ث) ';$('cueFadeOut').closest('label').firstChild.textContent='تدرّج الخروج (ث) ';$('cueNumber').closest('label').firstChild.textContent='رقم الحالة ';
 const note=make('details','cue-note');note.append(make('summary',null,'ملاحظة'),$('cueNote').closest('label'));editor.append($('addCueBtn'),note);cue.append(editor);cue.append($('cueTable').closest('.table-wrap'));workspace.append(cue);
 $('cueTable').querySelector('thead tr').innerHTML='<th>الحالة</th><th>العنوان</th><th>البداية</th><th>الانتقال</th><th></th>';
 const top=document.querySelector('.top-actions'),files=make('details','project-files');files.id='lightingFileMenu';files.append(make('summary',null,'المشروع والتصدير'));
 for(const id of ['editProjectBtn','newProjectBtn','loadLocalBtn','exportJsonBtn','importJsonInput','exportPngBtn','printPdfBtn'])files.append(id==='importJsonInput'?$(id).closest('label'):$(id));top.append(files);$('saveLocalBtn').textContent='حفظ';

 $('noSelectionMsg').textContent='اختر بروجيكتورًا على الخشبة. اسحب هدفه لتوجيه الضوء، ثم اضبط اللون والشدة.';
 fresh.onclick=()=>{cancelEdit();for(const id of ['cueTitle','cueFadeIn','cueFadeOut','cueDuration','cueNote'])$(id).value='';$('cueNumber').value=Math.max(0,...LPF.state.cues.map(c=>Number(c.number)||0))+1;$('cueStart').value=window.LightingWorkspace?.time||0;$('cueTitle').focus();};
 function cancelEdit(){if(!window.LPF)return;if(LPF.state.editingCueId){if(LPF.state.cueBeforeEdit)LPF.state.fixtures=LPF.state.cueBeforeEdit;LPF.state.editingCueId=null;LPF.state.cueBeforeEdit=null;LPF.renderAll();LPF.selectFixture(LPF.state.selection.id);} }
 cancel.onclick=cancelEdit;
 play.onclick=()=>{LightingWorkspace.open();$('sharedPlay').click();};
 search.oninput=()=>{const query=search.value.trim().toLocaleLowerCase();for(const el of $('fixtureLibrary').children)el.hidden=!el.dataset.type.toLocaleLowerCase().includes(query);};
 function refresh(){if(!window.LPF)return;const editing=!!LPF.state.editingCueId;cancel.hidden=!editing;$('addCueBtn').textContent=editing?'اعتماد التعديل':'حفظ الحالة';play.hidden=!$('openSharedPreview');if(editing)cue.classList.add('editing-state');else cue.classList.remove('editing-state');}
 window.addEventListener('lighting:changed',refresh);window.addEventListener('lighting:ready',()=>{refresh();requestAnimationFrame(refresh);});
 window.LightingUI={refresh};
})();
