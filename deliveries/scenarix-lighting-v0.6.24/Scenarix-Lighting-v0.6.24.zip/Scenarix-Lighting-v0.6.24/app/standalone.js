(function(){'use strict';
 const $=id=>document.getElementById(id),create=(tag,text)=>{const n=document.createElement(tag);if(text)n.textContent=text;return n;};
 document.body.classList.add('standalone-lighting');
 // Keep onboarding brief; retain credits and installation information in MENU.
 const card=$('projectScreen').querySelector('.project-card'),identity=card.querySelector('.app-identity');
 identity.querySelector('.lead').textContent='صمّم مخطط الإضاءة، واضبط الأجهزة من الكونسول، واحفظ الحالات الضوئية.';
 const extras=create('details');extras.className='menu-settings';extras.append(create('summary','عن التطبيق والتثبيت'),identity.querySelector('.credits-box'),identity.querySelector('.pwa-install-box'));document.querySelector('.interface-menu-content').append(extras);
 const form=card.querySelector('.form-grid'),team=create('details');team.className='team-details';team.append(create('summary','بيانات الفريق والإنتاج'));const fields=create('div');fields.className='form-grid';team.append(fields);for(const id of ['companyName','directorName','scenographerName','productionYear'])fields.append($(id).closest('label'));form.after(team);form.prepend($('showTitle').closest('label'));
 const open=create('button','فتح ملف إضاءة JSON');open.id='welcomeOpenLighting';open.onclick=()=>$('importJsonInput').click();$('startProjectBtn').after(open);
 const reference=create('section');reference.className='menu-group';reference.append(create('h3','مرجع إخراج اختياري'));const label=create('label','استيراد مرجع JSON / stage2d');label.className='import-label';const input=create('input');input.type='file';input.accept='.json,.stage2d';input.id='importReferenceInput';label.append(input);reference.append(label);
 const remove=create('button','إزالة المرجع');remove.id='removeReferenceBtn';reference.append(remove);document.querySelector('.interface-menu-content').append(reference);
 const status=create('span');status.id='referenceStatus';document.querySelector('.lighting-project-summary').append(status);
 input.onchange=async()=>{const file=input.files[0];input.value='';if(!file)return;try{LightingWorkspace.pause();const data=JSON.parse(await file.text());LightingReference.importProject(data);LPF.selectFixture(null);}catch(error){alert(error.message);}};
 remove.onclick=()=>{if(!LPF.state.referenceProject)return;if(!confirm('إزالة مرجع الإخراج مع الاحتفاظ بخطة الإضاءة الحالية؟'))return;LightingWorkspace.pause();LightingReference.clear();LPF.state.scenicItems=LPF.state.scenicItems.filter(o=>!o.importedFromDirection);LPF.state.directionPaths=[];LPF.state.lightingTargets=[];LPF.renderAll();};
 function refresh(){const ref=LightingReference.readContext();status.textContent=ref?'المرجع: '+ref.currentScene.title:'تطبيق إضاءة مستقل';status.title=ref?'مرجع للمعاينة فقط؛ عناصر الإخراج غير قابلة للتعديل هنا.':'يمكن العمل دون مشروع إخراج.';remove.disabled=!ref;$('directionContextBar').classList.remove('hidden');}
 window.addEventListener('lighting:ready',refresh);window.addEventListener('lighting:changed',refresh);
})();
