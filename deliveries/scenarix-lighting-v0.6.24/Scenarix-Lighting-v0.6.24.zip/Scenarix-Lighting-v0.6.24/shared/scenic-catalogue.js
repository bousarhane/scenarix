(function(root){'use strict';
 const entries=[
 ['Actor','ممثل واقف',.65,.65,'actor-male.svg','people','male','standing'],['Actor Female','ممثلة واقفة',.65,.65,'actor-female.svg','people','female','standing'],['Actor Seated','ممثل جالس',.7,.7,'actor-male.svg','people','male','sitting'],['Actor Female Seated','ممثلة جالسة',.7,.7,'actor-female.svg','people','female','sitting'],['Actor Crouching','ممثل قرفصاء',.65,.65,'actor-male.svg','people','male','crouching'],['Actor Female Crouching','ممثلة قرفصاء',.65,.65,'actor-female.svg','people','female','crouching'],
 ['Chair','كرسي',.65,.65,'chair.svg','furniture'],['Table','طاولة',1.6,.9,'table.svg','furniture'],['Sofa','أريكة',2.2,.9,'sofa.svg','furniture'],['Bed','سرير',2,1.3,'bed.svg','furniture'],['Desk','مكتب',1.4,.7,'desk.svg','furniture'],
 ['Door','باب',1,.2,'door.svg','space'],['Window','نافذة',1.4,.2,'window.svg','space'],['Wall','جدار',3,.15,'wall.svg','space'],['Column','عمود',.45,.45,'column.svg','space'],['Stairs','درج',1.2,1.8,'stairs.svg','space'],['Platform','منصة',2.5,1.5,'platform.svg','space'],['Round Platform','منصة دائرية',1.5,1.5,'round-platform.svg','space'],
 ['Front Curtain','ستار أمامي',8,.2,'front-curtain.svg','drapes'],['Side Curtain','ستارة جانبية',1.5,.15,'pendrillon.svg','drapes'],['Cyclorama','سيكلوراما',8,.2,'cyclorama.svg','drapes'],
 ['Screen','شاشة',3,.2,'screen.svg','other'],['Tree','شجرة',1.2,1.2,'tree.svg','other'],['Prop','إكسسوار',.5,.5,'prop.svg','other'],['FOHBar','بار أمامي',8,.18,'','rigging'],['SideTowerJardin','برج جانبي Jardin',.35,3,'','rigging'],['SideTowerCour','برج جانبي Cour',.35,3,'','rigging'],['Zone','منطقة لعب',3,2,'','zones']
 ].map(([type,label,w,h,icon,category,gender,pose])=>({type,label,w,h,icon,category,gender,pose,color:gender?'#168bc2':'#7aa2f7',...(type==='Zone'?{kind:'zone'}:{})}));
 root.ScenicCatalogue={entries,find:type=>entries.find(e=>e.type===type),isActor:o=>o.referenceKind==='actor'||String(o.type).startsWith('Actor')};
})(window);
