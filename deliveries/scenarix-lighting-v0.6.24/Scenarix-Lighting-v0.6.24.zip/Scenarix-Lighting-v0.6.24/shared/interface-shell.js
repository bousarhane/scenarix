/* A common menu and information hierarchy for both workspaces. Existing controls
   are moved, not cloned, so their model bindings and undo behavior stay intact. */
(function(){'use strict';
 if(document.body.classList.contains('shared-preview'))return;
 const $=id=>document.getElementById(id),make=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text)n.textContent=text;return n;};
 document.body.classList.add('calm-interface');
 const menu=$('lightingFileMenu');
 menu.className='interface-menu';menu.querySelector('summary').textContent='☰ MENU';menu.querySelector('summary').setAttribute('aria-label','MENU — المشروع والإعدادات');
 const content=make('div','interface-menu-content');menu.append(content);
 function group(title,nodes){const section=make('section','menu-group');section.append(make('h3',null,title));for(const n of nodes)if(n)section.append(n);content.append(section);return section;}
 function fold(title,node,id){const d=make('details','menu-settings');if(id)d.id=id;d.append(make('summary',null,title));if(node){node.classList.remove('tab-panel');node.classList.add('menu-settings-body');d.append(node);}return d;}
 function nodes(ids){return ids.map($).filter(Boolean);}
 const files=group('المشروع',nodes(['newProjectBtn','loadLocalBtn','editProjectBtn','exportJsonBtn']));
 files.append($('importJsonInput').closest('label'));
 group('التصدير',nodes(['exportPngBtn','printPdfBtn']));
 const settings=group('الإعدادات',[]);
 const menuSummary=menu.querySelector('summary');
 function closeMenu(){menu.open=false;}
 menu.addEventListener('click',ev=>{if(ev.target.closest('button,a')&&!ev.target.closest('.menu-settings'))closeMenu();});
 document.addEventListener('pointerdown',ev=>{if(menu.open&&!menu.contains(ev.target))closeMenu();});
 document.addEventListener('keydown',ev=>{if(ev.key==='Escape'&&menu.open){closeMenu();menuSummary.focus();}});

  for(const id of ['lightPanel-mounts','lightPanel-layers'])settings.append($(id));
  $('stageWidthInput').closest('details').open=true;$('lightingLayers').open=true;
  const layoutGroup=group('ترتيب مساحة العمل',nodes(['maximizeLightPreview']));
  $('maximizeLightPreview').addEventListener('click',()=>{if(document.body.classList.contains('lighting-expanded'))$('lightingDeskTools').append($('maximizeLightPreview'));else layoutGroup.append($('maximizeLightPreview'));});
  // Navigation stays in the header; view choices stay beside the stage.
  if($('prevusceneHubButton'))$('prevusceneHubButton').textContent='الإخراج';$('playLightStatesBtn').classList.add('redundant-control');
  const header=document.querySelector('.topbar'),info=header.firstElementChild;info.classList.add('lighting-project-summary');
  const context=$('directionContextBar');context.classList.add('header-context');info.append(context);
  const note=context.querySelector('span:last-child');if(note)note.hidden=true;
  const meta=$('projectMetaPreview');meta.title=meta.textContent;
  function sync(){
   const launch=$('openSharedPreview');if(launch)launch.hidden=true;
   const panel=$('sharedPreviewPanel');if(panel&&!panel.dataset.calm){panel.dataset.calm='true';const nav=panel.querySelector('nav');$('shared2D').hidden=true;$('shared3D').hidden=true;nav.querySelector('b').hidden=true;$('sharedClose').textContent='عودة إلى المخطط';}
   const select=$('lightingSceneSelect');if(select){select.setAttribute('aria-label','المشهد الحالي');select.title='المشهد الحالي';}
  }
  window.addEventListener('lighting:ready',sync);new MutationObserver(sync).observe(document.body,{childList:true});new MutationObserver(sync).observe(context,{childList:true});sync();
 window.InterfaceShell={closeMenu};
})();
