(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.DMXOutput=factory();})(typeof window==='object'?window:globalThis,function(){'use strict';
 const profiles={dimmer:[{offset:1,source:'intensity'}],rgb:[{offset:1,source:'red'},{offset:2,source:'green'},{offset:3,source:'blue'}],rgbw:[{offset:1,source:'red'},{offset:2,source:'green'},{offset:3,source:'blue'},{offset:4,source:'white'}]};
 const sources=['intensity','red','green','blue','white','fixed'];
 const integer=(v,a,b)=>Number.isInteger(Number(v))&&Number(v)>=a&&Number(v)<=b;
 function buildFrames(fixtures){const frames={},safeFrames={},errors=[],occupied=new Map();let count=0;
 for(const f of fixtures){const channels=Number(f.dmxChannels||0);if(channels===0)continue;count++;const label=f.label||f.type||f.id;
 if(!integer(channels,1,512)||!integer(f.universe,1,32768)||!integer(f.dmxStart,1,512)||Number(f.dmxStart)+channels-1>512){errors.push(label+': عنوان Universe / DMX أو عدد القنوات غير صالح.');continue;}
 const u=Number(f.universe),start=Number(f.dmxStart);for(let i=0;i<channels;i++){const key=u+':'+(start+i);if(occupied.has(key))errors.push(label+': تداخل Patch مع '+occupied.get(key)+' في '+key);else occupied.set(key,label);}
 const profile=f.dmxOutput;if(profile?.confirmed!==true||profile.mode!==f.mode||profile.footprint!==channels){errors.push(label+': حدد خريطة القنوات واعتمد مطابقتها لوضع الجهاز.');continue;}
 const mapping=profile.kind==='custom'?profile.channels:profiles[profile.kind];if(!Array.isArray(mapping)||!mapping.length||mapping.length!==channels){errors.push(label+': يجب تعريف كل قناة في وضع الجهاز؛ لا تفترض خريطة من اسم الموديل.');continue;}
 const offsets=new Set();let valid=true;for(const row of mapping){if(!integer(row.offset,1,channels)||offsets.has(Number(row.offset))||!sources.includes(row.source)||(row.source==='fixed'&&!integer(row.value,0,255))){valid=false;break;}offsets.add(Number(row.offset));}
 if(!valid||!mapping.some(row=>row.source!=='fixed')){errors.push(label+': خريطة القنوات غير صالحة أو لا تحتوي على قناة للتحكم في الضوء.');continue;}
 const rawLevel=Number(f.intensity??f.footprintIntensity??65);if(!Number.isFinite(rawLevel)||rawLevel<0||rawLevel>100){errors.push(label+': الشدة خارج المجال 0–100.');continue;}
 const colour=/^#[0-9a-f]{6}$/i.test(f.color||'')?f.color:'#ffffff';let r=parseInt(colour.slice(1,3),16),g=parseInt(colour.slice(3,5),16),b=parseInt(colour.slice(5,7),16);const white=mapping.some(row=>row.source==='white')?Math.min(r,g,b):0;r-=white;g-=white;b-=white;
 const level=rawLevel/100,colourLevel=mapping.some(row=>row.source==='intensity')?(level>0?1:0):level,values={intensity:Math.round(level*255),red:Math.round(r*colourLevel),green:Math.round(g*colourLevel),blue:Math.round(b*colourLevel),white:Math.round(white*colourLevel)};
 frames[u]||=Array(512).fill(0);safeFrames[u]||=Array(512).fill(0);for(const row of mapping){const index=start+Number(row.offset)-2;frames[u][index]=row.source==='fixed'?Number(row.value):values[row.source];safeFrames[u][index]=row.source==='fixed'?Number(row.value):0;}
 }
 if(!count)errors.push('أضف جهازًا يدعم DMX ثم اضبط Patch وخريطة قنواته.');return{frames,safeFrames,errors,fixtureCount:count};}
 return{profiles,sources,buildFrames};
});
