const { app, BrowserWindow, dialog, ipcMain } = require('electron');
const fs = require('fs');
const path = require('path');

const {fileURLToPath}=require('url');
let mainWindow;
const projectPaths=new Set();
const allowedPages=new Set(['direction/index.html','lighting/index.html'].map(p=>path.join(__dirname,p)));
function trusted(event){if(!mainWindow||event.sender!==mainWindow.webContents||event.senderFrame!==mainWindow.webContents.mainFrame)throw new Error('UNTRUSTED_SENDER');let page;try{page=fileURLToPath(event.senderFrame.url.split('#')[0].split('?')[0]);}catch{throw new Error('UNTRUSTED_PAGE');}if(!allowedPages.has(page))throw new Error('UNTRUSTED_PAGE');}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1500,
    height: 940,
    minWidth: 1100,
    minHeight: 720,
    backgroundColor: '#111827',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });
  mainWindow.webContents.setWindowOpenHandler(({url})=>url==='about:blank'?{action:'allow',overrideBrowserWindowOptions:{webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true,preload:undefined}}}:{action:'deny'});
  mainWindow.webContents.on('will-navigate',(event,url)=>{let target;try{target=fileURLToPath(url.split('#')[0].split('?')[0]);}catch{}if(!allowedPages.has(target))event.preventDefault();});
  mainWindow.loadFile(path.join(__dirname,'direction/index.html'));
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

ipcMain.handle('project:save', async (event, { data, filePath }) => {
  trusted(event);
  if(filePath&&!projectPaths.has(path.resolve(filePath)))throw new Error('UNAPPROVED_FILE_PATH');
  let target = filePath;
  if (!target) {
    const result = await dialog.showSaveDialog(mainWindow, {
      title: 'حفظ مشروع الإخراج',
      defaultPath: 'مشروع-مسرحي.stage2d',
      filters: [
        { name: 'مشروع Mise en Scene 2D', extensions: ['stage2d'] },
        { name: 'JSON', extensions: ['json'] }
      ]
    });
    if (result.canceled) return { canceled: true };
    target = result.filePath;
  }
  projectPaths.add(path.resolve(target));
  const temporary=target+'.tmp';
  fs.writeFileSync(temporary, JSON.stringify(data, null, 2), 'utf8');
  if(fs.existsSync(target))fs.copyFileSync(target,target+'.bak');
  fs.renameSync(temporary,target);
  return { canceled: false, filePath: target };
});

ipcMain.handle('project:open', async (event) => {
  trusted(event);
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'فتح مشروع إخراج',
    properties: ['openFile'],
    filters: [
      { name: 'مشروع Mise en Scene 2D', extensions: ['stage2d', 'json'] }
    ]
  });
  if (result.canceled || !result.filePaths[0]) return { canceled: true };
  const filePath = result.filePaths[0];
  const raw = fs.readFileSync(filePath, 'utf8');
  projectPaths.add(path.resolve(filePath));
  return { canceled: false, filePath, data: JSON.parse(raw) };
});

ipcMain.handle('export:png', async (event, { dataUrl, defaultName }) => {
  trusted(event);
  if(typeof dataUrl!=='string'||!/^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(dataUrl)||dataUrl.length>64*1024*1024)throw new Error('INVALID_PNG');
  const result = await dialog.showSaveDialog(mainWindow, {
    title: 'تصدير مخطط الخشبة',
    defaultPath: defaultName || 'مخطط-المشهد.png',
    filters: [{ name: 'PNG Image', extensions: ['png'] }]
  });
  if (result.canceled) return { canceled: true };
  const base64 = dataUrl.replace(/^data:image\/png;base64,/, '');
  fs.writeFileSync(result.filePath, Buffer.from(base64, 'base64'));
  return { canceled: false, filePath: result.filePath };
});

ipcMain.handle('app:print', async (event) => {
  trusted(event);
  if (!mainWindow) return false;
  mainWindow.webContents.print({ printBackground: true });
  return true;
});
