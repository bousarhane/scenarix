(function () {
  "use strict";

  let deferredInstallPrompt = null;

  const installButton = document.getElementById("installPwaBtn");
  const status = document.getElementById("pwaStatus");

  function setStatus(message) {
    if (status) status.textContent = message;
  }

  if ("serviceWorker" in navigator) {
    window.addEventListener("load", function () {
      navigator.serviceWorker.register("../service-worker.js", {scope: "../"})
        .then(async function () {
          await navigator.serviceWorker.ready;
          for(const registration of await navigator.serviceWorker.getRegistrations())if(registration.active?.scriptURL.endsWith('/lighting/service-worker.js'))await registration.unregister();
          setStatus("التطبيق جاهز للعمل دون اتصال بعد تحميله أول مرة.");
        })
        .catch(function () {
          setStatus("لم يتم تفعيل وضع العمل دون اتصال. جرّب فتح التطبيق عبر خادم محلي أو HTTPS.");
        });
    });
  } else {
    setStatus("هذا المتصفح لا يدعم Service Worker.");
  }

  window.addEventListener("beforeinstallprompt", function (event) {
    event.preventDefault();
    deferredInstallPrompt = event;

    if (installButton) {
      installButton.classList.remove("hidden");
    }

    setStatus("يمكن الآن تثبيت التطبيق على هذا الجهاز.");
  });

  if (installButton) {
    installButton.addEventListener("click", async function () {
      if (!deferredInstallPrompt) {
        setStatus("إن لم يظهر التثبيت تلقائيا، استعمل قائمة المتصفح ثم اختر تثبيت التطبيق أو Add to Home Screen.");
        return;
      }

      deferredInstallPrompt.prompt();

      const result = await deferredInstallPrompt.userChoice;
      deferredInstallPrompt = null;
      installButton.classList.add("hidden");

      if (result.outcome === "accepted") {
        setStatus("تم تثبيت التطبيق أو قبول طلب التثبيت.");
      } else {
        setStatus("تم إلغاء التثبيت. يمكنك تثبيته لاحقا من قائمة المتصفح.");
      }
    });
  }

  window.addEventListener("appinstalled", function () {
    setStatus("تم تثبيت التطبيق بنجاح.");
    if (installButton) installButton.classList.add("hidden");
  });
})();
