/* Upgrade legacy lighting-only installations. */
importScripts('../service-worker.js');
