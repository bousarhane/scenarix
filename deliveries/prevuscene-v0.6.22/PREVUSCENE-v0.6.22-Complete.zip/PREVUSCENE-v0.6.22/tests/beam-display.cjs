const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const pw=require(process.env.PLAYWRIGHT_MODULE||'playwright'),root=process.env.APP_DIR||path.resolve(__dirname,'..');
(async()=>{
 const c=process.env.CHROMIUM_PACKAGE_MODULE?(await import(process.env.CHROMIUM_PACKAGE_MODULE)).default:{args:['--no-sandbox']};
 const browser=await pw.chromium.launch({executablePath:process.env.BROWSER_EXECUTABLE,args:c.args,headless:true});
 try {
  const page=await browser.newPage({viewport:{width:1600,height:1100}}),errors=[],external=[];
  page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(/^https?:/.test(r.url()))external.push(r.url());});
  await page.goto('file://'+path.join(root,'lighting/index.html'));await page.click('#startProjectBtn');
  await page.evaluate(()=>{LPF.state.fixtures=[{id:'test',type:'PC 1kW',label:'test',x:2,y:2,directionMode:'face',rotation:30,beamAngle:40,beamLength:4,targetX:4,targetY:5,color:'#ffd36a',showBeam:true,showFootprint:true,footprintIntensity:65,intensity:65}];LPF.renderAll();LPF.selectFixture('test');});
  async function counts(cone,footprint){assert.deepEqual(await page.evaluate(()=>[document.querySelectorAll('#beamLayer polygon').length,document.querySelectorAll('#beamLayer ellipse').length]),[cone,footprint]);}
  async function combinations(){for(let i=0;i<3;i++){await page.locator('#propShowBeam').check();await page.locator('#propShowFootprint').check();await counts(1,2);await page.locator('#propShowBeam').uncheck();await counts(0,2);await page.locator('#propShowFootprint').uncheck();await counts(0,0);await page.locator('#propShowBeam').check();await counts(1,0);await page.locator('#propShowFootprint').check();await counts(1,2);}}
  await combinations();
  // Real target drag changes the mode to free: the footprint must survive.
  await page.locator('#plot').scrollIntoViewIfNeeded();
  const handle=page.locator('.light-target-handle circle'),box=await handle.boundingBox();
  assert(box);await page.mouse.move(box.x+box.width/2,box.y+box.height/2);await page.mouse.down();await page.mouse.move(box.x+box.width/2+40,box.y+box.height/2+20,{steps:3});await page.mouse.up();
  assert.equal(await page.evaluate(()=>LPF.state.fixtures[0].directionMode),'free');await counts(1,2);await combinations();
  const before=await page.evaluate(()=>{const f=LPF.state.fixtures[0];return [f.targetX,f.targetY,f.rotation,f.intensity];});
  await page.locator('#propShowBeam').uncheck();await counts(0,2);
  assert.deepEqual(await page.evaluate(()=>{const f=LPF.state.fixtures[0];return [f.targetX,f.targetY,f.rotation,f.intensity];}),before);
  await page.selectOption('#propDirectionMode','douche');assert(await page.locator('#propShowBeam').isDisabled());await counts(0,2);
  await page.locator('#propShowFootprint').uncheck();await counts(0,0);await page.locator('#propShowFootprint').check();await counts(0,2);
  await page.selectOption('#propDirectionMode','free');assert(await page.locator('#propShowBeam').isEnabled());await counts(0,2);
  if(await page.locator('#lightPanel-layers').count())await page.click('#lightPanel-layers');
  if(await page.locator('#lightingLayers').count())await page.click('#lightingLayers summary');
  await page.locator('.layerToggle[data-layer="beams"]').uncheck();await counts(0,0);assert.equal(await page.locator('#beamDisplayHint').evaluate(el=>el.hidden),false);
  await page.evaluate(()=>LPF.renderBeams());await counts(0,0);
  await page.locator('.layerToggle[data-layer="beams"]').check();await counts(0,2);
  if(await page.locator('#lightPanel-properties').count())await page.click('#lightPanel-properties');
  // Independent fixture choices, then real JSON import round trip.
  await page.evaluate(()=>{LPF.state.fixtures.push({...LPF.state.fixtures[0],id:'other',showBeam:true,showFootprint:false});LPF.renderAll();LPF.selectFixture('other');});await counts(1,2);
  assert(await page.locator('#propShowBeam').isChecked());assert(!await page.locator('#propShowFootprint').isChecked());
  await page.evaluate(()=>LPF.selectFixture('test'));assert(!await page.locator('#propShowBeam').isChecked());assert(await page.locator('#propShowFootprint').isChecked());
  const saved=await page.evaluate(()=>({stage:LPF.state.stage,...LPF.snapshot()}));
  await page.locator('#importJsonInput').setInputFiles({name:'display.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(saved))});
  await page.waitForFunction(()=>LPF.state.selection.id===null);await page.evaluate(()=>LPF.selectFixture('test'));await counts(1,2);
  // Same settings survive a linked project save/reload with cues present.
  const project=JSON.parse(fs.readFileSync(path.join(root,'examples/obstacles-and-surfaces.stage2d'),'utf8'));
  await page.evaluate(({project,saved})=>{project.lightingByScene={[project.currentSceneId]:{...saved,initialFixtures:saved.fixtures,cues:[{id:'q',start:1,fixtures:saved.fixtures}]}};PREVUSCENEBridge.writeContext(SceneContract.projectContext(project,project.currentSceneId));},{project,saved});
  await page.reload();await page.waitForFunction(()=>!!document.getElementById('lightingSceneSelect'));await page.evaluate(()=>LPF.selectFixture('test'));await counts(1,2);
  await page.locator('#propShowBeam').check();await counts(2,2);await page.locator('#propShowFootprint').uncheck();await counts(2,0);
  await page.reload();await page.waitForFunction(()=>!!document.getElementById('lightingSceneSelect'));await page.evaluate(()=>LPF.selectFixture('test'));await counts(2,0);
  assert.equal(await page.evaluate(()=>LPF.state.cues.length),1);assert.deepEqual(errors,[]);assert.deepEqual(external,[]);
  console.log('Passed: repeated cone/footprint/both/hide choices, real target drag and free direction, vertical footprint, hidden layer, unchanged aim/intensity, independent fixtures, JSON import, linked save/reload with cues; no page errors or external requests.');
 } finally {await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
