const assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs');
const pw=require(process.env.PLAYWRIGHT_MODULE||'playwright');
const near=(a,b)=>assert(Math.abs(a-b)<.002,`${a} differs from ${b}`);
(async()=>{
 let args=['--no-sandbox'];if(process.env.CHROMIUM_PACKAGE_MODULE){const{default:c}=await import(process.env.CHROMIUM_PACKAGE_MODULE);args=c.args;}
 const browser=await pw.chromium.launch({executablePath:process.env.BROWSER_EXECUTABLE,args,headless:true});
 const page=await browser.newPage({viewport:{width:1500,height:980},acceptDownloads:true}),errors=[],external=[];
 page.on('pageerror',e=>errors.push(e.stack));page.on('dialog',d=>d.accept());page.on('request',r=>{if(/^https?:/.test(r.url()))external.push(r.url());});
 try{
  await require('./legacy-controls.cjs')(page);await page.goto('file://'+path.resolve(__dirname,'../index.html'));await page.waitForFunction(()=>!!window.MS2D);
  await page.fill('#authUserName','معاينة مسرحية');await page.fill('#authPassword','12345');await page.fill('#authConfirmPassword','12345');await page.click('#authSubmitBtn');await page.waitForFunction(()=>MS2DSecurity.isUnlocked());
  await page.locator('[data-type=actorMale]').dragTo(page.locator('#canvasContainer'));const actor=await page.evaluate(()=>selectedId);
  await page.evaluate(id=>{Object.assign(scene().objects.find(o=>o.id===id),{x:300,y:330,pose:'side',facing:90,name:'الممثل الأول',characterName:'الممثل الأول'});renderScene();},actor);
  async function clickStage(x,y){const pt=await page.evaluate(({x,y})=>{const m=viewport.getScreenCTM();return{x:m.a*x+m.c*y+m.e,y:m.b*x+m.d*y+m.f};},{x,y});await page.mouse.click(pt.x,pt.y);}
  async function newMove(shape,duration){await page.click('[data-tab=movementTab]');await page.evaluate(id=>MS2D.setSelectedId(id),actor);await page.click('#createMovementBtn');await page.click('#chooseTranslationBtn');await page.check('#newMoveTranslationBody');await page.selectOption('#newMoveOrientationChoice','custom');await page.selectOption('#newMoveShape',shape);await page.fill('#newMoveDuration',duration);}
  await newMove('circle','2.8');await page.selectOption('#newMoveEndPose','standing');await page.fill('#newMoveEndFacing','0');await page.click('#startMovementDrawBtn');await clickStage(450,330);
  const circle=await page.evaluate(()=>scene().paths[0].id);
  await page.evaluate(()=>addObject('chair',700,420));const chair=await page.evaluate(()=>selectedId);
  await newMove('straight','1.4');await page.selectOption('#newMoveEndPose','sitting');await page.selectOption('#newMoveEndTarget',chair);await page.click('#startMovementDrawBtn');await clickStage(700,420);
  await page.evaluate(()=>{
   for(const [type,x,y]of [['actorFemale',460,210],['table',570,80],['sofa',180,160],['platform',850,140],['stairs',850,240],['wall',500,50]])addObject(type,x,y);
   const female=scene().objects.find(o=>o.gender==='female');female.pose='crouching';female.facing=270;selectedId=null;renderAll();
  });
  await page.evaluate(()=>{state.project.title='تجربة ثلاثية الأبعاد — دائرة ثم جلوس';scene().title='دائرة ثم جلوس';renderAll();});
  const example=await page.evaluate(()=>clone(state));const exampleDir=path.resolve(__dirname,'../examples');fs.mkdirSync(exampleDir,{recursive:true});fs.writeFileSync(path.join(exampleDir,'3D-circle-and-chair.stage2d'),JSON.stringify(example,null,2));
  const authored=await page.evaluate(()=>JSON.stringify(scene().paths));
  await page.click('#open3DPreviewBtn');await page.waitForFunction(()=>Stage3D.inspect().rendered);
  assert.equal(await page.locator('#preview3DError').isVisible(),false);
  let info=await page.evaluate(()=>Stage3D.inspect());assert.equal(info.items.length,8);const final=info.items.find(o=>o.id===actor);near(final.position[0],2);near(final.position[2],1.2);assert.equal(final.pose,'sitting');near(final.yaw,0);
  for(const mode of ['left','right','top','elevated','audience']){await page.selectOption('#camera3D',mode);const camera=await page.evaluate(()=>Stage3D.inspect().camera);assert(camera.every(Number.isFinite));}
  await page.selectOption('#camera3D','elevated');await page.waitForTimeout(250);await page.screenshot({path:path.resolve(__dirname,'../PREVIEW-3D-stage.png')});
  // Read the same moving scene in both projections, including the circular track.
  await page.click('#play3DSceneBtn');await page.waitForTimeout(200);
  const sample=await page.evaluate(id=>{const info=Stage3D.inspect().items.find(x=>x.id===id),g=layerGroup('actors').querySelector(`[data-id="${id}"]`),t=g.getAttribute('transform').match(/translate\(([^ ]+) ([^)]+)\)/),f=g.querySelector('.actor-orientation').getAttribute('transform').match(/rotate\(([^)]+)\)/);return{info,x:Number(t[1]),y:Number(t[2]),facing:-Number(f[1]),active:!!simulationFrame};},actor);
  assert(sample.active);near(sample.info.position[0],sample.x/100-5);near(sample.info.position[2],sample.y/100-3);near(sample.info.yaw,sample.facing*Math.PI/180);
  await page.click('#stop3DBtn');const stopped=await page.evaluate(id=>({o:clone(scene().objects.find(o=>o.id===id)),r:Stage3D.inspect().items.find(x=>x.id===id)}),actor);near(stopped.r.position[0],stopped.o.x/100-5);near(stopped.r.position[2],stopped.o.y/100-3);assert.equal(stopped.r.pose,stopped.o.pose);
  await page.click('#play3DSceneBtn');await page.waitForFunction(()=>!simulationFrame,{},{timeout:15000});
  info=await page.evaluate(()=>Stage3D.inspect());const seated=info.items.find(o=>o.id===actor);assert.equal(seated.pose,'sitting');near(seated.position[0],2);near(seated.position[2],1.2);assert.equal(await page.evaluate(()=>JSON.stringify(scene().paths)),authored);
  // Picking a physical torso in the 3D canvas selects the original actor.
  await page.selectOption('#camera3D','audience');
  const pt=await page.evaluate(id=>{const data=Stage3D.inspect(),item=data.items.find(o=>o.id===id),canvas=document.querySelector('#preview3DCanvas canvas'),r=canvas.getBoundingClientRect(),cam=new THREE.PerspectiveCamera(48,r.width/r.height,.05,150);cam.position.fromArray(data.camera);cam.lookAt(0,.85,0);cam.updateMatrixWorld();const point=new THREE.Vector3(item.position[0],1.05,item.position[2]).project(cam);return{x:r.left+(point.x+1)/2*r.width,y:r.top+(1-point.y)/2*r.height};},actor);
  await page.mouse.click(pt.x,pt.y);assert.equal(await page.evaluate(()=>selectedId),actor);
  await page.fill('#height3D','1.9');await page.locator('#selected3DName').click();assert.equal(await page.evaluate(id=>scene().objects.find(o=>o.id===id).height3D,actor),1.9);
  await page.fill('#elevation3D','.3');await page.locator('#selected3DName').click();near((await page.evaluate(()=>Stage3D.inspect())).items.find(o=>o.id===actor).position[1],.3);
  for(const pose of ['standing','side','sitting','floorSitting','kneeling','crouching','bending','lyingBack','lyingFront','lyingSide','moving']){await page.selectOption('#pose3D',pose);assert.equal((await page.evaluate(()=>Stage3D.inspect())).items.find(o=>o.id===actor).pose,pose);}
  await page.selectOption('#pose3D','lyingBack');assert.equal((await page.evaluate(()=>Stage3D.inspect())).items.find(o=>o.id===actor).pose,'lyingBack');
  await page.fill('#facing3D','270');await page.locator('#selected3DName').click();near((await page.evaluate(()=>Stage3D.inspect())).items.find(o=>o.id===actor).yaw,Math.PI*1.5);
  await page.uncheck('#paths3D');await page.uncheck('#labels3D');
  const downloadPromise=page.waitForEvent('download');await page.click('#export3DBtn');const download=await downloadPromise;const exported=path.resolve(__dirname,'../PREVIEW-3D-export.png');await download.saveAs(exported);assert(fs.statSync(exported).size>15000);
  // Camera orbit and zoom do not change the authored project.
  const before=await page.evaluate(()=>JSON.stringify(state));const cb=await page.locator('#preview3DCanvas canvas').boundingBox();await page.mouse.move(cb.x+cb.width*.3,cb.y+cb.height*.3);await page.mouse.down();await page.mouse.move(cb.x+cb.width*.4,cb.y+cb.height*.35,{steps:5});await page.mouse.up();await page.mouse.wheel(0,-120);assert.equal(await page.evaluate(()=>JSON.stringify(state)),before);
  await page.click('#close3DBtn');assert(await page.locator('#stageSvg').isVisible());assert.equal(await page.inputValue('#objPose'),'lyingBack');
  await page.evaluate(()=>DirectionStorage.saveLocal());await page.reload();await page.waitForFunction(()=>MS2DSecurity.isUnlocked()&&scene().paths.length===2);assert.equal(await page.evaluate(id=>scene().objects.find(o=>o.id===id).height3D,actor),1.9);
  await page.click('#open3DPreviewBtn');await page.waitForFunction(()=>Stage3D.inspect().rendered);near((await page.evaluate(()=>Stage3D.inspect())).items.find(o=>o.id===actor).position[1],.3);
  // Switching scenes while reading updates all objects in the 3D view.
  await page.evaluate(()=>{const sc=defaultScene(state.acts[0].id);sc.title='المشهد الثاني';sc.objects=[preset('actorFemale',220,180)];state.scenes.push(sc);});
  await page.click('#play3DShowBtn');await page.waitForFunction(()=>scene().title==='المشهد الثاني',{},{timeout:15000});assert.equal((await page.evaluate(()=>Stage3D.inspect())).items.length,1);await page.click('#stop3DBtn');
  await page.evaluate(()=>MS2DSecurity.lock());await page.waitForFunction(()=>!document.getElementById('preview3DDialog').open);
  assert.deepEqual(external,[]);assert.deepEqual(errors,[]);console.log('Offline WebGL: cameras, articulated poses, scenery, shared circular/straight timing and final chair state, stop, ray selection, 3D height/base/pose/facing edits, PNG, camera immutability, encrypted reload, scene reading and lock passed.');
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exit(1);});
