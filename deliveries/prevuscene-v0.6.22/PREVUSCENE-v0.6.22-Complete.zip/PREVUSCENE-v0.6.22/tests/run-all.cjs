// Tests run serially in a disposable copy; examples and release screenshots stay unchanged.
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),cp=require('node:child_process');
const root=path.resolve(__dirname,'..'),dir=fs.mkdtempSync(path.join(os.tmpdir(),'prevuscene-validation-')),app=path.join(dir,'app');
const playwrightModule=process.env.PLAYWRIGHT_MODULE||require.resolve('playwright');
const tests=['bridge-contracts','seating-approach','offline-workspaces','desktop-guard','urgent-fixes','lighting-desk','actor-appearance','beam-display','light-timeline','lighting-repair','lighting-integration','terrain-contracts','spatial-constraints','cyclorama','frise-stairs','scenery','workspace','timeline-contracts','actor-continuity','movement-editing','movement-dialog','movement-choice','final-state-edit','body-actions','arm-gestures','stage-support','choreography','scene-playback','original-ui','actor-sprites','direct-selection','selection-3d','preview-3d','example-3d','director-sequence'];
const selected=process.argv.length>2?process.argv.slice(2):tests;
if(selected.some(t=>!tests.includes(t)))throw Error('Unknown test name.');
fs.cpSync(root,app,{recursive:true,filter:src=>!path.relative(root,src).split(path.sep).some(part=>['node_modules','dist','.git'].includes(part))});
const testEnv={...process.env,PLAYWRIGHT_MODULE:playwrightModule,APP_DIR:app};
let failed=false;const failures=[];
try{
 for(const test of selected){console.log('\nTEST '+test);const r=cp.spawnSync(process.execPath,[path.join(app,'tests',test+'.cjs')],{env:testEnv,stdio:'inherit',timeout:240000});if(r.error||r.status!==0){failed=true;console.error(r.error?.message||'Failed: '+test);failures.push(test);}}
 if(process.env.PROJECT_TEST_FILE&&process.env.PROJECT_TEST_PASSWORD){const r=cp.spawnSync(process.execPath,[path.join(app,'tests/imported-project.cjs')],{env:testEnv,stdio:'inherit',timeout:180000});if(r.error||r.status!==0){failed=true;failures.push('imported-project');}}
 else if(!failed)console.log('External user-project test needs PROJECT_TEST_FILE and PROJECT_TEST_PASSWORD; not run.');
 console.log(failed?'Validation failed: '+failures.join(', '):'All configured tests passed.');
}finally{fs.rmSync(dir,{recursive:true,force:true});}
process.exitCode=failed?1:0;
