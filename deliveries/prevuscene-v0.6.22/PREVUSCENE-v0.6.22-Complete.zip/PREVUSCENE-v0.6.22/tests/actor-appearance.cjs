const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),pw=require(process.env.PLAYWRIGHT_MODULE||'playwright');
const root=process.env.APP_DIR||path.resolve(__dirname,'..');
(async()=>{const c=process.env.CHROMIUM_PACKAGE_MODULE?(await import(process.env.CHROMIUM_PACKAGE_MODULE)).default:{args:['--no-sandbox']};const browser=await pw.chromium.launch({executablePath:process.env.BROWSER_EXECUTABLE||await c.executablePath(),args:c.args,headless:true});
try{const page=await browser.newPage({viewport:{width:1500,height:1000}}),errors=[],external=[];page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(/^https?:/.test(r.url()))external.push(r.url());});
 await page.goto('file://'+path.join(root,'direction/shared-preview.html'));await page.waitForFunction(()=>!!window.Stage3D);
 const ids=await page.evaluate(()=>{scene().objects=[];scene().paths=[];addObject('actorMale',440,300);const male=selected().id;addObject('actorFemale',560,300);const female=selected().id;for(const o of scene().objects){o.facing=0;o.pose='standing';o.color='#437c88';o.characterName=o.gender==='female'?'الممثلة':'الممثل';}selectedId=null;renderAll();return{male,female};});
 await page.evaluate(()=>Stage3D.open());await page.waitForFunction(()=>Stage3D.inspect().rendered);
 const get=()=>page.evaluate(()=>Stage3D.inspect().items);let items=await get();assert.equal(items.find(o=>o.id===ids.male).appearance,'male');assert.equal(items.find(o=>o.id===ids.female).appearance,'female');
 for(const pose of ['standing','sitting','crouching','kneeling','bending','floorSitting','lyingBack','lyingFront','lyingSide']){
  await page.evaluate(pose=>{for(const o of scene().objects)o.pose=pose;renderScene();},pose);items=await get();for(const item of items){assert.equal(item.pose,pose);assert(item.hipWorld.every(Number.isFinite));for(const point of Object.values(item.arms))assert(point.every(Number.isFinite));}
 }
 await page.evaluate(()=>{for(const o of scene().objects){o.pose='standing';o.poseTransition={from:'standing',to:'sitting',progress:.5};}renderScene();});items=await get();for(const item of items)assert(Math.abs(item.hip[1]-.78)<.001);
 await page.evaluate(()=>{for(const o of scene().objects){o.poseTransition=null;o.pose='standing';o.arms={right:{preset:'raised',bend:0}};}renderScene();});items=await get();for(const item of items){assert(item.arms.rh[1]>item.arms.rs[1]+.4);const dist=(a,b)=>Math.hypot(...a.map((v,i)=>v-b[i]));assert(Math.abs(dist(item.arms.re,item.arms.rs)-.29*1.72/1.8)<.002);assert(Math.abs(dist(item.arms.rh,item.arms.re)-.27*1.72/1.8)<.002);}
 await page.evaluate(id=>{scene().objects.find(o=>o.id===id).gender='female';renderScene();},ids.male);assert.equal((await get()).find(o=>o.id===ids.male).appearance,'female');
 await page.evaluate(id=>{scene().objects.find(o=>o.id===id).gender='male';for(const o of scene().objects){o.arms={};o.pose='standing';}scene().title='هيئتان بشريتان — الممثل والممثلة';renderScene();},ids.male);
 const authored=await page.evaluate(()=>JSON.stringify(scene()));
 await page.evaluate(id=>{Stage3D.movementFrame(scene(),new Map([[id,{x:440,y:300,facing:0,pose:'standing'}]]),0);Stage3D.movementFrame(scene(),new Map([[id,{x:500,y:350,facing:90,pose:'standing',arms:{right:{preset:'raised',bend:0}}}]]),1);},ids.male);
 const moving=(await get()).find(o=>o.id===ids.male);assert(Math.abs(moving.position[0])<.002);assert(Math.abs(moving.position[2]-.5)<.002);assert(Math.abs(moving.yaw-Math.PI/2)<.002);
 assert.equal(await page.evaluate(()=>JSON.stringify(scene())),authored);await page.evaluate(()=>{Stage3D.endMovement();Stage3D.sync();});
 await page.locator('#labels3D').uncheck();await page.locator('#paths3D').uncheck();
 const bounds=await page.locator('#preview3DCanvas canvas').boundingBox();await page.mouse.move(bounds.x+bounds.width/2,bounds.y+bounds.height/2);await page.mouse.wheel(0,-1000);
 await page.waitForTimeout(300);await page.locator('#preview3DCanvas').screenshot({path:path.join(root,'PREVIEW-actor-appearance-3D.png'),timeout:60000});
 const project=await page.evaluate(()=>clone(state));fs.writeFileSync(path.join(root,'examples/actor-appearance.stage2d'),JSON.stringify(project,null,2));
 assert.deepEqual(errors,[]);assert.deepEqual(external,[]);console.log('Passed: distinct male/female rigs, gender refresh, nine poses, gradual posture, raised arm lengths, unchanged body joints; no page errors or external requests.');
}finally{await browser.close();}})().catch(e=>{console.error(e);process.exitCode=1;});
