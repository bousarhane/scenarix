const assert=require('node:assert/strict'),path=require('node:path');
const pw=require(process.env.PLAYWRIGHT_MODULE||'playwright');
(async()=>{
 let args=['--no-sandbox'];if(process.env.CHROMIUM_PACKAGE_MODULE){const{default:c}=await import(process.env.CHROMIUM_PACKAGE_MODULE);args=c.args;}
 const browser=await pw.chromium.launch({executablePath:process.env.BROWSER_EXECUTABLE,args,headless:true});
 const page=await browser.newPage({viewport:{width:1500,height:980}}),errors=[];
 page.on('pageerror',e=>errors.push(e.stack));page.on('dialog',d=>d.accept());
 try{
  await require('./legacy-controls.cjs')(page);await page.goto('file://'+path.resolve(__dirname,'../index.html'));await page.waitForFunction(()=>!!window.MS2D);
  await page.fill('#authUserName','تسلسل مسرحي');await page.fill('#authPassword','12345');await page.fill('#authConfirmPassword','12345');await page.click('#authSubmitBtn');await page.waitForFunction(()=>MS2DSecurity.isUnlocked());
  const r=await page.evaluate(()=>{
   addObject('actorMale',200,300);const actor=selected();actor.initialState=ActorContinuity.stateOf(actor);
   const make=(id,start,duration,extra={})=>({id,code:id,actorObjectId:actor.id,type:'walk',actionKind:'pose',pathShape:'stationary',direction:'forward',timingMode:'absolute',absoluteStart:start,duration,x1:200,y1:300,x2:200,y2:300,startStateMode:'inherit',positionStartMode:'inherit',startPose:'standing',endPose:'standing',startFacing:0,endFacing:0,facingMode:'fixed',poseAt:0,poseEndAt:100,poseInterpolation:'smooth',...extra});
   const set=(...ps)=>{actor.stateChanges=[];scene().paths=ps;renderScene();};
   const sample=t=>{const all=ActorContinuity.prepare(compileMovementSchedule());return sampleActorActions(all.filter(a=>a.path.actorObjectId===actor.id),t,actor,id=>sampleActorPosition(all.filter(a=>a.path.actorObjectId===id),t,scene().objects.find(o=>o.id===id)));};
   const out={};
   set(make('later',8,2,{startStateMode:'explicit',startPose:'side',endPose:'sitting'}));out.future=[sample(1).pose,sample(1).facing];
   set(make('long-turn',0,10,{actionKind:'turn',facingMode:'turn',endFacing:90}),make('short-turn',2,1,{actionKind:'turn',facingMode:'turn',endFacing:180}));out.afterOverlap=sample(4).facing;
   const first=make('first',0,2,{endPose:'crouching'}),last=make('last',4,2,{endPose:'standing'});
   set(first,last);out.firstDerived=last.startPose;
   const middle=make('middle',2,2,{endPose:'kneeling'});scene().paths.push(middle);renderScene();out.inserted=last.startPose;
   middle.absoluteStart=7;renderScene();out.retimed=last.startPose;
   first.endPose='bending';renderScene();out.edited=last.startPose;
   scene().paths=scene().paths.filter(p=>p.id!=='first');renderScene();out.deletedOpening=last.startPose;
   actor.initialState.pose='side';actor.initialState.facing=90;
   set(make('walk',0,2,{actionKind:'translate',pathShape:'straight',x2:400}),make('next',2,2,{actionKind:'translate',pathShape:'straight',x1:400,x2:600}));out.translation=[sample(1).pose,sample(1).facing];
   scene().paths[0].x2=450;renderScene();out.adjusted=[scene().paths[1].x1,sample(3).facing];
   addObject('chair',200,300);const chair=selected();actor.initialState={...actor.initialState,x:200,y:300,pose:'sitting',support:StageSupport.bind(actor,chair,'sitting')};
   set(make('stay-seated',0,2,{actionKind:'compound',pathShape:'straight',x2:210,keepStartPose:true,endPose:'sitting'}));out.supportHeld=sample(2).support?.targetId===chair.id;
   scene().paths[0].x2=400;renderScene();out.supportDetached=sample(2).support;
   actor.initialState={x:200,y:300,pose:'standing',facing:0,poseTransition:null,support:null,arms:{}};
   set(make('raise-right',0,2,{actionKind:'gesture',armSide:'right',gesturePreset:'raised',gestureFinish:'hold',gestureReachAt:50,startArms:{}}),make('raise-left',2,2,{actionKind:'gesture',armSide:'left',gesturePreset:'side',gestureFinish:'hold',gestureReachAt:50,startArms:{}}));out.independentArms=[sample(3).arms.right.preset,sample(4).arms.left.preset];
   const a=make('delete-A',0,2,{endPose:'crouching',code:'M01'}),b=make('delete-B',2,2,{code:'M02',timingMode:'sequential',anchorMovementId:'delete-A'});set(a,b);
   selectedPathId=a.id;selectedId=null;renderScene();return{...out,actor:actor.id};
  });
  assert.deepEqual(r.future,['standing',0]);assert.equal(r.afterOverlap,180);
  assert.equal(r.firstDerived,'crouching');assert.equal(r.inserted,'kneeling');assert.equal(r.retimed,'crouching');assert.equal(r.edited,'bending');assert.equal(r.deletedOpening,'standing');
  assert.deepEqual(r.translation,['side',90]);assert.deepEqual(r.adjusted,[450,90]);assert.equal(r.supportHeld,true);assert.equal(r.supportDetached,null);assert.deepEqual(r.independentArms,['raised','side']);
  await page.click('[data-tab=movementTab]');await page.click('#deleteMovementBtn');
  let remaining=await page.evaluate(()=>({paths:clone(scene().paths),times:compileMovementSchedule().map(a=>({start:a.start,invalid:a.invalid})),o:clone(scene().objects.find(o=>o.type==='actor'))}));
  assert.equal(remaining.paths[0].startPose,'standing');assert.deepEqual(remaining.times,[{start:2,invalid:''}]);
  await page.click('#undoBtn');assert.equal(await page.evaluate(()=>scene().paths.length),2);await page.click('#redoBtn');assert.equal(await page.evaluate(()=>scene().paths.length),1);
  await page.evaluate(id=>{selectedId=id;selectedPathId=null;renderScene()},r.actor);await page.click('#createMovementBtn');await page.click('#choosePostureBtn');await page.selectOption('#newMovePostureMode','hold');await page.click('#startMovementDrawBtn');assert.equal(await page.evaluate(()=>currentMovement().code),'M03');await page.click('#deleteMovementBtn');
  await page.evaluate(()=>{selectedPathId=scene().paths[0].id;renderScene();});await page.click('#deleteMovementBtn');
  remaining=await page.evaluate(()=>clone(scene().objects.find(o=>o.type==='actor')));assert.equal(remaining.pose,'standing');assert.equal(remaining.x,200);
  await page.evaluate(id=>{selectedId=id;selectedPathId=null;renderScene()},r.actor);await page.click('#createMovementBtn');await page.click('#chooseTranslationBtn');await page.selectOption('#newMoveShape','polyline');await page.click('#startMovementDrawBtn');
  async function clickStage(x,y){const q=await page.evaluate(({x,y})=>{const pt=svg.createSVGPoint();pt.x=x;pt.y=y;const q=pt.matrixTransform(viewport.getScreenCTM());return{x:q.x,y:q.y};},{x,y});await page.mouse.click(q.x,q.y);}
  await clickStage(400,350);assert.equal(await page.evaluate(()=>scene().paths.length),0);await clickStage(550,250);assert.equal(await page.evaluate(()=>scene().paths.length),0);
  await page.click('#finishPolylineBtn');const poly=await page.evaluate(()=>clone(currentMovement()));assert.equal(poly.points.length,3);assert.equal(poly.x2,550);assert.equal(poly.y2,250);
  await page.evaluate(()=>DirectionStorage.saveLocal());await page.reload();await page.waitForFunction(()=>MS2DSecurity.isUnlocked()&&scene().paths.length===1);assert.deepEqual(await page.evaluate(()=>clone(scene().paths[0])),poly);
  const oldIds=await page.evaluate(()=>{const saved={id:'saved-state',title:'حالة محفوظة',objects:clone(scene().objects),paths:clone(scene().paths),ambientLight:scene().ambientLight};const actor=saved.objects.find(o=>o.type==='actor');saved.paths[0].id='saved-only-action';actor.stateChanges=[{id:'saved-point',afterMovementId:'saved-only-action',time:5,keys:['pose'],value:{...ActorContinuity.stateOf(actor),pose:'kneeling'}}];scene().states=[saved];return{objects:saved.objects.map(o=>o.id),path:saved.paths[0].id};});
  await page.click('#duplicateSceneBtn');const copy=await page.evaluate(()=>clone(scene()));assert.equal(copy.states.length,1);assert(copy.states[0].objects.every(o=>!oldIds.objects.includes(o.id)));assert.notEqual(copy.states[0].paths[0].id,oldIds.path);const savedActor=copy.states[0].objects.find(o=>o.type==='actor');assert.equal(savedActor.stateChanges[0].afterMovementId,copy.states[0].paths[0].id);
  await page.click('[data-tab=scenesTab]');await page.locator('#sceneStatesList [data-s=apply]').click();assert.equal(await page.evaluate(()=>scene().paths[0].id),copy.states[0].paths[0].id);assert.equal(await page.evaluate(()=>sampleActorActions(ActorContinuity.prepare(compileMovementSchedule()),10,scene().objects.find(o=>o.type==='actor')).pose),'kneeling');
  const lateActor=await page.evaluate(()=>{const a=scene().objects.find(o=>o.type==='actor');a.stateChanges=[];const first=scene().paths[0];first.duration=2;scene().paths.push({...clone(first),id:'late-hold',code:'M02',actionKind:'hold',pathShape:'stationary',duration:2,timingMode:'sequential',anchorMovementId:first.id,offset:0});renderScene();selectedId=a.id;selectedPathId=null;renderScene();return a.id;});await page.selectOption('#objPose','kneeling');
  await page.click('[data-tab=movementTab]');await page.evaluate(()=>{selectedId=null;selectedPathId='late-hold';renderScene();});await page.click('#deleteMovementBtn');
  await page.evaluate(id=>{selectedId=id;selectedPathId=null;renderScene()},lateActor);await page.selectOption('#objPose','standing');assert.equal(await page.evaluate(id=>sampleActorActions(ActorContinuity.prepare(compileMovementSchedule()),5,scene().objects.find(o=>o.id===id)).pose,lateActor),'standing','A surviving later actor state must remain editable after its arrow is removed.');assert.deepEqual(errors,[]);
  console.log('Passed: future isolation, overlap ownership, insertion/retiming/edit/delete, initial restoration, independent body/position/arms, seat hold/detach, real delete/undo/redo, preserved timing anchors, multipoint clicks, encrypted reload, duplicated saved states and restore.');
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exit(1);});
