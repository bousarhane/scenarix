const assert=require('node:assert/strict'),path=require('node:path');const pw=require(process.env.PLAYWRIGHT_MODULE||'playwright');
(async()=>{let args=['--no-sandbox'];if(process.env.CHROMIUM_PACKAGE_MODULE){const{default:c}=await import(process.env.CHROMIUM_PACKAGE_MODULE);args=c.args;}const b=await pw.chromium.launch({executablePath:process.env.BROWSER_EXECUTABLE,args,headless:true});const page=await b.newPage({viewport:{width:1500,height:980}});const errors=[];page.on('pageerror',e=>errors.push(e.stack));page.on('dialog',d=>d.accept());try{
await require('./legacy-controls.cjs')(page);await page.goto('file://'+path.resolve(__dirname,'../index.html'));await page.waitForFunction(()=>!!window.MS2D);await page.fill('#authUserName','أيقونات');await page.fill('#authPassword','12345');await page.fill('#authConfirmPassword','12345');await page.click('#authSubmitBtn');await page.waitForFunction(()=>MS2DSecurity.isUnlocked());

for(const gender of ['male','female']){
 await page.locator(`[data-type="${gender==='male'?'actorMale':'actorFemale'}"]`).dragTo(page.locator('#canvasContainer'));
 await page.click('#actorPosePicker [data-view="side"]');
 await page.click('#actorFacingPicker [data-facing="270"]');
 assert.equal(await page.evaluate(()=>selected().pose),'side');assert.equal(await page.evaluate(()=>selected().facing),270);
 const id=await page.evaluate(()=>selectedId),actor=`[data-id="${id}"]`;
 assert.equal(await page.locator(actor+' .actor-sprite').getAttribute('transform'),'scale(-1 1)');
 await page.click('#actorPosePicker [data-view="side"]');assert.equal(await page.evaluate(()=>selected().facing),270,'Re-selecting side pose must preserve its direction');
 await page.click('#actorFacingPicker [data-facing="90"]');assert.equal(await page.evaluate(()=>selected().pose),'side');
 assert.equal(await page.locator(actor+' .actor-sprite').getAttribute('transform'),null);
}
const id=await page.evaluate(()=>selectedId),actor=`[data-id="${id}"]`;
await page.click('[data-tab=movementTab]');await page.click('#createMovementBtn');await page.click('#chooseTranslationBtn');await page.check('#newMoveTranslationBody');await page.selectOption('#newMoveOrientationChoice','custom');
await page.selectOption('#newMoveShape','straight');await page.fill('#newMoveDuration','2');await page.click('#startMovementDrawBtn');
const pt=await page.evaluate(()=>{const m=viewport.getScreenCTM();return{x:m.a*400+m.c*250+m.e,y:m.b*400+m.d*250+m.f};});await page.mouse.click(pt.x,pt.y);
await page.selectOption('#moveEndPose','standing');
assert.equal(await page.evaluate(()=>currentMovement().endPose),'standing','Edited final pose must survive change handler');
assert.equal(await page.inputValue('#moveEndPose'),'standing');
await page.selectOption('#moveOrientationChoice','custom');await page.fill('#moveEndFacing','0');await page.locator('#moveEndPose').click();
assert.equal(await page.evaluate(()=>currentMovement().endFacing),0);
assert.equal(await page.evaluate(id=>scene().objects.find(o=>o.id===id).pose,id),'standing');
assert.equal(await page.locator(actor+' .actor-sprite').getAttribute('data-view'),'front');
await page.click('#simulateMovementBtn');await page.waitForTimeout(100);
assert.equal(await page.locator(actor+' .actor-sprite').getAttribute('data-view'),'side');
await page.waitForFunction(()=>!simulationFrame,{},{timeout:10000});
assert.equal(await page.locator(actor+' .actor-sprite').getAttribute('data-view'),'front');
const reached=await page.evaluate(id=>clone(scene().objects.find(o=>o.id===id)),id);assert.equal(reached.pose,'standing');assert.equal(reached.facing,0);assert(Math.abs(reached.x-400)<.001);assert(Math.abs(reached.y-250)<.001);
// Change both body states and the turn on the same already drawn movement.
await page.selectOption('#moveEndPose','side');await page.selectOption('#moveOrientationChoice','custom');await page.fill('#moveEndFacing','270');await page.locator('#moveEndPose').click();
await page.fill('#movePoseAt','30');await page.locator('#moveEndPose').click();
assert.equal(await page.inputValue('#moveStartPose'),'side');assert.equal(await page.inputValue('#moveStartFacing'),'90');
assert.equal(await page.evaluate(()=>currentMovement().poseAt),30);
assert.equal(await page.locator(actor+' .actor-sprite').getAttribute('transform'),'scale(-1 1)');
await page.click('#simulateMovementBtn');await page.waitForFunction(()=>!simulationFrame,{},{timeout:10000});
assert.equal(await page.evaluate(id=>scene().objects.find(o=>o.id===id).facing,id),270);
await page.selectOption('#moveOrientationChoice','fixed');assert.equal(await page.evaluate(()=>currentMovement().facingMode),'fixed');
assert.equal(await page.evaluate(id=>scene().objects.find(o=>o.id===id).facing,id),90);
await page.selectOption('#moveOrientationChoice','custom');
// Editing during playback must also preserve the new value through its stop/redraw.
await page.evaluate(()=>{currentMovement().duration=3;});await page.click('#simulateMovementBtn');await page.waitForTimeout(100);
await page.selectOption('#moveEndPose','sitting');assert.equal(await page.evaluate(()=>currentMovement().endPose),'sitting');
assert.equal(await page.evaluate(id=>scene().objects.find(o=>o.id===id).pose,id),'sitting');
await page.evaluate(()=>DirectionStorage.saveLocal());await page.reload();await page.waitForFunction(()=>MS2DSecurity.isUnlocked()&&scene().paths.length===1);
const saved=await page.evaluate(()=>clone(scene().paths[0]));assert.equal(saved.startPose,'side');assert.equal(saved.endPose,'sitting');assert.equal(saved.startFacing,90);assert.equal(saved.endFacing,270);assert.equal(saved.poseAt,30);
await page.click('[data-tab=movementTab]');await page.evaluate(()=>{selectedPathId=scene().paths[0].id;scene().paths[0].duration=2;renderScene();});
await page.click('#simulateMovementBtn');await page.waitForFunction(()=>!simulationFrame,{},{timeout:10000});
assert.equal(await page.evaluate(id=>scene().objects.find(o=>o.id===id).pose,id),'sitting');assert.equal(await page.evaluate(id=>scene().objects.find(o=>o.id===id).facing,id),270);
assert.deepEqual(errors,[]);console.log('Actual UI: final pose/direction edits, front arrival, opposite side, both actor images, direction-preserving pose choice, edit during playback, fixed/turn mode, encrypted save/reload and replay passed.');
}finally{await b.close();}})().catch(e=>{console.error(e);process.exit(1);});
