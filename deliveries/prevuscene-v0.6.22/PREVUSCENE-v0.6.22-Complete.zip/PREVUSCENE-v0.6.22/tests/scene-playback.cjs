const assert=require('node:assert/strict'),path=require('node:path');const pw=require(process.env.PLAYWRIGHT_MODULE||'playwright');
(async()=>{let args=['--no-sandbox'];if(process.env.CHROMIUM_PACKAGE_MODULE){const{default:c}=await import(process.env.CHROMIUM_PACKAGE_MODULE);args=c.args;}
const browser=await pw.chromium.launch({executablePath:process.env.BROWSER_EXECUTABLE,args,headless:true});const page=await browser.newPage({viewport:{width:1500,height:980}});const errors=[],alerts=[];page.on('pageerror',e=>errors.push(e.stack));page.on('dialog',d=>{alerts.push(d.message());return d.accept();});
try{
 await require('./legacy-controls.cjs')(page);await page.goto('file://'+path.resolve(__dirname,'../index.html'));await page.waitForFunction(()=>!!window.MS2D);await page.fill('#authUserName','تجربة القراءة');await page.fill('#authPassword','12345');await page.fill('#authConfirmPassword','12345');await page.click('#authSubmitBtn');await page.waitForFunction(()=>MS2DSecurity.isUnlocked());
 await page.locator('[data-type=actorMale]').dragTo(page.locator('#canvasContainer'));await page.waitForFunction(()=>MS2D.scene().objects.some(o=>o.type==='actor'));
 await page.evaluate(()=>{
  const template=clone(scene().objects.find(o=>o.type==='actor'));
  state.acts=[{id:'second-act',title:'الفصل الثاني',order:1},{id:'first-act',title:'الفصل الأول',order:0}];
  function make(id,act,x,end,duration){const sc=defaultScene(act);sc.id=id;sc.title=id;const o={...clone(template),id:id+'-actor',x,y:200,facing:225};sc.objects=[o];if(end!=null)sc.paths=[{id:id+'-movement',code:'M01',actorObjectId:o.id,type:'walk',duration,timingMode:'absolute',absoluteStart:0,direction:'forward',pathShape:'curve',curve:-40,x1:x,y1:200,x2:end,y2:200}];return sc;}
  const one=make('scene-one','first-act',100,200,1);one.duration=.05; // Three seconds includes a final-position hold.
  const two=make('scene-static','first-act',250,null,0);
  const three=make('scene-three','second-act',300,450,1.2);
  state.scenes=[three,one,two];state.currentSceneId=three.id;MS2D.renderAll();
 });
 await page.click('[data-tab=scenesTab]');await page.check('#respectSceneDuration');await page.screenshot({path:path.resolve(__dirname,'../PREVIEW-scene-reading.png')});await page.click('#readAllScenesBtn');
 await page.waitForFunction(()=>MS2D.scene().id==='scene-one');await page.waitForTimeout(180);assert.equal(await page.evaluate(()=>MS2D.scene().id),'scene-one');
 await page.waitForFunction(()=>MS2D.scene().id==='scene-static');assert.equal(await page.evaluate(()=>state.scenes.find(s=>s.id==='scene-one').objects[0].x),200);
 await page.waitForFunction(()=>MS2D.scene().id==='scene-three');await page.waitForFunction(()=>!ScenePlayback.isRunning());assert.equal(await page.evaluate(()=>MS2D.scene().objects[0].x),450);assert.equal(await page.evaluate(()=>simulationFrame),null);assert.equal(await page.evaluate(()=>MS2D.scene().objects[0].facing),225);assert.match(await page.locator('#sceneReadingStatus').textContent(),/3/);
 await page.evaluate(()=>DirectionStorage.saveLocal());await page.reload();await page.waitForFunction(()=>MS2DSecurity.isUnlocked()&&MS2D.scene().id==='scene-three');assert.equal(await page.evaluate(()=>MS2D.scene().objects[0].x),450);
 await page.click('[data-tab=scenesTab]');await page.click('#readFromSceneBtn');await page.waitForFunction(()=>!ScenePlayback.isRunning());assert.match(await page.locator('#sceneReadingStatus').textContent(),/1/);assert.equal(await page.evaluate(()=>MS2D.scene().id),'scene-three');
 // Stop mid-scene must cancel the entire chain and preserve the reached position.
 await page.evaluate(()=>{selectScene('scene-one');scene().paths[0].duration=2;scene().duration=0;scene().objects[0].x=100;renderAll();});await page.click('#readAllScenesBtn');await page.waitForTimeout(250);await page.click('#stopSceneReadingBtn');assert.equal(await page.evaluate(()=>ScenePlayback.isRunning()),false);const x=await page.evaluate(()=>MS2D.scene().objects[0].x);assert(x>100&&x<200);await page.waitForTimeout(350);assert.equal(await page.evaluate(()=>MS2D.scene().objects[0].x),x);assert.equal(await page.evaluate(()=>MS2D.scene().id),'scene-one');
 // Manual scene selection and standalone movement playback interrupt the chain.
 await page.click('#readAllScenesBtn');await page.waitForTimeout(80);await page.evaluate(()=>selectScene('scene-three'));assert.equal(await page.evaluate(()=>ScenePlayback.isRunning()),false);assert.equal(await page.evaluate(()=>simulationFrame),null);
 await page.click('#readAllScenesBtn');await page.waitForTimeout(80);await page.evaluate(()=>simulateAllMovements());assert.equal(await page.evaluate(()=>ScenePlayback.isRunning()),false);await page.evaluate(()=>stopSimulation());
 // Invalid timing references are reported before starting any scene.
 await page.evaluate(()=>{const p=state.scenes.find(s=>s.id==='scene-three').paths[0];p.timingMode='sequential';p.anchorMovementId='missing';});await page.click('#readAllScenesBtn');assert.equal(await page.evaluate(()=>ScenePlayback.isRunning()),false);assert.equal(await page.evaluate(()=>simulationFrame),null);assert(alerts.some(x=>x.includes('راجع توقيت')));
 assert.deepEqual(errors,[]);console.log('Scene reading: ordered acts/scenes, duration hold, static scenes, final-position save/reload, start from current, stop, manual selection, standalone interruption and invalid timing passed.');
}finally{await browser.close();}})().catch(e=>{console.error(e);process.exit(1);});
