const assert=require('node:assert/strict'),path=require('node:path');const pw=require(process.env.PLAYWRIGHT_MODULE||'playwright');
(async()=>{let args=['--no-sandbox'];if(process.env.CHROMIUM_PACKAGE_MODULE){const{default:c}=await import(process.env.CHROMIUM_PACKAGE_MODULE);args=c.args;}const b=await pw.chromium.launch({executablePath:process.env.BROWSER_EXECUTABLE,args,headless:true});const page=await b.newPage({viewport:{width:1500,height:980}});const errors=[];page.on('pageerror',e=>errors.push(e.stack));page.on('dialog',d=>{console.log('Dialog:',d.message());return d.accept();});try{
await require('./legacy-controls.cjs')(page);await page.goto('file://'+path.resolve(__dirname,'../index.html'),{waitUntil:'domcontentloaded',timeout:60000});await page.waitForFunction(()=>!!window.MS2D);await page.fill('#authUserName','أيقونات');await page.fill('#authPassword','12345');await page.fill('#authConfirmPassword','12345');await page.click('#authSubmitBtn');await page.waitForFunction(()=>MS2DSecurity.isUnlocked());
for(const gender of ['male','female']){
 await page.locator(`[data-type="${gender==='male'?'actorMale':'actorFemale'}"]`).dragTo(page.locator('#canvasContainer'));const o=await page.evaluate(()=>clone(selected()));const id=o.id;
 assert.equal(o.gender,gender);assert.equal(await page.inputValue('#objGender'),gender);assert.equal(await page.locator('#actorPosePicker button').count(),6);
 const selector=`[data-id="${id}"]`;
 for(const [facing,view] of [['0','front'],['90','side'],['180','back'],['270','side'],['45','side']]){
  await page.fill('#objFacing',facing);await page.locator('#objFacing').blur();assert.equal(await page.locator(selector+' .actor-sprite').getAttribute('data-view'),view);assert.equal(await page.locator(selector+' .actor-orientation').getAttribute('transform'),`rotate(${-Number(facing)})`);
 }
 for(const view of ['front','back','side','sitting','lying','crouching']){
  await page.click(`#actorPosePicker [data-view="${view}"]`);assert.equal(await page.locator(selector+' .actor-sprite').getAttribute('data-view'),view);
  const object=await page.evaluate(id=>clone(scene().objects.find(o=>o.id===id)),id);assert.equal(object.x,o.x);assert.equal(object.y,o.y);assert.equal(object.w,o.w);assert.equal(object.h,o.h);
 }
 await page.selectOption('#objActorVisual','diagram');assert.equal(await page.locator(selector+' .actor-sprite').count(),0);await page.selectOption('#objActorVisual','illustrated');assert.equal(await page.locator(selector+' .actor-sprite').count(),1);
 await page.selectOption('#objPose','kneeling');assert.equal(await page.locator(selector+' .actor-sprite').count(),0);await page.selectOption('#objPose','standing');assert.equal(await page.locator(selector+' .actor-sprite').count(),1);
}
await page.evaluate(()=>DirectionStorage.saveLocal());await page.reload({waitUntil:'domcontentloaded',timeout:60000});await page.waitForFunction(()=>MS2DSecurity.isUnlocked()&&scene().objects.length===2);assert.equal(await page.locator('.stage-object .actor-sprite').count(),2);
// Visual verification board with all six source views for both genders.
await page.evaluate(()=>{
 const templates=clone(scene().objects);scene().objects=[];for(let row=0;row<2;row++)for(let col=0;col<6;col++){
  const choices=[['standing',0],['standing',180],['side',90],['sitting',90],['lyingBack',0],['crouching',90]],o={...clone(templates[row]),id:crypto.randomUUID(),x:90+col*160,y:180+row*250,w:80,h:130,pose:choices[col][0],facing:choices[col][1],symbol:String(col+1)};scene().objects.push(o);
 }selectedId=scene().objects.at(-1).id;renderAll();fit();});
assert.ok(await page.locator('.stage-object .actor-sprite path').count()>100);console.log('Views, facing and save/reload passed; exporting vector stage.');await page.screenshot({path:path.resolve(__dirname,'../PREVIEW-actor-poses.png'),animations:'disabled',timeout:60000});const downloadPromise=page.waitForEvent('download',{timeout:90000});downloadPromise.catch(()=>{});await page.evaluate(()=>$('exportBtn').click());const download=await downloadPromise;await download.saveAs(path.resolve(__dirname,'../PREVIEW-actors-export.png'));
await page.waitForTimeout(300);await page.screenshot({path:path.resolve(__dirname,'../PREVIEW-actor-poses.png'),animations:'disabled',timeout:60000});assert.deepEqual(errors,[]);console.log('Actor images: original drag/drop, both genders, six source views, facing/mirroring, fixed coordinates/dimensions, diagram fallback and encrypted save/reload passed.');
}finally{await b.close();}})().catch(e=>{console.error(e);process.exit(1);});
