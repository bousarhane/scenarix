// Core regression tests expose optional controls; workspace.cjs checks the collapsed UI.
module.exports=async page=>{if(page.__legacyControls)return;page.__legacyControls=true;await page.addInitScript(()=>document.addEventListener('DOMContentLoaded',()=>document.querySelectorAll('details:not(#projectMenu)').forEach(d=>d.open=true)));};
