// Pass PROJECT_TEST_FILE and PROJECT_TEST_PASSWORD to test an encrypted user project.
// Neither the project nor the password is embedded in this package.
const assert=require('node:assert/strict'),path=require('node:path'),fs=require('node:fs');const pw=require(process.env.PLAYWRIGHT_MODULE||'playwright');
(async()=>{
 const file=process.env.PROJECT_TEST_FILE,password=process.env.PROJECT_TEST_PASSWORD;if(!file||!password)throw Error('Provide PROJECT_TEST_FILE and PROJECT_TEST_PASSWORD.');
 const envelope=JSON.parse(fs.readFileSync(file,'utf8'));let args=['--no-sandbox'];if(process.env.CHROMIUM_PACKAGE_MODULE){const{default:c}=await import(process.env.CHROMIUM_PACKAGE_MODULE);args=c.args;}
 const b=await pw.chromium.launch({executablePath:process.env.BROWSER_EXECUTABLE,args,headless:true});const page=await b.newPage({viewport:{width:1500,height:980},acceptDownloads:true});const errors=[];page.on('pageerror',e=>errors.push(e.stack));page.on('dialog',d=>d.accept());
 try{
 await require('./legacy-controls.cjs')(page);await page.goto('file://'+path.resolve(__dirname,'../index.html'));await page.waitForFunction(()=>!!window.MS2D);await page.fill('#authUserName',envelope.ownerName);await page.fill('#authPassword',password);await page.fill('#authConfirmPassword',password);await page.click('#authSubmitBtn');await page.waitForFunction(()=>MS2DSecurity.isUnlocked());
 const chooser=page.waitForEvent('filechooser');await page.click('#openProjectBtn');await(await chooser).setFiles(file);await page.waitForFunction(()=>state.scenes.length===3);
 const initial=await page.evaluate(()=>clone(state));assert.equal(initial.scenes.reduce((n,s)=>n+s.paths.length,0),14);assert(initial.scenes.every(s=>typeof s.actId==='string'&&initial.acts.some(a=>a.id===s.actId)));
 await page.click('[data-tab=scenesTab]');assert.equal(await page.locator('#actsTree .tree-scene').count(),3);assert.equal(await page.isChecked('#respectSceneDuration'),false);
 // Drive the real imported schedules, observing visible motion in every scene.
 await page.click('#readAllScenesBtn');
 for(let i=0;i<initial.scenes.length;i++){
  const sc=initial.scenes[i];await page.waitForFunction(id=>MS2D.scene().id===id,sc.id);
  const actorId=sc.paths[0].actorObjectId;
  const first=await page.locator('[data-id="'+actorId+'"]').getAttribute('transform');
  await page.waitForFunction(({sceneId,actorId,first})=>MS2D.scene().id===sceneId&&!!simulationFrame&&layerGroup('actors')?.querySelector(`[data-id="${actorId}"]`)?.getAttribute('transform')!==first,{sceneId:sc.id,actorId,first},{timeout:15000});
  const second=await page.locator('[data-id="'+actorId+'"]').getAttribute('transform');assert.notEqual(first,second,'Actor must visibly move in scene '+(i+1));
 }
 await page.waitForFunction(()=>!ScenePlayback.isRunning(),{},{timeout:35000});const after=await page.evaluate(()=>clone(state));
 assert.equal(after.scenes.reduce((n,s)=>n+s.paths.length,0),14);
 for(let i=0;i<initial.scenes.length;i++){
  assert.deepEqual(after.scenes[i].paths,initial.scenes[i].paths,'Playback preserves authored paths and timing.');
  const latest=new Map();for(const item of await page.evaluate(paths=>compileMovementSchedule(paths).map(i=>({path:i.path,end:i.end})),after.scenes[i].paths)){const prev=latest.get(item.path.actorObjectId);if(!prev||item.end>prev.end)latest.set(item.path.actorObjectId,item);}
  for(const [id,item] of latest){const o=after.scenes[i].objects.find(o=>o.id===id);assert.equal(o.x,item.path.x2);assert.equal(o.y,item.path.y2);}
 }
 await page.evaluate(()=>DirectionStorage.saveLocal());await page.reload();await page.waitForFunction(()=>MS2DSecurity.isUnlocked()&&state.scenes.length===3);assert.equal(await page.evaluate(()=>state.scenes.reduce((n,s)=>n+s.paths.length,0)),14);assert(await page.evaluate(()=>state.scenes.every(s=>typeof s.actId==='string')));
 // Reproduce the original creation bug through the actual footer button.
 await page.click('#addSceneBtn');await page.waitForFunction(()=>document.querySelector('#sceneContinuityDialog').open);await page.click('#confirmContinuityBtn');await page.waitForFunction(()=>state.scenes.length===4);assert.equal(await page.evaluate(()=>typeof MS2D.scene().actId),'string');assert.equal(await page.locator('#actsTree .tree-scene').count(),4);
 assert.deepEqual(errors,[]);console.log('Actual encrypted project: all 3 scenes / 14 movements included, visible animation in each, endpoints, unchanged paths/timing, encrypted save/reload and footer scene creation passed.');
 }finally{await b.close();}
})().catch(e=>{console.error(e);process.exit(1);});
