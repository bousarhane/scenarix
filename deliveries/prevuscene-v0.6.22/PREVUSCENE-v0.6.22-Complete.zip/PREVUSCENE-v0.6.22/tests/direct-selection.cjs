const assert=require('node:assert/strict'),path=require('node:path');const pw=require(process.env.PLAYWRIGHT_MODULE||'playwright');
(async()=>{let args=['--no-sandbox'];if(process.env.CHROMIUM_PACKAGE_MODULE){const{default:c}=await import(process.env.CHROMIUM_PACKAGE_MODULE);args=c.args;}const b=await pw.chromium.launch({executablePath:process.env.BROWSER_EXECUTABLE,args,headless:true});const page=await b.newPage({viewport:{width:1500,height:980},hasTouch:true});const errors=[];page.on('pageerror',e=>errors.push(e.stack));page.on('dialog',d=>d.accept());try{
await require('./legacy-controls.cjs')(page);await page.goto('file://'+path.resolve(process.env.APP_DIR||path.resolve(__dirname,'..'),'index.html'));await page.waitForFunction(()=>!!window.MS2D);await page.fill('#authUserName','أيقونات');await page.fill('#authPassword','12345');await page.fill('#authConfirmPassword','12345');await page.click('#authSubmitBtn');await page.waitForFunction(()=>MS2DSecurity.isUnlocked());

await page.locator('[data-type="actorMale"]').dragTo(page.locator('#canvasContainer'));
const id=await page.evaluate(()=>selectedId);
async function setup(pose='standing',facing=0,gender='male',actorVisual='illustrated'){
 await page.evaluate(({id,pose,facing,gender,actorVisual})=>{const o=scene().objects.find(o=>o.id===id);Object.assign(o,{x:300,y:250,pose,facing,gender,actorVisual});o.initialState=ActorContinuity.stateOf(o);o.stateChanges=[];scene().paths=[];selectedId=null;selectedPathId=null;tool='select';renderScene();},{id,pose,facing,gender,actorVisual});
}
async function screen(x,y){return page.evaluate(({x,y})=>{const m=viewport.getScreenCTM();return{x:m.a*x+m.c*y+m.e,y:m.b*x+m.d*y+m.f};},{x,y});}
async function click(x,y){const pt=await screen(x,y);await page.mouse.click(pt.x,pt.y);}
await setup('side',90);await click(300,230);
assert.equal(await page.evaluate(()=>selectedId),id,'Clicking an actor body must select it');
for(const gender of ['male','female'])for(const [pose,facing] of [['standing',0],['standing',180],['side',90],['side',270],['sitting',90],['crouching',270],['lyingBack',0]]){
 await setup(pose,facing,gender);await click(320,230);assert.equal(await page.evaluate(()=>selectedId),id,`${gender} ${pose} must be selectable across its image viewport`);
 assert.equal(await page.locator(`[data-id="${id}"]`).getAttribute('class').then(s=>s.includes('selected')),true);
 assert.equal(await page.inputValue('#objFacing'),String(facing));
}
await setup('lyingBack');await click(343,250);assert.equal(await page.evaluate(()=>selectedId),id,'Lying figure protruding beyond nominal width remains clickable');
await setup();await page.evaluate(id=>{scene().paths=[{id:'route',code:'M01',actorObjectId:id,pathShape:'straight',direction:'forward',duration:.4,x1:100,y1:250,x2:300,y2:250}];renderScene();},id);
await click(300,250);assert.equal(await page.evaluate(()=>selectedId),id,'Movement endpoint over actor must not swallow selection');
await click(285,250);assert.equal(await page.evaluate(()=>selectedId),id,'Movement stroke over actor must not take selection');
await click(150,250);assert.equal(await page.evaluate(()=>selectedPathId),'route','Movement is still selectable away from actors');
await click(700,400);assert.equal(await page.evaluate(()=>selectedId),null);assert.equal(await page.evaluate(()=>selectedPathId),null);
// Mouse dragging from the visible body keeps path data intact and can be undone.
const before=await page.evaluate(()=>JSON.stringify(scene().paths));const a=await screen(300,230),bpt=await screen(350,260);
await page.mouse.move(a.x,a.y);await page.mouse.down();await page.mouse.move(bpt.x,bpt.y,{steps:5});await page.mouse.up();
const moved=await page.evaluate(id=>clone(scene().objects.find(o=>o.id===id)),id);assert(Math.abs(moved.x-350)<.01);assert(Math.abs(moved.y-280)<.01);assert.equal(await page.evaluate(()=>JSON.stringify(scene().paths)),before);
await page.click('#undoBtn');assert.equal(await page.evaluate(id=>scene().objects.find(o=>o.id===id).x,id),300);
// Touch and schematic representations use the same direct selection.
await setup('side',270,'neutral','diagram');let pt=await screen(320,230);await page.touchscreen.tap(pt.x,pt.y);assert.equal(await page.evaluate(()=>selectedId),id);
await setup();await page.evaluate(()=>{zoom=.45;renderStage();});await click(300,230);assert.equal(await page.evaluate(()=>selectedId),id);await page.evaluate(()=>fit());
await page.evaluate(()=>{layer('actors').locked=true;selectedId=null;renderScene();});await click(300,230);assert.equal(await page.evaluate(()=>selectedId),null);
await page.evaluate(()=>{layer('actors').locked=false;layer('actors').visible=false;renderScene();});await click(300,230);assert.equal(await page.evaluate(()=>selectedId),null);
await page.evaluate(()=>{layer('actors').visible=true;renderScene();});await click(300,230);assert.equal(await page.evaluate(()=>selectedId),id);
await page.screenshot({path:path.resolve(__dirname,'../PREVIEW-direct-selection.png')});
assert.deepEqual(errors,[]);console.log('Direct selection: body/transparent icon area, both genders, all pictured poses/directions, lying width, overlapping movement endpoints/strokes, path selection, empty stage, drag/undo, touch, zoom, locked/hidden layer passed.');
}finally{await b.close();}})().catch(e=>{console.error(e);process.exit(1);});
