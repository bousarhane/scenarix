const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('stageAPI', {
  saveProject: (payload) => ipcRenderer.invoke('project:save', payload),
  openProject: () => ipcRenderer.invoke('project:open'),
  exportPNG: (payload) => ipcRenderer.invoke('export:png', payload),
  print: () => ipcRenderer.invoke('app:print')
});
