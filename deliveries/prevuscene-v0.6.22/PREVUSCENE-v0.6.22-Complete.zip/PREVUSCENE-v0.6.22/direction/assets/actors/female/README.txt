ستة أوضاع متجهية بخلفية شفافة. افتح preview.html لتغيير الألوان وتنزيل SVG ملون.
للاستخدام داخل التطبيق، ضمّن SVG في DOM واستعمل:
svg.style.setProperty("--shirt-color", "#e63946");
svg.style.setProperty("--trousers-color", "#252525");
أو عدّل fill للعناصر data-part="shirt" وdata-part="trousers" واحذف style منها.
متغيرات CSS لا تنتقل من الصفحة إلى SVG المحمّل عبر img؛ استعمل SVG مضمّنًا أو عدّل الملف قبل تحميله.
الرسوم محوّلة إلى مسارات متجهية من الصور المرجعية مع تبسيط التفاصيل الصغيرة.
