// Compatibility entry point; the application's bridge is defined once at the root.
require('../preload.js');
