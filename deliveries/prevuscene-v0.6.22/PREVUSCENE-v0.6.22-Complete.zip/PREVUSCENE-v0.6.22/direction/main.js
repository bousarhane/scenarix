// One Electron entry point for both launch locations.
require('../main.js');
