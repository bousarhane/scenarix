'use strict';
// Repairs the original workspace without replacing any of its panels or assets.
function normalFacing(v){return ((Number(v)||0)%360+360)%360;}
function remapDuplicatedScene(s){
 const snapshots=[s,...(s.openingSnapshot?[s.openingSnapshot]:[]),...(s.states||[]),...(s.tableaux||[]),...(s.versions||[])];
 const objectIds=new Map([...new Set(snapshots.flatMap(v=>(v.objects||[]).map(o=>o.id)))].map(id=>[id,crypto.randomUUID()]));
 const pathIds=new Map([...new Set(snapshots.flatMap(v=>(v.paths||[]).map(p=>p.id)))].map(id=>[id,crypto.randomUUID()]));
 const remapSupport=b=>{if(b?.targetId)b.targetId=objectIds.get(b.targetId)||b.targetId;};
 const remapArms=arms=>{const visit=g=>{if(!g)return;if(g.targetId)g.targetId=objectIds.get(g.targetId)||g.targetId;visit(g.from);visit(g.to);};for(const g of Object.values(arms||{}))visit(g);};
 const remapBody=body=>{if(!body)return;remapSupport(body.fromSupport);remapSupport(body.toSupport);if(body.seatTargetId)body.seatTargetId=objectIds.get(body.seatTargetId)||body.seatTargetId;remapBody(body.fromState);};
 for(const o of s.objects||[]){o.id=objectIds.get(o.id);remapSupport(o.support);remapBody(o.poseTransition);remapArms(o.arms);if(o.initialState){remapSupport(o.initialState.support);remapBody(o.initialState.poseTransition);remapArms(o.initialState.arms);}for(const e of o.stateChanges||[]){e.id=crypto.randomUUID();e.afterMovementId=pathIds.get(e.afterMovementId)||e.afterMovementId;if(e.atMovementId)e.atMovementId=pathIds.get(e.atMovementId)||e.atMovementId;if(e.forActionId)e.forActionId=pathIds.get(e.forActionId)||e.forActionId;remapSupport(e.value?.support);remapBody(e.value?.poseTransition);remapArms(e.value?.arms);}}
 for(const p of s.paths||[]){remapSupport(p.startSupport);remapBody(p.startBodyState);remapArms(p.startArms);if(p.travelTargetId)p.travelTargetId=objectIds.get(p.travelTargetId)||p.travelTargetId;if(p.gestureTargetId)p.gestureTargetId=objectIds.get(p.gestureTargetId)||p.gestureTargetId;const old=p.id;p.id=pathIds.get(old);p.actorObjectId=objectIds.get(p.actorObjectId)||p.actorObjectId||null;p.lookTargetId=objectIds.get(p.lookTargetId)||p.lookTargetId||null;p.endTargetId=objectIds.get(p.endTargetId)||p.endTargetId||null;if(p.anchorMovementId)p.anchorMovementId=pathIds.get(p.anchorMovementId)||p.anchorMovementId;}
 const remapSnapshot=snap=>{if(!snap)return;for(const o of snap.objects||[]){o.id=objectIds.get(o.id)||o.id;remapSupport(o.support);remapBody(o.poseTransition);remapArms(o.arms);if(o.initialState){remapSupport(o.initialState.support);remapBody(o.initialState.poseTransition);remapArms(o.initialState.arms);}for(const e of o.stateChanges||[]){e.id=crypto.randomUUID();e.afterMovementId=pathIds.get(e.afterMovementId)||e.afterMovementId;if(e.atMovementId)e.atMovementId=pathIds.get(e.atMovementId)||e.atMovementId;if(e.forActionId)e.forActionId=pathIds.get(e.forActionId)||e.forActionId;remapSupport(e.value?.support);remapBody(e.value?.poseTransition);remapArms(e.value?.arms);}}for(const p of snap.paths||[]){remapSupport(p.startSupport);remapBody(p.startBodyState);remapArms(p.startArms);if(p.travelTargetId)p.travelTargetId=objectIds.get(p.travelTargetId)||p.travelTargetId;if(p.gestureTargetId)p.gestureTargetId=objectIds.get(p.gestureTargetId)||p.gestureTargetId;p.id=pathIds.get(p.id)||p.id;p.actorObjectId=objectIds.get(p.actorObjectId)||p.actorObjectId;p.lookTargetId=objectIds.get(p.lookTargetId)||p.lookTargetId||null;p.endTargetId=objectIds.get(p.endTargetId)||p.endTargetId;if(p.anchorMovementId)p.anchorMovementId=pathIds.get(p.anchorMovementId)||p.anchorMovementId;}};
 remapSnapshot(s.openingSnapshot);for(const list of [s.states||[],s.tableaux||[],s.versions||[]])for(const snap of list){snap.id=crypto.randomUUID();remapSnapshot(snap);}s.continuity=null;
 if(s.openingSnapshot)s.openingSnapshot.currentSignature=tinyHash(stableStringify({ambientLight:s.ambientLight,objects:(s.openingSnapshot.objects||[]).map(continuityObjectView)}));
}
function validateDirectionProject(value){
 if(!value||typeof value!=='object'||!Array.isArray(value.scenes)||!value.scenes.length||!value.stage||!value.project)throw new Error('ملف المشروع لا يحتوي بنية إخراج صالحة.');
 if(!Number.isFinite(Number(value.stage.width))||Number(value.stage.width)<=0||!Number.isFinite(Number(value.stage.depth))||Number(value.stage.depth)<=0)throw new Error('أبعاد الخشبة غير صالحة.');
 const copy=clone(value),ids=new Set();
 for(const sc of copy.scenes){if(!sc||!sc.id||ids.has(sc.id)||!Array.isArray(sc.objects)||!Array.isArray(sc.paths))throw new Error('بيانات المشاهد غير صالحة.');ids.add(sc.id);const objects=new Set(),paths=new Set();for(const o of sc.objects){if(!o||!o.id||objects.has(o.id)||!Number.isFinite(Number(o.x))||!Number.isFinite(Number(o.y)))throw new Error('بيانات عناصر الخشبة غير صالحة.');objects.add(o.id);}for(const p of sc.paths){if(!p||!p.id||paths.has(p.id))throw new Error('بيانات مسارات الحركة غير صالحة.');paths.add(p.id);}}
 if(!ids.has(copy.currentSceneId))copy.currentSceneId=copy.scenes[0].id;
 return copy;
}
// Keep UI hooks refreshed after scene switches and undo without changing the layout.
const originalRenderAll=renderAll;renderAll=function(){originalRenderAll();window.MS2DBlocking?.syncForm();window.MS2DRehearsal?.render();if($('ambientLight')){$('ambientLight').value=scene().ambientLight;$('ambientLightValue').textContent=scene().ambientLight+'%';}};
window.MS2D.renderAll=renderAll;
window.DirectionRepairs={normalFacing,remapDuplicatedScene,validateDirectionProject};
window.addEventListener('keydown',ev=>{if(ev.key==='Escape'&&tool==='path'){tool='select';pathStart=null;pendingMovement=null;$('selectTool').classList.add('active');$('pathTool').classList.remove('active');$('statusText').textContent='أُلغي الرسم؛ الحركة الأصلية محفوظة';}});
