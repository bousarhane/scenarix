'use strict';
// Names prepare effects once; subsequent edits remain the director's authored choices.
(function(){
 let durationEdited=false;const defaultDuration=$('newMoveDuration').value;
 $('newMoveDuration').addEventListener('input',()=>{durationEdited=true;});
 for(const id of ['chooseTranslationBtn','choosePostureBtn'])$(id).addEventListener('click',()=>{durationEdited=false;},true);
 const poses={sit:'sitting',stand:'standing',kneel:'kneeling',crouch:'crouching',bend:'bending',fall:'lyingBack'};
 const names={custom:'وضعية أختارها',sit:'جلوس',stand:'نهوض',turn:'استدارة',kneel:'ركوع',crouch:'قرفصاء',bend:'انحناء',fall:'استلقاء / سقوط'};
 const typeLabel=movementTypeLabel;movementTypeLabel=v=>({crouch:'قرفصاء',bend:'انحناء'}[v]||typeLabel(v));
 const kindLabel=actionKindLabel;actionKindLabel=p=>p.bodyPreset&&p.bodyPreset!=='custom'?names[p.bodyPreset]+' — '+kindLabel(p):kindLabel(p);
 for(const prefix of ['newMove','move']){
  for(const v of ['crouch','bend'])$(prefix+'Type').append(new Option(names[v],v));
  const field=document.createElement('label');field.innerHTML=`الفعل الجسدي<select id="${prefix}BodyPreset"></select><small>اختيار الفعل يجهّز أثره؛ يمكنك تعديل وضعية البداية والنهاية والتوقيت بعد ذلك.</small>`;
  $(prefix+'StartPose').closest('fieldset').querySelector('legend').after(field);
  for(const [value,label] of Object.entries(names))$(prefix+'BodyPreset').append(new Option(label,value));
  $(prefix+'BodyPreset').onchange=()=>apply(prefix,$(prefix+'BodyPreset').value);
  $(prefix+'Type').addEventListener('change',()=>{const v=$(prefix+'Type').value;if(poses[v]||v==='turn')apply(prefix,v);else if(prefix==='newMove'&&!durationEdited&&['walk','run'].includes(v))$(prefix+'Duration').value=v==='run'?Math.max(.1,Number(defaultDuration)*.6):defaultDuration;});
 }
 function apply(prefix,v){
  if(v==='custom')return;
  const actor=scene().objects.find(o=>o.id===$(prefix+'Actor').value);
  const spatial=$(prefix+'Shape').value!=='stationary';
  if(spatial&&$(prefix+'ActionKind').value==='translate'){
   if(v==='turn'){$(prefix+'PostureMode').value='turn';$(prefix+'PostureMode').onchange();}
   else{$(prefix+'TranslationBody').checked=true;$(prefix+'TranslationBody').onchange();}
  }else if(v==='turn'&&$(prefix+'ActionKind').value==='pose'){$(prefix+'PostureMode').value='turn';$(prefix+'PostureMode').onchange();}
  else if(v!=='turn'&&$(prefix+'ActionKind').value==='turn'){$(prefix+'PostureMode').value='pose';$(prefix+'PostureMode').onchange();}
  $(prefix+'BodyPreset').value=v;$(prefix+'Type').value=Array.from($(prefix+'Type').options).some(o=>o.value===v)?v:'walk';
  if(v==='turn'){
   $(prefix+'EndPose').value=$(prefix+'StartPose').value;$(prefix+'FacingMode').value='turn';$(prefix+'EndFacing').value=normalFacing(Number($(prefix+'StartFacing').value)+90);$(prefix+'OrientationChoice').value='custom';
  }else{
   if(v==='stand'&&!['sitting','floorSitting','crouching','kneeling'].includes($(prefix+'StartPose').value))$(prefix+'StartPose').value='sitting';
   $(prefix+'EndPose').value=poses[v];$(prefix+'PoseInterpolation').value='smooth';$(prefix+'PoseAt').value=0;$(prefix+'PoseEndAt').value=100;
   // A bodily action does not imply a change of gaze.
   $(prefix+'FacingMode').value='fixed';$(prefix+'EndFacing').value=$(prefix+'StartFacing').value;$(prefix+'OrientationChoice').value='fixed';
   const target=$(prefix+'EndTarget'),selectedTarget=target.value;target.replaceChildren(new Option('غير مرتبط',''));
   for(const o of scene().objects.filter(o=>StageSupport.allowed(o,poses[v])))target.append(new Option(o.name,o.id));target.value=selectedTarget||((v==='sit'&&actor?.support?.targetId)||'');
  }
  TheatricalActions.updateControls(prefix);
  $(prefix+'EndFacing').closest('label').hidden=v!=='turn';
  if(prefix==='move'){TheatricalActions.saveActionEdit();const p=currentMovement();if(p)p.bodyPreset=v;}
 }
 const fill=fillChoreo;fillChoreo=function(prefix,p,o){fill(prefix,p,o);$(prefix+'BodyPreset').value=p.bodyPreset||'custom';};
 const read=readChoreo;readChoreo=function(prefix){return{...read(prefix),bodyPreset:$(prefix+'BodyPreset').value};};
 const data=applyChoreographyData;applyChoreographyData=function(p,d){data(p,d);p.bodyPreset=d.bodyPreset||'custom';};
 // Gait exists only during the actor's active spatial channel, not before/after it.
 const sample=sampleActorActions;sampleActorActions=function(list,sec,o,resolve){
  const result=sample(list,sec,o,resolve),item=chooseChannelAction(list,sec,'position');
  if(item&&sec>=item.start&&sec<item.end&&item.track.getTotalLength()>1){const type=item.path.type==='run'?'run':item.path.type==='backward'?'backward':'walk',speed={slow:.7,normal:1,fast:1.35}[item.path.speed]||1;result.gait={type,phase:(sec-item.start)*(type==='run'?11:7)*speed};}
  return result;
 };
 function updateGait(g,o){
  const sprite=g.querySelector('.actor-sprite');let feet=g.querySelector('.actor-gait');
  if(sprite&&!Object.hasOwn(sprite.dataset,'gaitBaseTransform'))sprite.dataset.gaitBaseTransform=sprite.getAttribute('transform')||'';
  if(!o.gait){feet?.remove();if(sprite){const base=sprite.dataset.gaitBaseTransform;if(base)sprite.setAttribute('transform',base);else sprite.removeAttribute('transform');}return;}
  const run=o.gait.type==='run',phase=o.gait.phase,bob=Math.abs(Math.sin(phase))*(run?5:2),stride=Math.sin(phase)*(run?16:8),y=(Number(o.h)||90)/2;
  if(sprite)sprite.setAttribute('transform',`translate(0 ${-bob}) ${sprite.dataset.gaitBaseTransform}`);
  if(!feet){feet=svgEl('g',{class:'actor-gait','pointer-events':'none'});feet.append(svgEl('ellipse',{cx:-9,rx:4}),svgEl('ellipse',{cx:9,rx:4}));g.append(feet);}
  feet.dataset.gait=o.gait.type;Array.from(feet.children).forEach((foot,i)=>{foot.setAttribute('cy',y+(i===0?stride:-stride));foot.setAttribute('ry',run?8:5);foot.setAttribute('fill',o.color||'#168bc2');});
 }
 window.ActorGait={update:updateGait};
 const shapeBefore=shape;shape=function(o){const g=shapeBefore(o);if(o.gait)updateGait(g,o);return g;};
})();
