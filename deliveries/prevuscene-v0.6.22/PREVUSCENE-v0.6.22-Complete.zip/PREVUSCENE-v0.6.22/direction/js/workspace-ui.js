'use strict';
// Presentation only: retain the existing elements, handlers and directing engine.
(function(){
 const library=$('libraryPanel'),tabs=library.querySelector('.tabs');
 const tab=id=>library.querySelector(`.tab[data-tab="${id}"]`);
 const activate=id=>{const b=tab(id);if(b)b.click();library.scrollTop=0;};
 function fold(parent,title,id){const d=document.createElement('details');if(id)d.id=id;const s=document.createElement('summary');s.textContent=title;d.append(s);parent.append(d);return d;}
 function pack(parent,title,nodes,id){const d=fold(parent,title,id);for(const n of nodes)if(n)d.append(n);return d;}
 // Three primary libraries, with directing and administration below them.
 const people=document.createElement('section');people.id='performerLibraryTab';people.className='tab-panel';
 people.innerHTML='<h2>الممثلون</h2><p class="hint">اسحب الممثل أو الممثلة إلى موقعه على الخشبة. حدده لتغيير الوضع والاتجاه.</p>';
 const peopleCards=$('elementsTab').querySelector('details');peopleCards.querySelector('summary').textContent='أيقونات الممثلين';people.append(peopleCards);
 const registry=document.createElement('button');registry.textContent='بطاقات الشخصيات وأسماء الممثلين';registry.className='full';registry.onclick=()=>{more.open=true;activate('actorsTab');};people.append(registry);library.append(people);
 const peopleTab=document.createElement('button');peopleTab.className='tab';peopleTab.dataset.tab=people.id;peopleTab.textContent='الممثلون';peopleTab.onclick=()=>{library.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b===peopleTab));library.querySelectorAll('.tab-panel').forEach(p=>p.classList.toggle('active',p===people));library.scrollTop=0;};
 const mainNav=document.createElement('nav');mainNav.className='component-nav';mainNav.setAttribute('aria-label','مكونات الخشبة');library.prepend(mainNav);
 mainNav.append(tab('stageTab'),peopleTab,tab('elementsTab'));
 const label=document.createElement('h2');label.textContent='مكونات المشهد';library.prepend(label);
 const workNav=document.createElement('nav');workNav.className='work-nav';workNav.append(tab('movementTab'),tab('scenesTab'));mainNav.after(workNav);
 const more=fold(library,'أدوات المشهد والإدارة','workspaceMore');more.append(tabs);
 for(const d of $('elementsTab').querySelectorAll('details'))d.open=false;
 $('elementsTab').querySelector('details').open=true;
 // Props are a separate scenic category, rather than mixed with exterior scenery.
 const prop=$('elementsTab').querySelector('[data-type="prop"]');pack($('elementsTab'),'الإكسسوارات — PROP',[],'propLibrary');const propCards=document.createElement('div');propCards.className='cards';propCards.append(prop);$('propLibrary').append(propCards);
 // Existing movement/select tools move next to their actual workspace.
 const tools=$('pathTool').closest('details');const toolBar=document.createElement('div');toolBar.className='directing-tools';toolBar.append($('selectTool'),$('pathTool'));tools.remove();
 const play=document.createElement('button');play.id='workspacePlay';play.className='accent';play.textContent='▶ قراءة المشهد';play.onclick=()=>simulateAllMovements();
 const stop=document.createElement('button');stop.id='workspaceStop';stop.textContent='■ إيقاف';stop.onclick=()=>stopSimulation();
 toolBar.append(play,stop);$('canvasContainer').before(toolBar);
 // Keep measurements prominent and background/grid/presets behind a disclosure.
 const stage=$('stageTab');const stageAdvanced=fold(stage,'الشبكة والصورة المرجعية','stageAdvanced');
 const children=[...stage.children],hr=children.findIndex(n=>n.tagName==='HR');
 if(hr>=0)for(const n of children.slice(hr))if(n!==stageAdvanced)stageAdvanced.append(n);
 stageAdvanced.append(stage.querySelector('.preset-grid'),$('gridSize').closest('label'));
 const heightLabel=document.createElement('label');heightLabel.textContent='الارتفاع المتاح بالمتر';const height=document.createElement('input');height.id='stageHeight';height.type='number';height.min='1';height.step='.5';height.value=state.stage.height||4;heightLabel.append(height);$('applyStageBtn').before(heightLabel);
 const depthLabel=$('stageDepth').closest('label');depthLabel.firstChild.textContent='الطول / العمق بالمتر';
 const apply=$('applyStageBtn').onclick;$('applyStageBtn').onclick=()=>{const inputs=[$('stageWidth'),$('stageDepth'),height,$('gridSize')];if(inputs.some(i=>!i.checkValidity()||!Number.isFinite(Number(i.value))||Number(i.value)<=0)){inputs.find(i=>!i.checkValidity()||Number(i.value)<=0)?.reportValidity();return;}const value=Number(height.value);apply();state.stage.height=value;height.value=value;mark('حُفظت قياسات الخشبة');};
 // Contextual inspector: visible essentials and optional detailed metadata.
 const form=$('selectionForm'),actor=$('actorProperties');
 pack(form,'الموقع والقياسات وتفاصيل العنصر',[$('objLayer').closest('label'),$('objX').closest('.two'),$('objRotation').closest('label'),$('objNotes').closest('label'),$('bringFrontBtn').closest('.row')],'objectDetails');
 pack(actor,'بطاقة الشخصية وتفاصيلها',[$('objActorCard').closest('label'),$('objActorName').closest('label'),$('objSymbol').closest('.two'),$('objActorVisual').closest('label'),$('objFacing').closest('label'),$('objEntrance').closest('.two'),$('objIntention').closest('label'),$('objLookTarget').closest('label'),$('objCostume').closest('label'),$('objAccessories').closest('label')],'actorDetails');
 const opening=$('initialActorPose')?.closest('fieldset');if(opening)pack(form,'حالة البداية ونقاط التغيير',[opening],'openingDetails');
 const inspector=$('propertiesPanel'),sceneHead=[...inspector.children].find(n=>n.tagName==='H2'&&n.textContent==='بيانات المشهد');
 if(sceneHead){const all=[...inspector.children],a=all.indexOf(sceneHead),b=all.findIndex(n=>n.tagName==='H2'&&n.textContent==='قائمة العناصر');pack(inspector,'بيانات المشهد',all.slice(a,b>0?b:a+1),'sceneDetails');if(b>0)pack(inspector,'العناصر الموجودة على الخشبة',all.slice(b),'stageObjectDetails');}
 inspector.querySelectorAll(':scope > hr').forEach(n=>n.remove());
 // Preserve all toolbar actions while reducing the always-visible header.
 const toolbar=document.querySelector('.toolbar'),menu=fold(toolbar,'المشروع والتصدير','projectMenu');menu.classList.add('workspace-menu');
 for(const id of ['projectDataBtn','newProjectBtn','saveAsBtn','exportBtn','printBtn','openLightingWorkspaceBtn','logoutBtn'])menu.append($(id));
 const render=renderAll;renderAll=function(){render();height.value=state.stage.height||4;};
 activate(people.id);requestAnimationFrame(fit);
})();
