'use strict';
// Pointer drawing and transactional editing. Geometry never writes facing or timing.
(function(){
 let interaction=null,overlay=null;
 const host=svg.parentElement;
 const point=ev=>{const p=stagePoint(ev);return{x:clamp(p.x,0,m2p(state.stage.width)),y:clamp(p.y,0,m2p(state.stage.depth))};};
 const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
 function smooth(points){
  const kept=[points[0]];for(const p of points.slice(1,-1))if(distance(p,kept.at(-1))>=5)kept.push(p);kept.push(points.at(-1));
  return kept.map((p,i)=>i===0||i===kept.length-1?{...p}:{x:(kept[i-1].x+2*p.x+kept[i+1].x)/4,y:(kept[i-1].y+2*p.y+kept[i+1].y)/4});
 }
 const geometry=movementGeometry;movementGeometry=function(p){
  if(p.pathShape!=='freehand'||!p.points?.length)return geometry(p);
  const a=p.points;let d=`M${a[0].x} ${a[0].y}`;
  for(let i=0;i<a.length-1;i++){const prev=a[Math.max(0,i-1)],q=a[i],r=a[i+1],next=a[Math.min(a.length-1,i+2)];d+=`C${q.x+(r.x-prev.x)/6} ${q.y+(r.y-prev.y)/6} ${r.x-(next.x-q.x)/6} ${r.y-(next.y-q.y)/6} ${r.x} ${r.y}`;}
  return{d,lx:a[Math.floor(a.length/2)].x,ly:a[Math.floor(a.length/2)].y};
 };
 const label=movementShapeLabel;movementShapeLabel=v=>v==='freehand'?'رسم حر':label(v);
 for(const prefix of ['newMove','move'])$(prefix+'Shape').append(new Option('رسم حر — بالسحب','freehand'));
 function control(p){const dx=p.x2-p.x1,dy=p.y2-p.y1,len=Math.max(1,Math.hypot(dx,dy));return{x:(p.x1+p.x2)/2-dy/len*(p.pathShape==='straight'?0:(p.curve||0)),y:(p.y1+p.y2)/2+dx/len*(p.pathShape==='straight'?0:(p.curve||0))};}
 function circleEnd(p){const a=(p.pathShape==='circle'?360:p.sweep)*(p.clockwise===false?-1:1)*Math.PI/180,dx=p.x1-p.center.x,dy=p.y1-p.center.y;p.x2=p.pathShape==='circle'?p.x1:p.center.x+dx*Math.cos(a)-dy*Math.sin(a);p.y2=p.pathShape==='circle'?p.y1:p.center.y+dx*Math.sin(a)+dy*Math.cos(a);}
 function drawOverlay(){
  overlay?.remove();overlay=svgEl('g',{id:'movementEditingOverlay'});viewport.append(overlay);
  if(interaction){const p=interaction.preview;overlay.append(svgEl('path',{d:movementPathD(p),fill:'none',stroke:p.color||'#c98212','stroke-width':3,'stroke-dasharray':'7 4','pointer-events':'none'}));window.StageConstraints?.preview(p,overlay);}
  const p=interaction?.mode==='edit'?interaction.preview:currentMovement();if(!p||tool!=='select'||p.pathShape==='stationary'||layer('movement')?.locked||layer('movement')?.visible===false)return;
  const handle=(q,kind,title,index)=>{const g=svgEl('g',{'data-handle':kind,'data-index':index??'',class:'movement-edit-handle',transform:`translate(${q.x} ${q.y})`,style:'cursor:grab;touch-action:none'});const t=svgEl('title');t.textContent=title;g.append(t,svgEl('circle',{r:13,fill:'#fff','fill-opacity':.85,stroke:'#1d6ce0','stroke-width':2}),svgEl('circle',{r:4,fill:'#1d6ce0','pointer-events':'none'}));overlay.append(g);};
  handle({x:p.x1,y:p.y1},'start','تعديل البداية');handle({x:p.x2,y:p.y2},'end','تعديل النهاية والمسافة');
  if(p.center)handle(p.center,'center','تعديل مركز الدوران');
  else if(['polyline','freehand'].includes(p.pathShape)){const a=p.points||[];const step=Math.max(1,Math.ceil(a.length/8));for(let i=step;i<a.length-1;i+=step)handle(a[i],'point','تعديل انحناء المسار',i);}
  else if(['straight','curve','sCurve'].includes(p.pathShape))handle(control(p),'curve','اسحب لتعديل الانحناء');
 }
 const render=renderScene;renderScene=function(){render();drawOverlay();};
 function change(p,q,kind,index){
  if(kind==='start')p.positionStartMode='fixed';
  if(kind==='center'){p.center=q;circleEnd(p);return;}
  if(kind==='curve'){const dx=p.x2-p.x1,dy=p.y2-p.y1,len=Math.max(1,Math.hypot(dx,dy));p.curve=((q.x-(p.x1+p.x2)/2)*-dy+(q.y-(p.y1+p.y2)/2)*dx)/len;if(p.pathShape==='straight')p.pathShape='curve';return;}
  if(kind==='point'){p.points[index]=q;return;}
  if(kind==='end'&&p.center){
   if(p.pathShape==='circle'){p.positionStartMode='fixed';p.x1=q.x;p.y1=q.y;circleEnd(p);return;}
   // An arc passes through its actor-owned start and the dragged endpoint.
   // Project the centre onto their perpendicular bisector instead of moving the start.
   const vx=q.x-p.x1,vy=q.y-p.y1,length=vx*vx+vy*vy;if(length<1)return;
   const mx=(p.x1+q.x)/2,my=(p.y1+q.y)/2,shift=((mx-p.center.x)*vx+(my-p.center.y)*vy)/length;
   p.center={x:p.center.x+shift*vx,y:p.center.y+shift*vy};
   const dx=p.x1-p.center.x,dy=p.y1-p.center.y;
   const angle=(Math.atan2(q.y-p.center.y,q.x-p.center.x)-Math.atan2(dy,dx))*(p.clockwise===false?-1:1)*180/Math.PI;
   p.sweep=(angle+360)%360;circleEnd(p);return;
  }
  p[kind==='start'?'x1':'x2']=q.x;p[kind==='start'?'y1':'y2']=q.y;
  if(p.points?.length)p.points[kind==='start'?0:p.points.length-1]=q;
  if(p.center)circleEnd(p);
 }
 function finish(ev,cancel=false){
  if(!interaction)return;const drag=interaction;interaction=null;try{host.releasePointerCapture(drag.id);}catch(e){}
  if(cancel){drawOverlay();return;}
  if(drag.mode==='edit'){
   if(JSON.stringify(drag.original)===JSON.stringify(drag.preview)){drawOverlay();return;}
   snap();Object.assign(drag.path,drag.preview);
   const target=StageSupport.target({targetId:drag.path.endTargetId});if(target&&!StageSupport.contains(target,{x:drag.path.x2,y:drag.path.y2}))drag.path.endTargetId=null;
   placeMovementActorAtEnd(drag.path);mark('عُدّل المسار مع حفظ التوقيت ووضعية الجسم');renderScene();return;
  }
  if(drag.points.length===1)drag.points.push(point(ev));
  const end=drag.points.at(-1);if(drag.shape==='freehand')pendingMovement.points=smooth(drag.points);
  // A single click remains usable, but all shapes commit a dragged path on release.
  if(drag.shape==='polyline'&&distance(drag.down,end)<3){pendingMovement.points.push(end);drawOverlay();return;}
  if(drag.shape==='polyline')pendingMovement.points=smooth(drag.points);
  if(['circle','arc'].includes(drag.shape)&&distance(pathStart,end)<3){drawOverlay();return;}
  commitChoreographyPath(end);drawOverlay();
 }
 host.addEventListener('pointerdown',ev=>{
  if(ev.button!==0||interaction)return;
  const h=ev.target.closest('.movement-edit-handle');
  if(h&&tool==='select'&&!layer('movement')?.locked){ev.preventDefault();ev.stopImmediatePropagation();const p=currentMovement();stopSimulation();interaction={mode:'edit',id:ev.pointerId,path:p,original:clone(p),preview:clone(p),kind:h.dataset.handle,index:Number(h.dataset.index)};host.setPointerCapture(ev.pointerId);return;}
  if(tool!=='path'||!pendingMovement||layer('movement')?.locked)return;
  ev.preventDefault();ev.stopImmediatePropagation();const q=point(ev);if(!pathStart)pathStart=q;
  const shape=pendingMovement.pathShape;interaction={mode:'draw',id:ev.pointerId,shape,down:clone(q),points:[clone(pathStart)],preview:{...clone(pendingMovement),x1:pathStart.x,y1:pathStart.y,x2:q.x,y2:q.y}};
  host.setPointerCapture(ev.pointerId);drawOverlay();
 },true);
 host.addEventListener('pointermove',ev=>{
  if(!interaction||interaction.id!==ev.pointerId)return;ev.preventDefault();ev.stopImmediatePropagation();const q=point(ev),drag=interaction;
  if(drag.mode==='edit')change(drag.preview,q,drag.kind,drag.index);
  else{
   if(distance(drag.points.at(-1),q)>=2)drag.points.push(q);Object.assign(drag.preview,{x2:q.x,y2:q.y});
   if(['freehand','polyline'].includes(drag.shape))drag.preview.points=smooth(drag.points.length>1?drag.points:[drag.points[0],q]);
   if(['circle','arc'].includes(drag.shape)){drag.preview.center=q;circleEnd(drag.preview);}
  }
  drawOverlay();
 },true);
 host.addEventListener('pointerup',ev=>{if(interaction){ev.preventDefault();ev.stopImmediatePropagation();finish(ev);}},true);
 host.addEventListener('pointercancel',ev=>finish(ev,true),true);
 window.addEventListener('keydown',ev=>{if(ev.key==='Escape'&&interaction)finish(ev,true);});
 const begin=beginEnhancedMovementDraw;beginEnhancedMovementDraw=function(){const result=begin();if(result&&pendingMovement)$('statusText').textContent='اضغط واسحب لرسم المسار ثم أفلت لاعتماده؛ الدائرة والقوس: اسحب نحو المركز';return result;};
})();
