'use strict';
// Acts, scenes, tableaux/states, continuity and summaries — PREVUSCENE v0.5
let pendingContinuityActId = null;

function stableStringify(value){
  if(value === null || typeof value !== 'object') return JSON.stringify(value);
  if(Array.isArray(value)) return `[${value.map(stableStringify).join(',')}]`;
  return `{${Object.keys(value).sort().map(k => JSON.stringify(k)+':'+stableStringify(value[k])).join(',')}}`;
}
function tinyHash(str){
  let h = 2166136261;
  for(let i=0;i<str.length;i++){ h ^= str.charCodeAt(i); h = Math.imul(h,16777619); }
  return (h>>>0).toString(16);
}
function continuityObjectView(o){
  return {
    id:o.id,type:o.type,layer:o.layer,name:o.name,actorId:o.actorId||null,
    characterName:o.characterName||'',x:+o.x||0,y:+o.y||0,w:+o.w||0,h:+o.h||0,
    rotation:+o.rotation||0,pose:o.pose||'',poseTransition:o.poseTransition||null,...(o.arms&&Object.values(o.arms).some(Boolean)?{arms:o.arms}:{}),...(o.support?{support:o.support}:{}),facing:+o.facing||0,color:o.color||'',
    ...(o.terrain?{terrain:o.terrain}:{}),...(o.blocksPassage!==undefined?{blocksPassage:o.blocksPassage}:{}),...(o.clearance3D!==undefined?{clearance3D:o.clearance3D}:{}),...(o.platformShape?{platformShape:o.platformShape}:{}),...(o.stairSteps?{stairSteps:o.stairSteps,stairDirection:o.stairDirection}:{}),...(o.curtainOpen!==undefined?{curtainOpen:o.curtainOpen}:{}),height3D:o.height3D??null,...(o.seatHeight3D!=null?{seatHeight3D:o.seatHeight3D}:{}),elevation3D:o.elevation3D??null,
    radius:+o.radius||0,intensity:+o.intensity||0
  };
}
function sceneEndSignature(sc){
  if(!sc) return null;
  return tinyHash(stableStringify({ambientLight:+sc.ambientLight||0,objects:(sc.objects||[]).map(continuityObjectView)}));
}
function continuitySourceScene(sc=scene()){
  return sc?.continuity?.fromSceneId ? state.scenes.find(x=>x.id===sc.continuity.fromSceneId)||null : null;
}
function continuityIsStale(sc=scene()){
  const c=sc?.continuity;
  if(!c || c.source!=='end' || !c.fromSceneId) return false;
  const src=continuitySourceScene(sc);
  if(!src) return false;
  return sceneEndSignature(src)!==c.sourceSignature;
}
function sceneHasWorkBeyondOpening(sc=scene()){
  if(!sc.openingSnapshot) return (sc.paths||[]).length>0 || (sc.states||[]).length>0;
  if((sc.paths||[]).length || (sc.states||[]).length) return true;
  return sceneEndSignature(sc)!==sc.openingSnapshot.currentSignature;
}
function selectScene(id){
  stopSimulation();state.currentSceneId=id;selectedId=null;selectedPathId=null;renderAll();
  if(continuityIsStale(scene())) mark('تنبيه: تغيّرت نهاية المشهد السابق؛ راجع استمرارية افتتاح هذا المشهد.');
}
function captureSceneState(){
  const title=prompt('اسم الحالة:',`الحالة ${(scene().states?.length||0)+1}`);
  if(!title)return;
  snap();
  scene().states.push({id:crypto.randomUUID(),title,createdAt:new Date().toISOString(),objects:clone(scene().objects),paths:clone(scene().paths),ambientLight:scene().ambientLight});
  mark('حُفظت حالة المشهد');renderSceneEngine();
}
function applySceneState(st){
  if(!confirm(`استعادة الحالة «${htmlText(st.title)}»؟ ستستبدل الوضعية الحالية.`))return;
  snap();scene().objects=clone(st.objects||[]);scene().paths=clone(st.paths||[]);if(st.ambientLight!=null)scene().ambientLight=st.ambientLight;selectedId=null;selectedPathId=null;
  mark('استعيدت حالة المشهد');renderScene();
}
function objectKey(o){return o.actorId?`actor:${o.actorId}`:`${o.type}:${o.name}`;}
function transitionData(){
  const prev=previousScene();if(!prev)return null;
  const prevMap=new Map(prev.objects.map(o=>[objectKey(o),o]));
  const currMap=new Map(scene().objects.map(o=>[objectKey(o),o]));
  const entering=[...currMap.keys()].filter(k=>!prevMap.has(k)).map(k=>currMap.get(k));
  const leaving=[...prevMap.keys()].filter(k=>!currMap.has(k)).map(k=>prevMap.get(k));
  const moved=[];
  for(const [k,o] of currMap)if(prevMap.has(k)){
    const q=prevMap.get(k);
    if(Math.hypot(o.x-q.x,o.y-q.y)>20||Math.abs((o.rotation||0)-(q.rotation||0))>2)moved.push(o);
  }
  return{prev,entering,leaving,moved};
}
function nextSceneTitle(actId){return `المشهد ${scenesInAct(actId).length+1}`;}
function sceneInsertIndexForAct(actId){
  let idx=-1;
  for(let i=0;i<state.scenes.length;i++) if(state.scenes[i].actId===actId) idx=i;
  if(idx>=0)return idx+1;
  const act=actById(actId);
  const later=new Set(orderedActs().filter(a=>a.order>(act?.order??0)).map(a=>a.id));
  const firstLater=state.scenes.findIndex(s=>later.has(s.actId));
  return firstLater>=0?firstLater:state.scenes.length;
}
function renderSceneEngine(){
  const tree=$('actsTree');
  if(tree){
    tree.innerHTML='';
    for(const a of orderedActs()){
      const block=document.createElement('div');block.className='act-block';
      const head=document.createElement('div');head.className='act-head';
      head.innerHTML=`<b>${htmlText(a.title)}</b><button data-x="rename">تسمية</button><button data-x="add">+ مشهد</button><button data-x="delete" class="danger">حذف</button>`;
      head.querySelector('[data-x="rename"]').onclick=()=>{const n=prompt('اسم الفصل:',a.title);if(!n)return;snap();a.title=n;mark('عُدل اسم الفصل');renderAll();};
      head.querySelector('[data-x="add"]').onclick=()=>openSceneContinuity(a.id);
      head.querySelector('[data-x="delete"]').onclick=()=>deleteAct(a.id);
      block.append(head);
      const list=document.createElement('div');list.className='act-scenes';
      for(const s of scenesInAct(a.id)){
        const row=document.createElement('div');row.className='tree-scene'+(s.id===state.currentSceneId?' active':'');
        const stale=continuityIsStale(s);
        const inherited=s.continuity?.fromSceneId?'<span class="continuity-badge" title="افتتاح موروث">↳</span>':'';
        const warn=stale?'<span class="continuity-warn" title="تغير المشهد المصدر">⚠</span>':'';
        row.innerHTML=`<span>${inherited}${htmlText(s.title)}${warn}</span><small>${Number(s.duration)||0} د · ${(s.objects||[]).filter(o=>o.type==='actor').length} ش · ${(s.objects||[]).length} ع</small>`;
        row.onclick=()=>selectScene(s.id);list.append(row);
      }
      if(!list.children.length)list.innerHTML='<div class="empty">لا توجد مشاهد.</div>';
      block.append(list);tree.append(block);
    }
  }
  const states=$('sceneStatesList');
  if(states){
    states.innerHTML='';
    for(const st of scene().states||[]){
      const card=document.createElement('div');card.className='scene-state-card';
      card.innerHTML=`<div class="scene-state-head"><b>${htmlText(st.title)}</b><button data-s="apply">استعادة</button><button data-s="rename">تسمية</button><button data-s="delete" class="danger">حذف</button></div><small>${(st.objects||[]).length} عنصر · ${(st.paths||[]).length} حركة</small>`;
      card.querySelector('[data-s="apply"]').onclick=()=>applySceneState(st);
      card.querySelector('[data-s="rename"]').onclick=()=>{const n=prompt('اسم الحالة:',st.title);if(!n)return;snap();st.title=n;mark('عُدل اسم الحالة');renderSceneEngine();};
      card.querySelector('[data-s="delete"]').onclick=()=>{snap();scene().states=scene().states.filter(x=>x.id!==st.id);mark('حُذفت الحالة');renderSceneEngine();};
      states.append(card);
    }
    if(!states.children.length)states.innerHTML='<div class="empty">لم تحفظ حالات لهذا المشهد بعد.</div>';
  }
  renderTransition();
}
function continuitySourceObjects(){
  const source=$('continuitySource')?.value||'end',curr=scene();
  if(source==='empty')return[];
  if(source==='start')return clone(curr.openingSnapshot?.objects||curr.objects||[]);
  if(source==='saved'){
    const id=$('continuitySavedState')?.value,st=curr.states?.find(x=>x.id===id);
    return clone(st?.objects||curr.objects||[]);
  }
  return clone(curr.objects||[]);
}
function renderContinuityItems(){
  const box=$('continuityItems');if(!box)return;
  const objects=continuitySourceObjects();box.innerHTML='';
  if(!objects.length){box.innerHTML='<div class="continuity-empty">لا توجد عناصر موروثة من المصدر المحدد.</div>';return;}
  for(const o of objects){
    const label=document.createElement('label');label.className='continuity-item';
    label.innerHTML=`<input type="checkbox" data-continuity-id="${htmlText(o.id)}" checked><span><b>${htmlText(o.characterName||o.name||'عنصر')}</b><small>${o.type==='actor'?'شخصية':o.layer==='decor'?'ديكور':o.layer==='props'?'إكسسوار':o.layer==='lighting'?'إضاءة':'عنصر'}</small></span>`;
    box.append(label);
  }
}
function openSceneContinuity(actId=scene().actId){
  if(typeof actId!=='string'||!actById(actId))actId=scene().actId;
  pendingContinuityActId=actId;
  const dlg=$('sceneContinuityDialog'),sel=$('continuitySavedState');
  sel.innerHTML='';
  for(const st of scene().states||[]){const op=document.createElement('option');op.value=st.id;op.textContent=st.title;sel.append(op);}
  $('continuitySource').value='end';$('savedStateWrap').hidden=true;
  const target=$('continuityTargetAct');
  if(target)target.textContent=`سيُنشأ ${nextSceneTitle(actId)} داخل ${actById(actId)?.title||'الفصل'}، انطلاقًا من المشهد الحالي «${scene().title}».`;
  renderContinuityItems();dlg.showModal();
}
function addSceneToAct(actId=pendingContinuityActId||scene().actId){
  if(typeof actId!=='string'||!actById(actId))actId=scene().actId;
  const source=$('continuitySource')?.value||'end',sourceScene=scene(),all=continuitySourceObjects();
  const keep=new Set([...document.querySelectorAll('[data-continuity-id]:checked')].map(x=>x.dataset.continuityId));
  snap();
  const inherited=source==='empty'?[]:all.filter(o=>keep.has(o.id));
  for(const o of inherited)if(o.type==='actor'){delete o.initialState;delete o.stateChanges;}
  const s=defaultScene(actId);s.title=nextSceneTitle(actId);s.objects=clone(inherited);s.paths=[];s.states=[];
  if(source!=='empty')s.ambientLight=sourceScene.ambientLight;
  const sourceSig=source==='end'?sceneEndSignature(sourceScene):tinyHash(stableStringify({source,objects:inherited,ambientLight:s.ambientLight}));
  s.openingSnapshot={
    objects:clone(inherited),ambientLight:s.ambientLight,createdAt:new Date().toISOString(),signature:sourceSig,
    currentSignature:tinyHash(stableStringify({ambientLight:s.ambientLight,objects:inherited.map(continuityObjectView)}))
  };
  s.continuity={source,fromSceneId:sourceScene.id,sourceSignature:sourceSig,createdAt:new Date().toISOString()};
  state.scenes.splice(sceneInsertIndexForAct(actId),0,s);
  state.currentSceneId=s.id;selectedId=null;selectedPathId=null;pendingContinuityActId=null;
  mark('أضيف مشهد ورث الحالة السابقة');$('sceneContinuityDialog')?.close();renderAll();
}
function refreshOpeningFromPrevious(){
  const sc=scene(),src=continuitySourceScene(sc);
  if(!src)return alert('لا يوجد مشهد مصدر صالح لهذا المشهد.');
  const hasWork=sceneHasWorkBeyondOpening(sc);
  if(hasWork&&!confirm('بدأ العمل داخل هذا المشهد. تحديث الافتتاح من نهاية المشهد السابق سيستبدل العناصر الحالية ويمسح مسارات الحركة. هل تريد المتابعة؟'))return;
  if(!hasWork&&!confirm('تحديث افتتاح هذا المشهد من النهاية الحالية للمشهد السابق؟'))return;
  snap();
  const inherited=clone(src.objects||[]);for(const o of inherited)if(o.type==='actor'){delete o.initialState;delete o.stateChanges;}sc.objects=inherited;sc.paths=[];sc.ambientLight=src.ambientLight;
  const sig=sceneEndSignature(src);
  sc.continuity={...(sc.continuity||{}),source:'end',fromSceneId:src.id,sourceSignature:sig,updatedAt:new Date().toISOString()};
  sc.openingSnapshot={objects:clone(inherited),ambientLight:sc.ambientLight,createdAt:new Date().toISOString(),signature:sig,currentSignature:tinyHash(stableStringify({ambientLight:sc.ambientLight,objects:inherited.map(continuityObjectView)}))};
  selectedId=null;selectedPathId=null;mark('حُدّث افتتاح المشهد من السابق');renderAll();
}
function renderTransition(){
  const box=$('transitionAnalysis');if(!box)return;
  const t=transitionData();if(!t){box.innerHTML='هذا أول مشهد في المشروع؛ لا يوجد انتقال سابق.';return;}
  const names=a=>a.length?a.map(o=>o.characterName||o.name).join('، '):'لا شيء';
  const stale=continuityIsStale(scene());
  const continuity=scene().continuity?.fromSceneId
    ? `<div class="continuity-status ${stale?'stale':'ok'}"><b>${stale?'⚠ تغيّرت نهاية المشهد المصدر بعد إنشاء هذا المشهد.':'✓ افتتاح هذا المشهد محفوظ كصورة مستقلة من المشهد السابق.'}</b>${stale?'<button id="refreshOpeningBtn" type="button">تحديث الافتتاح من السابق</button>':''}</div>`
    : '';
  box.innerHTML=continuity+`<b>من: ${htmlText(t.prev.title)}</b><ul><li>يدخل: ${htmlText(names(t.entering))}</li><li>يخرج: ${htmlText(names(t.leaving))}</li><li>يتغير موقعه: ${htmlText(names(t.moved))}</li></ul>${scene().transitionNotes?`<div>${htmlText(scene().transitionNotes)}</div>`:''}`;
  const b=$('refreshOpeningBtn');if(b)b.onclick=refreshOpeningFromPrevious;
}
function deleteAct(id){
  const related=scenesInAct(id);
  if(related.length&&!confirm('سيُنقل مشهد/مشاهد هذا الفصل إلى الفصل الأول. متابعة؟'))return;
  if(state.acts.length===1)return alert('يجب الإبقاء على فصل واحد على الأقل.');
  snap();const fallback=state.acts.find(a=>a.id!==id);for(const s of related)s.actId=fallback.id;
  state.acts=state.acts.filter(a=>a.id!==id);state.acts.forEach((a,i)=>a.order=i);mark('حُذف الفصل');renderAll();
}
function moveCurrentScene(delta){
  const sc=scene(),siblings=scenesInAct(sc.actId),si=siblings.indexOf(sc),target=siblings[si+delta];if(!target)return;
  const i=state.scenes.indexOf(sc),j=state.scenes.indexOf(target);snap();[state.scenes[i],state.scenes[j]]=[state.scenes[j],state.scenes[i]];
  mark('تغير ترتيب المشهد داخل الفصل');renderAll();
}
function sceneTechnicalSummary(){
  const s=scene(),actors=s.objects.filter(o=>o.type==='actor'),decor=s.objects.filter(o=>o.layer==='decor'),props=s.objects.filter(o=>o.layer==='props');
  const lines=[`${actById(s.actId)?.title||''} — ${htmlText(s.title)}`,`المدة: ${Number(s.duration)||0} دقيقة`,``,`الملخص: ${s.synopsis||'غير محدد'}`,``,`الشخصيات (${actors.length}): ${actors.map(o=>o.characterName||o.name).join('، ')||'لا توجد'}`,`المداخل: ${actors.filter(o=>o.entrance).map(o=>`${o.characterName||o.name} (${o.entrance})`).join('، ')||'غير محددة'}`,`المخارج: ${actors.filter(o=>o.exit).map(o=>`${o.characterName||o.name} (${o.exit})`).join('، ')||'غير محددة'}`,`الديكور (${decor.length}): ${decor.map(o=>o.name).join('، ')||'لا يوجد'}`,`الإكسسوارات (${props.length}): ${props.map(o=>o.name).join('، ')||'لا توجد'}`,`الحركات (${s.paths.length}): ${s.paths.map(p=>`${p.code} ${movementActorLabel(p)} / ${movementTypeLabel(p.type)}`).join('، ')||'لا توجد'}`,``,`ملاحظات الانتقال: ${s.transitionNotes||'لا توجد'}`,`ملاحظات المخرج: ${s.directorNotes||'لا توجد'}`,`ملاحظات المحافظة: ${s.managerNotes||'لا توجد'}`];
  return lines.join('\n');
}
