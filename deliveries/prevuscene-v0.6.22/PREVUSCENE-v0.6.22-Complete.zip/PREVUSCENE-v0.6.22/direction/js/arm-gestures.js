'use strict';
// Each arm owns an independent channel; bodily pose and travel remain independent.
window.ArmGestures=(function(){
 const names={raised:'رفع',lowered:'خفض',side:'مد إلى الجانب',forward:'مد إلى الأمام',point:'إشارة نحو عنصر',rest:'عودة إلى الوضع الطبيعي'};
 const heights={actor:1.72,chair:.9,table:.75,desk:.75,sofa:.85,bed:.55,platform:.4,stairs:.8,tree:3,door:2.2,wall:2.5,column:2.5,window:1.2,car:1.5,screen:2,prop:.5,note:.05,light:3,group:1.72};
 function targetPoint(target,resolve){if(!target)return null;const position=resolve?.(target.id);const o={...target,...(position||{})};return{x:o.x,y:o.y,z:(o.type==='actor'?StageSupport.elevation(o):Number(o.elevation3D)||0)+(Number(o.height3D)||heights[o.type]||.6)*.55};}
 function point(state,resolve){const target=scene().objects.find(o=>o.id===state?.targetId);return state?.track&&target?targetPoint(target,resolve):state?.targetPoint||targetPoint(target,resolve);}
 function smooth(t){t=clamp(t,0,1);return t*t*(3-2*t);}
 function sample(p,t,o,side,resolve){
  const start=clone(p.startArms?.[side]||null),finish={preset:p.gesturePreset||'raised',bend:clamp(Number(p.gestureBend)||0,0,135)};
  const end=finish.preset==='rest'?null:finish;
  if(finish.preset==='point'){finish.targetId=p.gestureTargetId;finish.track=p.gestureTrack!==false;finish.targetPoint=clone(p.gestureTargetPoint||null);const latest=point(finish,resolve);if(latest)finish.targetPoint=latest;}
  const reach=clamp(Number(p.gestureReachAt??50),1,100)/100,back=Math.max(reach,clamp(Number(p.gestureReturnAt??75),1,99)/100);
  if(p.gestureFinish==='return'&&t>=back)return transition(end,start,smooth((t-back)/Math.max(.001,1-back)));
  return transition(start,end,smooth(t/reach));
 }
 function transition(from,to,progress){if(progress<=0)return clone(from);if(progress>=1)return clone(to);return{from:clone(from),to:clone(to),progress};}
 function label(p){return `${names[p.gesturePreset]||'إيماءة'} — ${p.armSide==='left'?'الذراع اليسرى':p.armSide==='right'?'الذراع اليمنى':'الذراعان'}`;}
 function display(state,side,o,depth=0){
  const sign=side==='left'?-1:1,base={x:sign*o.w*.3,y:o.h*.28,label:'طبيعي'};if(!state||depth>16)return base;
  if(Object.hasOwn(state,'progress')){const a=display(state.from,side,o,depth+1),b=display(state.to,side,o,depth+1),t=clamp(Number(state.progress)||0,0,1);return{x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t,label:b.label};}
  const presets={raised:{x:sign*o.w*.32,y:-o.h*.75},lowered:base,side:{x:sign*o.w*.95,y:-o.h*.15},forward:{x:sign*o.w*.3,y:-o.h*.5},rest:base};let p=presets[state.preset]||base;
  if(state.preset==='point'){const target=point(state,o.armTargetResolver);if(target){const dx=target.x-o.x,dy=target.y-o.y,len=Math.hypot(dx,dy)||1;p={x:sign*o.w*.23+dx/len*o.h*.65,y:-o.h*.15+dy/len*o.h*.65};}}
  return{...p,label:names[state.preset]||'إيماءة'};
 }
 function draw(g,o){if(o.type!=='actor'||!o.arms||!Object.values(o.arms).some(Boolean))return;const overlay=svgEl('g',{class:'actor-arm-gesture','pointer-events':'none'});g.append(overlay);let labels=[];
  for(const side of ['left','right']){const state=o.arms[side];if(!state)continue;const sign=side==='left'?-1:1,a={x:sign*o.w*.23,y:-o.h*.15},b=display(state,side,o);overlay.append(svgEl('path',{d:`M${a.x} ${a.y} Q${(a.x+b.x)/2} ${Math.min(a.y,b.y)-5} ${b.x} ${b.y}`,fill:'none',stroke:'#e69b12','stroke-width':3,'stroke-linecap':'round'}));overlay.append(svgEl('circle',{cx:b.x,cy:b.y,r:4,fill:'#ffc354',stroke:'#654513','stroke-width':1}));labels.push(`${side==='left'?'يسرى':'يمنى'}: ${b.label}`);}
  const text=svgEl('text',{x:0,y:-o.h*.85-8,class:'arm-gesture-label','text-anchor':'middle'});text.textContent=labels.join(' · ');overlay.append(text);
 }
 return{sample,point,targetPoint,label,draw};
})();
(function(){
 const fields=new Map();
 for(const prefix of ['newMove','move']){
  $(prefix+'ActionKind').append(new Option('حركة الذراعين','gesture'));
  const field=document.createElement('fieldset');field.id=prefix+'GestureFields';field.className='movement-timing-fieldset';field.hidden=true;
  field.innerHTML=`<legend>حركة الذراعين</legend><label>الذراع<select id="${prefix}ArmSide"><option value="right">اليمنى</option><option value="left">اليسرى</option><option value="both">الذراعان</option></select></label><label>الإيماءة<select id="${prefix}GesturePreset"><option value="raised">رفع فوق الرأس</option><option value="lowered">خفض</option><option value="side">مد إلى الجانب</option><option value="forward">مد إلى الأمام</option><option value="point">الإشارة إلى ممثل أو عنصر</option><option value="rest">العودة إلى الوضع الطبيعي</option></select></label><label id="${prefix}GestureTargetWrap">هدف الإشارة<select id="${prefix}GestureTarget"><option value="">اختر عنصرًا</option></select></label><label id="${prefix}GestureTrackWrap"><input type="checkbox" id="${prefix}GestureTrack" checked> تتبع الهدف عند تحركه</label><label>ثني المرفق °<input id="${prefix}GestureBend" type="number" min="0" max="135" step="any" value="15"></label><label>بلوغ الإيماءة عند % من مدة الحركة<input id="${prefix}GestureReachAt" type="number" min="1" max="100" step="any" value="50"></label><label>نهاية الحركة<select id="${prefix}GestureFinish"><option value="hold">الاحتفاظ بالإيماءة</option><option value="return">العودة إلى وضع الذراع عند البداية</option></select></label><label id="${prefix}GestureReturnWrap">بدء العودة عند % من المدة<input id="${prefix}GestureReturnAt" type="number" min="1" max="99" step="any" value="75"></label><p class="hint">الذراع مستقل عن الانتقال ووضع الجسم. يمكن مزامنة رفع ذراع مع المشي أو مع حركة الذراع الأخرى. في 2D تظهر علامة توضيحية؛ في 3D يتحرك الكتف والمرفق واليد.</p>`;
  $(prefix+'TimingMode').closest('fieldset').before(field);fields.set(prefix,field);
  for(const suffix of ['ArmSide','GesturePreset','GestureTarget','GestureTrack','GestureBend','GestureReachAt','GestureFinish','GestureReturnAt'])$(prefix+suffix).addEventListener('change',()=>{refresh(prefix);if(prefix==='move')TheatricalActions.saveActionEdit();});
 }
 function refresh(prefix){const field=fields.get(prefix);field.hidden=$(prefix+'ActionKind').value!=='gesture';const point=$(prefix+'GesturePreset').value==='point';$(prefix+'GestureTargetWrap').hidden=!point;$(prefix+'GestureTrackWrap').hidden=!point;$(prefix+'GestureReturnWrap').hidden=$(prefix+'GestureFinish').value!=='return';}
 const update=TheatricalActions.updateControls;TheatricalActions.updateControls=function(prefix){update(prefix);refresh(prefix);};
 const fill=fillChoreo;fillChoreo=function(prefix,p,o){fill(prefix,p,o);const f=fields.get(prefix);f.startArms=clone(p.startArms||(!p.id?o?.arms:null)||{});f.targetId=p.gestureTargetId;f.targetPoint=clone(p.gestureTargetPoint||null);for(const [suffix,value] of Object.entries({ArmSide:p.armSide||'right',GesturePreset:p.gesturePreset||'raised',GestureBend:p.gestureBend??15,GestureReachAt:p.gestureReachAt??50,GestureFinish:p.gestureFinish||'hold',GestureReturnAt:p.gestureReturnAt??75}))$(prefix+suffix).value=value;$(prefix+'GestureTrack').checked=p.gestureTrack!==false;const target=$(prefix+'GestureTarget');target.replaceChildren(new Option('اختر عنصرًا',''));for(const x of scene().objects.filter(x=>x.id!==o?.id))target.append(new Option(x.characterName||x.name,x.id));target.value=p.gestureTargetId||'';refresh(prefix);};
 const read=readChoreo;readChoreo=function(prefix){const data=read(prefix);if($(prefix+'ActionKind').value!=='gesture')return data;const field=fields.get(prefix),id=$(prefix+'GestureTarget').value;return{...data,startArms:clone(field.startArms),armSide:$(prefix+'ArmSide').value,gesturePreset:$(prefix+'GesturePreset').value,gestureTargetId:id||null,gestureTargetPoint:field.targetId===id&&field.targetPoint?clone(field.targetPoint):ArmGestures.targetPoint(scene().objects.find(o=>o.id===id)),gestureTrack:$(prefix+'GestureTrack').checked,gestureBend:clamp(Number($(prefix+'GestureBend').value)||0,0,135),gestureReachAt:clamp(Number($(prefix+'GestureReachAt').value)||50,1,100),gestureReturnAt:clamp(Number($(prefix+'GestureReturnAt').value)||75,1,99),gestureFinish:$(prefix+'GestureFinish').value};};
 const save=TheatricalActions.saveActionEdit;TheatricalActions.saveActionEdit=function(){if($('moveActionKind').value==='gesture'){const d=readChoreo('move');if(d.gesturePreset==='point'&&!d.gestureTargetId){alert('اختر هدف الإشارة.');return;}if(d.gestureFinish==='return'&&d.gestureReturnAt<=d.gestureReachAt){alert('يجب أن تبدأ العودة بعد بلوغ الإيماءة.');return;}}return save();};
 const begin=beginEnhancedMovementDraw;beginEnhancedMovementDraw=function(){if($('newMoveActionKind').value==='gesture'){const d=readChoreo('newMove');if(d.gesturePreset==='point'&&!d.gestureTargetId){alert('اختر هدف الإشارة من عناصر الخشبة.');return false;}if(d.gestureFinish==='return'&&d.gestureReturnAt<=d.gestureReachAt){alert('يجب أن تبدأ العودة بعد بلوغ الإيماءة.');return false;}}return begin();};
 const baseShape=shape;shape=function(o){const g=baseShape(o);ArmGestures.draw(g,o);return g;};
 const panel=document.createElement('fieldset');panel.id='actorArmStatus';panel.innerHTML='<legend>حالة الذراعين</legend><p id="actorArmStatusText" class="hint"></p><button id="resetActorArmsBtn" type="button">إعادة الذراعين إلى الوضع الطبيعي</button>'; $('actorPosePicker').after(panel);
 $('resetActorArmsBtn').onclick=()=>{const o=selected();if(!o||o.type!=='actor'||layer(o.layer)?.locked)return;stopSimulation();snap();o.arms={};mark('استعيد وضع الذراعين الطبيعي');renderScene();};
 const props=renderProperties;renderProperties=function(){props();const o=selected();panel.hidden=o?.type!=='actor';if(!o||o.type!=='actor')return;$('actorArmStatusText').textContent=o.arms&&Object.values(o.arms).some(Boolean)?'إيماءة محفوظة؛ أضف حركة ذراع لتغييرها أو استعد الوضع الطبيعي.':'الذراعان يتبعان وضع الجسم.';$('resetActorArmsBtn').disabled=!!layer(o.layer)?.locked;};
})();
