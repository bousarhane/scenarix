'use strict';
// Sequential scene reading reuses the movement engine and its position commit.
(function(){
  let running=null;
  function display(text){$('sceneReadingStatus').textContent=text;}
  function cancel(){if(!running)return;running=null;display('توقفت القراءة عند المشهد الحالي');}
  function orderedScenes(){return orderedActs().flatMap(a=>scenesInAct(a.id));}
  function start(fromCurrent=false){
    stopSimulation();
    ensureState();
    let list=orderedScenes();
    if(fromCurrent){const index=list.findIndex(s=>s.id===state.currentSceneId);list=list.slice(Math.max(0,index));}
    if(!list.length)return alert('لا توجد مشاهد للقراءة.');
    for(const sc of list){const invalid=compileMovementSchedule(sc.paths||[]).find(x=>x.invalid);
      if(invalid){selectScene(sc.id);return alert(`راجع توقيت ${invalid.path.code||'الحركة'} في «${sc.title}» قبل قراءة المشاهد.`);}
    }
    if(window.StageConstraints){const previous=state.currentSceneId;for(const sc of list){state.currentSceneId=sc.id;const entries=ActorContinuity.prepare(compileMovementSchedule(sc.paths||[]),sc);if(!StageConstraints.allow(entries,sc)){selectScene(sc.id);return;}}state.currentSceneId=previous;}
    const run={list,index:0,respectDuration:$('respectSceneDuration').checked};running=run;
    function next(){
      if(running!==run)return;
      if(run.index>=run.list.length){running=null;display(`اكتملت قراءة ${run.list.length} مشاهد`);$('statusText').textContent='اكتملت قراءة المشاهد — احتُفظ بالمواقع النهائية';return;}
      const sc=run.list[run.index];
      if(!state.scenes.includes(sc)){stopSimulation();return;}
      // Each scene keeps its own authored actors, scenery and opening paths.
      state.currentSceneId=sc.id;selectedId=null;selectedPathId=null;renderAll();
      const schedule=compileMovementSchedule(sc.paths||[]);
      const movementTotal=Math.max(0,...schedule.map(x=>x.end));
      const duration=Math.max(movementTotal,run.respectDuration?Math.max(0,Number(sc.duration)||0)*60:0)||1;
      const label=`المشهد ${run.index+1}/${run.list.length} — ${sc.title}`;
      animateMovementSchedule(schedule,{
        label,minDuration:duration,allowEmpty:true,preserveSequence:true,
        onProgress:(sec,total)=>{if(running===run)display(`${label} · ${sec.toFixed(1)} / ${total.toFixed(1)} ث`);},
        onComplete:()=>{if(running===run){run.index++;next();}}
      });
    }
    next();
  }
  window.ScenePlayback={start,cancel,isRunning:()=>!!running};
  $('readAllScenesBtn').onclick=()=>start(false);
  $('readFromSceneBtn').onclick=()=>start(true);
  $('stopSceneReadingBtn').onclick=()=>stopSimulation();
})();
