'use strict';
// The actor owns a persistent opening state. Actions only change channels at their time.
(function(){
 const cache=new WeakMap(),observed=new WeakMap();
 const keys=['x','y','pose','facing','poseTransition','support','arms','terrain'];
 function stateOf(o){const defaults={x:0,y:0,pose:'standing',facing:0,poseTransition:null,support:null,arms:{},terrain:null};return Object.fromEntries(keys.map(k=>[k,clone(o[k]===undefined?defaults[k]:o[k])]));}
 function base(o,list=[]){
  if(o.initialState)return{...o,...clone(o.initialState)};
  const opening=scene().openingSnapshot?.objects?.find(a=>a.id===o.id);
  if(opening)return{...o,...stateOf(opening)};
  const first=[...list].sort((a,b)=>a.start-b.start)[0]?.path;if(!first)return o;
  const value={...o,pose:first.startPose||o.pose,facing:first.startFacing??o.facing,poseTransition:first.startBodyState||null,support:clone(first.startSupport||null)};
  const spatial=[...list].filter(a=>actionChannels(a.path).position).sort((a,b)=>a.start-b.start)[0]?.path;
  if(spatial)Object.assign(value,{x:spatial.direction==='reverse'?spatial.x2:spatial.x1,y:spatial.direction==='reverse'?spatial.y2:spatial.y1});
  if(first.startArms)value.arms=clone(first.startArms);
  else{const gesture=[...list].sort((a,b)=>a.start-b.start).find(a=>a.path.startArms)?.path;if(gesture)value.arms=clone(gesture.startArms);}
  return value;
 }
 function capture(o){if(o&&!o.initialState)o.initialState=stateOf(o);}
 function track(p){return svgEl('path',{d:movementPathD(p)});}
 function retarget(p,pos){
  p.x1=pos.x;p.y1=pos.y;if(p.pathShape==='stationary'){p.x2=pos.x;p.y2=pos.y;}if(p.points?.length)p.points[0]={x:pos.x,y:pos.y};
  if(p.center){const a=(p.pathShape==='circle'?360:Number(p.sweep)||180)*(p.clockwise===false?-1:1)*Math.PI/180,dx=p.x1-p.center.x,dy=p.y1-p.center.y;p.x2=p.pathShape==='circle'?p.x1:p.center.x+dx*Math.cos(a)-dy*Math.sin(a);p.y2=p.pathShape==='circle'?p.y1:p.center.y+dx*Math.sin(a)+dy*Math.cos(a);}
 }
 function stateEntries(sc,schedule=compileMovementSchedule(sc.paths||[])){return sc.objects.filter(o=>o.type==='actor').flatMap(o=>(o.stateChanges||[]).map((e,index)=>{const anchor=schedule.find(a=>a.path.id===(e.atMovementId||e.afterMovementId)),time=anchor?(e.atMovementId?anchor.start:anchor.end):Number(e.time)||0;return{start:time,end:time,path:{id:e.id,actorObjectId:o.id,actionKind:'state',stateOrder:index,stateKeys:e.keys,stateValue:clone(e.value),pathShape:'stationary',x1:e.value.x??o.x,y1:e.value.y??o.y,x2:e.value.x??o.x,y2:e.value.y??o.y}};}));}
 function observe(sc=scene()){observed.set(sc,new Map(sc.objects.filter(o=>o.type==='actor').map(o=>[o.id,stateOf(o)])));}
 function recordManual(sc,schedule){const previous=observed.get(sc);if(!previous||movementPlayback)return;
  for(const o of sc.objects.filter(o=>o.type==='actor')){const before=previous.get(o.id);if(!before)continue;const now=stateOf(o),changed=keys.filter(k=>JSON.stringify(before[k])!==JSON.stringify(now[k]));if(!changed.length)continue;
   const list=schedule.filter(a=>a.path.actorObjectId===o.id);if(!list.length&&!o.stateChanges?.length){if(o.initialState)o.initialState=now;continue;}
   const lastAction=[...list].sort((a,b)=>b.end-a.end)[0],stateTime=Math.max(0,...stateEntries(sc,schedule).filter(a=>a.path.actorObjectId===o.id).map(a=>a.end));
   // Independent actor states can outlast the last surviving arrow after deletion.
   const last=lastAction&&lastAction.end>=stateTime?lastAction:{end:stateTime,path:{id:null}};o.stateChanges??=[];
   const owned=changed.filter(k=>k!=='arms');if(changed.includes('arms'))for(const side of ['left','right'])if(JSON.stringify(before.arms?.[side]||null)!==JSON.stringify(now.arms?.[side]||null))owned.push(side+'Arm');
   if(owned.some(k=>['x','y'].includes(k)))for(const k of ['x','y'])if(!owned.includes(k))owned.push(k);
   if(!owned.length)continue;const existing=o.stateChanges.find(e=>(last.path.id?e.afterMovementId===last.path.id:!e.afterMovementId&&Number(e.time)===last.end)&&!e.forActionId&&!e.atMovementId);if(existing){o.stateChanges=o.stateChanges.filter(e=>e.id!==existing.id);o.stateChanges.push({...existing,keys:[...new Set([...existing.keys,...owned])],value:now});}else o.stateChanges.push({id:crypto.randomUUID(),time:last.end,afterMovementId:last.path.id,keys:owned,value:now});
  }
 }
 function prepare(entries,sc=scene(),includeStates=true){
  const ids=new Set(entries.map(a=>a.path.actorObjectId));
  const full=includeStates?[...entries,...stateEntries(sc,compileMovementSchedule(sc.paths||[])).filter(a=>!ids.size||ids.has(a.path.actorObjectId))]:entries;
  const groups=new Map();
  for(const item of full){const v={...item,path:clone(item.path)};if(!groups.has(v.path.actorObjectId))groups.set(v.path.actorObjectId,[]);groups.get(v.path.actorObjectId).push(v);}
  // Positions are prepared first so looking/pointing at another actor uses its same-time position.
  for(const [id,list] of groups){const o=sc.objects.find(o=>o.id===id);if(!o)continue;list.sort((a,b)=>a.start-b.start||Number(b.path.actionKind==='state')-Number(a.path.actionKind==='state'));
   const prior=[];for(const item of list){const p=item.path;if(p.positionStartMode==='inherit'&&p.direction!=='reverse'&&(actionChannels(p).position||p.pathShape==='stationary')){const pos=sampleActorPosition(prior.filter(a=>a.start<item.start||(a.start===item.start&&a.path.actionKind==='state')),item.start,o);retarget(p,pos);}item.track=track(p);prior.push(item);}
  }
  const resolve=(id,sec)=>{const o=sc.objects.find(o=>o.id===id);return o?sampleActorPosition(groups.get(id)||[],sec,o):null;};
  for(const [id,list] of groups){const o=sc.objects.find(o=>o.id===id);if(!o)continue;const prior=[];
   for(const item of list){const p=item.path;
    if(p.startStateMode==='inherit'){
     const start=sampleActorActions(prior.filter(a=>a.start<item.start||(a.start===item.start&&a.path.actionKind==='state')),item.start,o,resolve);
     Object.assign(p,{startPose:start.pose,startFacing:start.facing,startBodyState:clone(start.poseTransition||null),startSupport:clone(start.support||null),startArms:clone(start.arms||{}),startTerrain:clone(start.terrain||null)});
     if(p.keepStartPose)p.endPose=start.pose;
    }
    prior.push(item);
   }
  }
  return full.map(item=>groups.get(item.path.actorObjectId)?.find(v=>v.path.id===item.path.id)||item);
 }
 function refresh(sc=scene()){
  const authored=compileMovementSchedule(sc.paths||[]);
  for(const o of sc.objects){const v=o.initialState,b=o.support,t=StageSupport.target(b),first=authored.find(a=>a.path.actorObjectId===o.id);if(v&&!v.support&&t&&first?.start===0&&first.path.pathShape==='stationary'&&first.path.endTargetId===t.id&&Math.hypot(v.x-first.path.x1,v.y-first.path.y1)<.001&&Math.hypot(o.x-b.actorX,o.y-b.actorY)<.001&&(t.x!==b.targetX||t.y!==b.targetY||Number(t.rotation||0)!==b.targetRotation)){const old={...t,x:b.targetX,y:b.targetY,rotation:b.targetRotation},local=StageSupport.local(v,old);Object.assign(v,StageSupport.world({localX:local.x,localY:local.y},t));v.facing=normalFacing((Number(v.facing)||0)-(Number(t.rotation)||0)+b.targetRotation);}}
  for(const o of sc.objects){const v=o.initialState,b=v?.support,t=StageSupport.target(b);if(t&&Math.hypot(v.x-b.actorX,v.y-b.actorY)<.001&&(t.x!==b.targetX||t.y!==b.targetY||Number(t.rotation||0)!==b.targetRotation)){Object.assign(v,StageSupport.world(b,t));v.facing=normalFacing((Number(v.facing)||0)-(Number(t.rotation)||0)+b.targetRotation);v.support=StageSupport.bind(v,t,v.pose);}}
  for(const o of sc.objects)if(o.stateChanges)o.stateChanges=o.stateChanges.filter(e=>!e.forActionId||sc.paths.some(p=>p.id===e.forActionId)||(e.forActionId==='__pending'&&pendingMovement?.adoptStateId===e.id));
  let schedule=compileMovementSchedule(sc.paths||[]);
  for(const o of sc.objects.filter(o=>o.type==='actor')){const list=schedule.filter(a=>a.path.actorObjectId===o.id);if(list.length&&!o.initialState)o.initialState=stateOf(base(o,list));}
  // Older translations stored the director's starting body on the arrow only.
  // Preserve that authored information as an actor state point at the action's start.
  for(const item of schedule){const p=item.path,o=sc.objects.find(o=>o.id===p.actorObjectId);if(!o||p.actionKind!=='translate'||p.startStateMode)continue;const owned=[],value=stateOf(base(o,schedule.filter(a=>a.path.actorObjectId===o.id)));if(p.startPose){value.pose=p.startPose;value.poseTransition=clone(p.startBodyState||null);value.support=clone(p.startSupport||null);owned.push('pose','poseTransition','support');}if(Number.isFinite(p.startFacing)){value.facing=p.startFacing;owned.push('facing');}if(owned.length){o.stateChanges??=[];o.stateChanges.push({id:crypto.randomUUID(),atMovementId:p.id,forActionId:p.id,time:item.start,keys:owned,value});}p.startStateMode='explicit';}
  const fingerprint=()=>JSON.stringify([sc.paths,sc.objects.filter(o=>o.type==='actor').map(o=>[o.id,o.initialState,o.stateChanges])]);
  const old=cache.get(sc);if(old===fingerprint()){recordManual(sc,schedule);if(old===fingerprint())return;}
  const prepared=prepare(schedule,sc);
  for(const item of prepared){const p=sc.paths.find(p=>p.id===item.path.id);if(!p)continue;
   if(p.positionStartMode==='inherit')for(const k of ['x1','y1','x2','y2','points'])if(item.path[k]!==undefined)p[k]=clone(item.path[k]);
   if(p.startStateMode==='inherit')for(const k of ['startPose','startFacing','startBodyState','startSupport','startArms','startTerrain','endPose','endFacing'])if(item.path[k]!==undefined)p[k]=clone(item.path[k]);
  }
  // An authored edit recomputes the final state of the sequence, not the end of one arrow.
  if(old!==undefined&&!movementPlayback){const resolve=(id,sec)=>{const o=sc.objects.find(o=>o.id===id);return o?sampleActorPosition(prepared.filter(a=>a.path.actorObjectId===id),sec,o):null;};
   for(const o of sc.objects.filter(o=>o.type==='actor')){const list=prepared.filter(a=>a.path.actorObjectId===o.id);if(list.length||o.initialState){const end=Math.max(0,...list.map(a=>a.end));Object.assign(o,sampleActorActions(list,end,o,resolve));delete o.gait;}}
  }
  cache.set(sc,fingerprint());
 }
 function playback(entries,normalize=false,isolated=false){
  const sc=scene(),full=prepare(compileMovementSchedule(sc.paths||[])),sources=new Map(),result=entries.map(e=>({...e,path:clone(full.find(a=>a.path.id===e.path.id)?.path||e.path)}));
  if(!entries.length)return{items:full,sources:new Map(sc.objects.filter(o=>o.type==='actor').map(o=>[o.id,{...o,initialState:stateOf(base(o,full.filter(a=>a.path.actorObjectId===o.id)))}]))};
  const min=normalize?Math.min(...entries.map(e=>e.start)):0;
  const resolve=(id,sec)=>{const o=sc.objects.find(o=>o.id===id);return o?sampleActorPosition(full.filter(a=>a.path.actorObjectId===id),sec,o):null;};
  for(const id of new Set(entries.map(e=>e.path.actorObjectId))){const o=sc.objects.find(o=>o.id===id);if(!o)continue;const selected=entries.filter(e=>e.path.actorObjectId===id).sort((a,b)=>a.start-b.start),first=selected[0],authored=full.find(a=>a.path.id===first.path.id),shift=first.start-(authored?.start??first.start),origin=min-shift;
   const context=sampleActorActions(full.filter(a=>a.path.actorObjectId===id),origin,o,resolve);sources.set(id,{...o,initialState:stateOf(context)});
   const end=Math.max(...selected.map(e=>e.end));for(const e of full.filter(e=>e.path.actorObjectId===id&&e.path.actionKind==='state'))if(e.start+shift>=first.start&&(isolated?e.start+shift<end:e.start+shift<=end)){if(!result.some(a=>a.path.id===e.path.id))result.push({...e,start:e.start+shift,end:e.end+shift});}
  }
  return{items:result,sources};
 }
 window.ActorContinuity={base,capture,prepare,refresh,stateOf,observe,playback,events:stateEntries};
 const place=placeMovementActorAtEnd;placeMovementActorAtEnd=function(p){capture(scene().objects.find(o=>o.id===p.actorObjectId));return place(p);};
 const render=renderScene;renderScene=function(){refresh();render();observe();};
 // Explicitly distinguish inheritance from a director-authored replacement start state.
 for(const prefix of ['newMove','move']){
  const field=document.createElement('label');field.innerHTML=`بداية الفعل<select id="${prefix}StartStateMode"><option value="inherit">يرث حالة الممثل عند هذا التوقيت</option><option value="explicit">بداية جسدية أحددها لهذا الفعل</option></select><small>الانتقال يحفظ الجسم والاتجاه؛ الأفعال التالية ترث الحالة الناتجة ما لم تحدد بداية مختلفة.</small>`;
  $(prefix+'StartPose').closest('fieldset').querySelector('legend').after(field);
  $(prefix+'EndPose').prepend(new Option('الحفاظ على وضعية البداية','inherit'));
  const geometry=document.createElement('label');geometry.innerHTML=`بداية المسار<select id="${prefix}PositionStartMode"><option value="inherit">موقع الممثل الناتج عن الأفعال السابقة</option><option value="fixed">نقطة بداية ثابتة أحددها بالرسم</option></select>`;$(prefix+'GeometryOptions').prepend(geometry);
  $(prefix+'StartStateMode').onchange=()=>{update(prefix);if(prefix==='move')TheatricalActions.saveActionEdit();};
  $(prefix+'PositionStartMode').onchange=()=>{if(prefix==='move'){const p=currentMovement();if(!p)return;snap();p.positionStartMode=$(prefix+'PositionStartMode').value;mark('عُدّلت علاقة بداية المسار بالممثل');renderScene();}};
 }
 function update(prefix){const inherited=$(prefix+'StartStateMode').value==='inherit';for(const suffix of ['StartPose','StartFacing'])$(prefix+suffix).disabled=inherited;}
 const fill=fillChoreo;fillChoreo=function(prefix,p,o){fill(prefix,p,o);$(prefix+'StartStateMode').value=p.startStateMode||(!p.id&&!o?.poseTransition?'inherit':'explicit');$(prefix+'PositionStartMode').value=p.positionStartMode||(!p.id?'inherit':'fixed');if(p.keepStartPose||!p.id)$(prefix+'EndPose').value='inherit';if(prefix==='newMove'&&!p.id&&!scene().paths.length&&o?.stateChanges?.length&&$('newMoveTimingMode').value==='absolute')$('newMoveAbsoluteStart').value=Math.max(...stateEntries(scene()).filter(a=>a.path.actorObjectId===o.id).map(a=>a.end));update(prefix);};
 const read=readChoreo;readChoreo=function(prefix){const keep=$(prefix+'EndPose').value==='inherit',value=read(prefix);return{...value,endPose:keep?value.startPose:value.endPose,keepStartPose:keep,startStateMode:$(prefix+'StartStateMode').value,positionStartMode:$(prefix+'PositionStartMode').value};};
 const apply=applyChoreographyData;applyChoreographyData=function(p,d){apply(p,d);for(const k of ['startStateMode','positionStartMode','keepStartPose'])if(d[k]!==undefined)p[k]=d[k];if(d.adoptStateId){const o=scene().objects.find(o=>o.id===p.actorObjectId),e=o?.stateChanges?.find(e=>e.id===d.adoptStateId);if(e)e.forActionId=p.id;delete p.adoptStateId;}};
 const begin=beginEnhancedMovementDraw;beginEnhancedMovementDraw=function(){
  const o=scene().objects.find(o=>o.id===$('newMoveActor').value);let adoption=null;
  if(o&&(o.poseTransition||Object.values(o.arms||{}).some(a=>a&&'progress'in a))){
   const schedule=compileMovementSchedule(),list=prepare(schedule).filter(a=>a.path.actorObjectId===o.id),last=[...schedule].filter(a=>a.path.actorObjectId===o.id).sort((a,b)=>b.end-a.end)[0];
   if(last){const end=sampleActorActions(list,Math.max(...list.map(a=>a.end)),o),now=stateOf(o),changed=keys.filter(k=>!['x','y'].includes(k)&&JSON.stringify(now[k])!==JSON.stringify(end[k]));if(changed.length){const owned=changed.filter(k=>k!=='arms');if(changed.includes('arms'))owned.push('leftArm','rightArm');adoption={id:crypto.randomUUID(),time:last.end,afterMovementId:last.path.id,keys:owned,value:now};}}
  }
  if(o&&!o.initialState&&!scene().paths.some(p=>p.actorObjectId===o.id))capture(o);
  const result=begin();if(result&&adoption){adoption.forActionId=pendingMovement?'__pending':currentMovement()?.id;if(pendingMovement)pendingMovement.adoptStateId=adoption.id;o.stateChanges??=[];o.stateChanges.push(adoption);renderScene();}if(result&&pendingMovement&&o&&pendingMovement.positionStartMode==='inherit'&&pendingMovement.direction!=='reverse'){
   const hypothetical={...clone(pendingMovement),id:'__pending',x1:o.x,y1:o.y,x2:o.x,y2:o.y};
   const schedule=compileMovementSchedule([...scene().paths,hypothetical]),start=schedule.find(a=>a.path.id==='__pending')?.start||0,list=prepare(schedule.filter(a=>a.path.id!=='__pending')).filter(a=>a.path.actorObjectId===o.id);
   pathStart=sampleActorPosition(list,start,o);if(pendingMovement.points?.length)pendingMovement.points[0]=clone(pathStart);
  }return result;
 };
 const save=TheatricalActions.saveActionEdit;TheatricalActions.saveActionEdit=function(){const before=currentMovement(),o=scene().objects.find(o=>o.id===before?.actorObjectId),wasSpatial=before&&before.pathShape!=='stationary',value=o?stateOf(o):null;const result=save();const p=currentMovement();if(wasSpatial&&p?.pathShape==='stationary'&&o){o.stateChanges??=[];o.stateChanges.push({id:crypto.randomUUID(),atMovementId:p.id,forActionId:p.id,time:0,keys:['x','y'],value});renderScene();}return result;};
 // Opening controls belong to the actor card and survive saving, duplication and replay.
 const opening=document.createElement('fieldset');opening.id='actorOpeningState';opening.className='movement-timing-fieldset';opening.innerHTML='<legend>حالة الممثل عند بداية المشهد</legend><label>الوضعية<select id="initialActorPose"></select></label><label>اتجاه الجسم °<input id="initialActorFacing" type="number" min="0" max="360" step="any"></label><div class="two"><label>الموقع X (م)<input id="initialActorX" type="number" step="any"></label><label>الموقع Y (م)<input id="initialActorY" type="number" step="any"></label></div><div id="actorStatePoints"></div><button type="button" id="useCurrentActorAsOpening">اعتماد الحالة الحالية كبداية</button><small>هذه البداية محفوظة للممثل؛ تشغيل المشهد أو تعديل نهايته لا يغيّرها.</small>';
 $('objPose').closest('label').after(opening);for(const op of $('objPose').options)$('initialActorPose').append(op.cloneNode(true));
 const props=renderProperties;renderProperties=function(){props();const o=selected();opening.hidden=!o||o.type!=='actor';if(opening.hidden)return;const v=o.initialState||o;for(const [id,key] of [['initialActorPose','pose'],['initialActorFacing','facing'],['initialActorX','x'],['initialActorY','y']]){$(id).value=['x','y'].includes(key)?v[key]/PPM:v[key]??0;$(id).disabled=!!layer(o.layer)?.locked;}$('useCurrentActorAsOpening').disabled=!!layer(o.layer)?.locked;const box=$('actorStatePoints');box.replaceChildren();for(const e of o.stateChanges||[]){const row=document.createElement('div'),remove=document.createElement('button');const details=[];if(e.keys.some(k=>['pose','poseTransition','support'].includes(k)))details.push(Array.from($('objPose').options).find(op=>op.value===e.value.pose)?.textContent||e.value.pose);if(e.keys.includes('facing'))details.push(e.value.facing+'°');if(e.keys.includes('x')||e.keys.includes('y'))details.push('موقع '+(e.value.x/PPM).toFixed(2)+', '+(e.value.y/PPM).toFixed(2));if(e.keys.includes('leftArm'))details.push('الذراع اليسرى');if(e.keys.includes('rightArm'))details.push('الذراع اليمنى');row.textContent=`حالة ${e.atMovementId?'عند بداية':'بعد'} ${scene().paths.find(p=>p.id===(e.atMovementId||e.afterMovementId))?.code||e.time+' ث'}: ${details.join(' · ')} `;remove.type='button';remove.textContent='حذف';remove.disabled=!!layer(o.layer)?.locked;remove.onclick=()=>{snap();o.stateChanges=o.stateChanges.filter(x=>x.id!==e.id);mark('حُذفت نقطة حالة الممثل');renderScene();};row.append(remove);box.append(row);}};
 for(const [id,key] of [['initialActorPose','pose'],['initialActorFacing','facing'],['initialActorX','x'],['initialActorY','y']])$(id).onchange=()=>{const o=selected();if(!o||layer(o.layer)?.locked)return;const value=$(id).value;snap();capture(o);o.initialState[key]=key==='pose'?value:key==='facing'?normalFacing(Number(value)):Number(value)*PPM;if(key==='pose'){o.initialState.poseTransition=null;o.initialState.support=null;}if(!scene().paths.some(p=>p.actorObjectId===o.id))Object.assign(o,clone(o.initialState));mark('عُدّلت بداية الممثل');renderScene();};
 $('useCurrentActorAsOpening').onclick=()=>{const o=selected();if(!o||layer(o.layer)?.locked)return;snap();o.initialState=stateOf(o);mark('حُفظت الحالة الحالية كبداية للمشهد');renderScene();};
})();
