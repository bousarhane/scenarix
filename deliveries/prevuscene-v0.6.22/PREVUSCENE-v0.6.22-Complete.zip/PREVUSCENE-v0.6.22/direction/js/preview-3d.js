'use strict';
// Local 3D projection of the directing model. Playback stays in movement-timeline.js.
(function(){
 const dialog=document.createElement('dialog');dialog.id='preview3DDialog';dialog.className='preview-3d-dialog';
 dialog.innerHTML=`<header class="preview-3d-header"><div><b>معاينة الخشبة ثلاثية الأبعاد</b><small id="preview3DTitle"></small></div><button id="close3DBtn">العودة إلى المخطط 2D</button></header>
 <nav class="preview-3d-tools"><label>موقع الرؤية<select id="camera3D"><option value="audience">الجمهور — الوسط</option><option value="left">الجمهور — يسار الرسم</option><option value="right">الجمهور — يمين الرسم</option><option value="elevated">رؤية مرتفعة</option><option value="top">من الأعلى</option><option value="orbit">رؤية حرة</option></select></label><button id="play3DSceneBtn">▶ أفعال المشهد</button><button id="play3DMovementBtn">▶ الفعل المختار</button><button id="play3DShowBtn">▶ جميع المشاهد</button><button id="stop3DBtn">■ إيقاف</button><label><input id="paths3D" type="checkbox" checked> المسارات</label><label><input id="labels3D" type="checkbox" checked> الأسماء</label><button id="export3DBtn">صورة PNG</button></nav>
 <div class="preview-3d-body"><div id="preview3DCanvas" aria-label="خشبة ثلاثية الأبعاد"><p id="preview3DError" hidden role="alert"></p></div><aside class="preview-3d-properties"><h3>العنصر المختار</h3><p id="selected3DName">انقر مجسّمًا لاختياره</p><div id="selected3DFields" hidden><label>الارتفاع بالمتر<input id="height3D" type="number" min="0.05" max="10" step="0.05"></label><label>ارتفاع القاعدة عن الأرض<input id="elevation3D" type="number" min="0" max="10" step="0.05"></label><div id="actor3DFields"><label>الوضعية<select id="pose3D"></select></label><label>اتجاه النظر °<input id="facing3D" type="number" step="1"></label></div></div><h3>الفعل المختار</h3><select id="movement3D"><option value="">اختر فعلًا</option></select><p class="hint">اسحب لتدوير الكاميرا، واستعمل عجلة الفأرة لتقريب الرؤية. النقر على مجسّم يختاره في المخطط أيضًا.</p><p class="hint">مجسّمات بشرية بأجسام وملابس وملامح أكثر وضوحًا. التغيير التدريجي يتبع مدة الفعل، والتبديل الفوري يتبع اللحظة المحددة. الارتفاعات تضبط من هذه النافذة وتُحفظ مع المشروع.</p></aside></div><footer id="preview3DStatus" role="status">المعاينة جاهزة</footer>`;
 document.body.append(dialog);
 for(const op of $('objPose').options)$('pose3D').append(op.cloneNode(true));
 let T,renderer,world,camera,environment,objects,paths,ambient,key,fill,sceneKey='',stageKey='',request=null,loading=null;
 const records=new Map(),materials=new Map(),geometries=new Map();
 const fixtureRecords=new Map();let lightingGroup;let needsRender=true;
 let live=null,clock=0,previous=new Map(),orbit={yaw:0,pitch:.08,distance:12},pointer=null;
 const target=()=>new T.Vector3(0,.85,0);
 const host=$('preview3DCanvas');
 const defaults={actor:1.72,group:1.72,chair:.9,table:.75,desk:.75,sofa:.85,bed:.55,door:2.2,window:1.2,wall:2.5,column:2.5,stairs:.8,platform:.4,frontCurtain:4,pendrillon:4,frise:.6,cyclorama:4,tree:3,car:1.5,screen:2,prop:.5,note:.05,light:3};
 function height(o){return clamp(Number(o.height3D)||defaults[o.type]||.6,.05,10);}
 function elevation(o){return o.type==='actor'?StageSupport.elevation(o):clamp(Number(o.elevation3D)||0,0,10);}
 function material(color){if(!materials.has(color))materials.set(color,new T.MeshPhongMaterial({color,shininess:22}));return materials.get(color);}
 function geometry(kind){if(!geometries.has(kind))geometries.set(kind,kind==='sphere'?new T.SphereGeometry(1,16,12):kind==='cylinder'?new T.CylinderGeometry(1,1,1,14):new T.BoxGeometry(1,1,1));return geometries.get(kind);}
 function mesh(parent,kind,color,x,y,z,sx,sy,sz){const m=new T.Mesh(geometry(kind),material(color));m.position.set(x,y,z);m.scale.set(sx,sy,sz);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m;}
 function box(g,c,x,y,z,w,h,d){return mesh(g,'box',c,x,y,z,w,h,d);}
 function sphere(g,c,x,y,z,xr,yr,zr){return mesh(g,'sphere',c,x,y,z,xr,yr,zr);}
 function cylinder(g,c,x,y,z,r,h){return mesh(g,'cylinder',c,x,y,z,r,h,r);}
 function releaseTree(root){root.traverse(n=>{if(n.userData.privateGeometry)n.geometry?.dispose();if(n.userData.privateMaterial){n.material.map?.dispose();n.material.dispose();}});root.clear();}
 function label(root,o,y){const c=document.createElement('canvas');c.width=512;c.height=80;const ctx=c.getContext('2d');ctx.fillStyle='#142034dd';ctx.fillRect(0,0,512,80);ctx.fillStyle='#ffffff';ctx.font='bold 34px Arial';ctx.textAlign='center';ctx.direction='rtl';ctx.fillText(o.characterName||o.name||'',256,53,490);const tex=new T.CanvasTexture(c);const sprite=new T.Sprite(new T.SpriteMaterial({map:tex,depthTest:true}));sprite.scale.set(1.6,.25,1);sprite.position.set(0,y,0);sprite.userData.privateMaterial=true;root.add(sprite);return sprite;}
 // Smooth, clothed silhouettes share the existing animation skeleton.
 function shaped(parent,key,color,profile,depth=1){
  if(!geometries.has(key)){const curve=new T.CatmullRomCurve3(profile.map(([r,y])=>new T.Vector3(r,y,0)));geometries.set(key,new T.LatheGeometry(curve.getPoints(48).map(p=>new T.Vector2(Math.max(0,p.x),p.y)),24));}
  const m=new T.Mesh(geometries.get(key),material(color));m.scale.z=depth;m.castShadow=true;m.receiveShadow=true;parent.add(m);return m;
 }
 function buildRig(root,o){
  const body=new T.Group();root.add(body);const female=o.gender==='female',c=o.color||'#168bc2',skin=o.skinColor||'#d5a47c',dark='#29313d',hairColor=o.hairColor||'#332820';
  const pelvis=sphere(body,dark,0,1,0,female?.185:.165,.115,.115);
  const profile=female?[[0,-.5],[.19,-.48],[.175,-.32],[.12,-.13],[.13,.06],[.175,.23],[.19,.32],[.14,.42],[.065,.5],[0,.5]]:[[0,-.5],[.165,-.48],[.17,-.32],[.155,-.12],[.18,.08],[.22,.26],[.235,.32],[.17,.42],[.075,.5],[0,.5]];
  const torso=shaped(body,'actor-torso-'+(female?'female':'male'),c,profile,.64);
  const neckMesh=cylinder(body,skin,0,1.54,0,.052,.1);
  const head=new T.Group();body.add(head);
  sphere(head,skin,0,0,0,female?.103:.112,.14,.105);
  sphere(head,skin,0,-.059,.035,female?.072:.079,.072,.078);
  const nose=sphere(head,skin,0,-.008,.104,.017,.025,.027);
  for(const sign of [-1,1]){
   sphere(head,skin,sign*.106,-.01,0,.017,.033,.021);
   sphere(head,'#f1ede6',sign*.04,.028,.095,.022,.010,.010);
   sphere(head,'#382e28',sign*.04,.028,.103,.009,.009,.004);
   box(head,hairColor,sign*.04,.050,.097,.035,.006,.006);
  }
  sphere(head,'#965f51',0,-.052,.102,.029,.004,.006);
  if(!geometries.has('actor-hair-cap'))geometries.set('actor-hair-cap',new T.SphereGeometry(1,24,16,0,Math.PI*2,0,Math.PI*.38));
  const hair=new T.Mesh(geometries.get('actor-hair-cap'),material(hairColor));hair.scale.set(female?.113:.119,.146,.114);hair.castShadow=true;head.add(hair);
  if(female){
   sphere(head,hairColor,0,-.055,-.068,.116,.165,.072);
   for(const sign of [-1,1])sphere(head,hairColor,sign*.102,-.06,-.008,.025,.151,.071);
  }else sphere(head,hairColor,0,.018,-.070,.10,.108,.051);
  const segments={},joints={};
  for(const [name,color,radius] of [['lu',c,.064],['ll',skin,.047],['ru',c,.064],['rl',skin,.047],['lt',dark,.087],['lc',dark,.061],['rt',dark,.087],['rc',dark,.061]]){
   const r=radius*(female?.90:1),profile=[[0,-.5],[r*.64,-.49],[r*.82,-.35],[r,.10],[r*.92,.35],[r*.60,.49],[0,.5]];
   segments[name]=shaped(body,'actor-limb-'+name+'-'+(female?'female':'male'),color,profile);
  }
  for(const name of ['ls','le','lh','rs','re','rh','lk','la','rk','ra']){
   if(name.endsWith('h')){
    const hand=new T.Group();body.add(hand);sphere(hand,skin,0,.035,0,.032,.052,.022);
    for(let i=0;i<4;i++)sphere(hand,skin,(i-1.5)*.014,.083-Math.abs(i-1.5)*.005,0,.008,.023,.010);
    sphere(hand,skin,name==='lh'?-.034:.034,.037,.002,.012,.029,.013);joints[name]=hand;
   }else{const lower=['lk','la','rk','ra'].includes(name),elbow=['le','re'].includes(name),radius=lower?.055:elbow?.044:.060;joints[name]=sphere(body,lower?dark:elbow?skin:c,0,0,0,radius,radius,radius);}
  }
  const feet=[sphere(body,'#202329',0,0,0,.065,.047,.133),sphere(body,'#202329',0,0,0,.065,.047,.133)];
  return{body,pelvis,torso,head,hair,neckMesh,segments,joints,feet,nose,appearance:female?'female':'male'};
 }
 const v=a=>new T.Vector3(...a);
 function segment(m,a,b){const d=v(b).sub(v(a));m.position.copy(v(a).add(v(b)).multiplyScalar(.5));m.scale.y=d.length();m.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),d.normalize());}
 function bodyFrame(o,moving=false,time=0){
  const pose=o.pose||'standing';let hip=[0,.96,0],shoulder=[0,1.39,0],neck=[0,1.52,0],head=[0,1.65,0];
  let lk=[-.12,.53,0],rk=[.12,.53,0],la=[-.12,.09,0],ra=[.12,.09,0],le=[-.27,1.09,0],re=[.27,1.09,0],lh=[-.27,.82,0],rh=[.27,.82,0];
  if(pose==='sitting'||pose==='floorSitting'){
   const surface=StageSupport.target(o.support),scale=height(o)/1.8;const seat=pose==='floorSitting'?.09:surface&&o.support?.mode==='seat'?StageSupport.surface(surface,o)/scale:.45;
   hip=[0,seat+.15,0];shoulder=[0,seat+.51,0];neck=[0,seat+.64,0];head=[0,seat+.77,0];
   lk=[-.13,seat+.02,.4];rk=[.13,seat+.02,.4];la=[-.13,.09,.43];ra=[.13,.09,.43];
   if(pose==='floorSitting'){lk=[-.3,.16,.27];rk=[.3,.16,.27];la=[.15,.09,.48];ra=[-.15,.09,.48];}
   le=[-.24,seat+.25,.08];re=[.24,seat+.25,.08];lh=[-.14,seat+.11,.25];rh=[.14,seat+.11,.25];
  }else if(pose==='crouching'){
   hip=[0,.39,-.15];shoulder=[0,.8,.05];neck=[0,.92,.1];head=[0,1.05,.13];lk=[-.2,.43,.28];rk=[.2,.43,.28];la=[-.16,.09,0];ra=[.16,.09,0];le=[-.27,.56,.29];re=[.27,.56,.29];lh=[-.2,.47,.3];rh=[.2,.47,.3];
  }else if(pose==='kneeling'){
   hip=[0,.53,-.12];shoulder=[0,.96,-.12];neck=[0,1.09,-.12];head=[0,1.22,-.12];lk=[-.13,.09,.15];rk=[.13,.09,.15];la=[-.13,.09,-.37];ra=[.13,.09,-.37];le=[-.27,.72,-.08];re=[.27,.72,-.08];lh=[-.27,.51,-.08];rh=[.27,.51,-.08];
  }else if(pose==='bending'){
   shoulder=[0,1.15,.37];neck=[0,1.17,.52];head=[0,1.17,.66];le=[-.25,.88,.45];re=[.25,.88,.45];lh=[-.23,.66,.45];rh=[.23,.66,.45];
  }else if(['standing','side','moving'].includes(pose)&&moving){
   const running=o.gait?.type==='run',gait=Math.sin(o.gait?.phase??time*7)*(running?.34:.2);if(running){const bounce=Math.abs(Math.sin(o.gait?.phase??time*11))*.08;for(const joint of [hip,shoulder,neck,head])joint[1]+=bounce;shoulder[2]+=.08;neck[2]+=.1;head[2]+=.12;}lk[2]=gait;rk[2]=-gait;la[2]=gait*1.3;ra[2]=-gait*1.3;le[2]=-gait*.5;re[2]=gait*.5;lh[2]=-gait;rh[2]=gait;
  }
  const ls=[-.23,...shoulder.slice(1)],rs=[.23,...shoulder.slice(1)];
  let bodyPosition=[0,0,0],bodyRotation=[0,0,0];
  if(['lyingBack','lyingFront','lyingSide'].includes(pose)){
   bodyRotation=[pose==='lyingFront'?Math.PI/2:-Math.PI/2,0,0];bodyPosition=[0,.2,pose==='lyingFront'?-.85:.85];
   if(pose==='lyingSide'){bodyRotation=[0,0,Math.PI/2];bodyPosition=[.85,.36,0];}
  }
  return{hip,neck,head,ls,le,lh,rs,re,rh,lk,la,rk,ra,bodyPosition,bodyRotation};
 }
 function blendBodyFrames(a,b,progress){
  const result={};for(const key of ['hip','neck','head','ls','le','lh','rs','re','rh','lk','la','rk','ra','bodyPosition'])result[key]=a[key].map((value,i)=>value+(b[key][i]-value)*progress);
  const qa=a.quaternion||new T.Quaternion().setFromEuler(new T.Euler(...a.bodyRotation)),qb=b.quaternion||new T.Quaternion().setFromEuler(new T.Euler(...b.bodyRotation));
  result.quaternion=qa.clone().slerp(qb,progress);return result;
 }
 function frameForTransition(state,o,depth=0){
  const legacy=state.seatTargetId?StageSupport.bind(o,scene().objects.find(x=>x.id===state.seatTargetId),'sitting'):null;
  const a=state.fromState&&depth<12?frameForTransition(state.fromState,o,depth+1):bodyFrame({...o,poseTransition:null,pose:state.from,support:Object.hasOwn(state,'fromSupport')?state.fromSupport:legacy});
  const b=bodyFrame({...o,poseTransition:null,pose:state.to,support:Object.hasOwn(state,'toSupport')?state.toSupport:legacy});return blendBodyFrames(a,b,clamp(Number(state.progress)||0,0,1));
 }
 // Resolve an arm in the actor's current body frame, including seated/lying poses.
 function armFrame(state,side,frame,o,depth=0){
  const l=side==='left',shoulder=v(frame[l?'ls':'rs']),base={elbow:frame[l?'le':'re'],hand:frame[l?'lh':'rh']};
  if(!state||depth>16)return base;
  if(Object.hasOwn(state,'progress')){const a=armFrame(state.from,side,frame,o,depth+1),b=armFrame(state.to,side,frame,o,depth+1),t=clamp(Number(state.progress)||0,0,1);const interpolate=(first,second)=>{const length=first.length()+(second.length()-first.length())*t;if(first.lengthSq()<1e-10||second.lengthSq()<1e-10)return first.lerp(second,t);const direction=first.clone().normalize(),rotation=new T.Quaternion().setFromUnitVectors(direction,second.clone().normalize());return direction.applyQuaternion(new T.Quaternion().slerp(rotation,t)).multiplyScalar(length);};const elbow=shoulder.clone().add(interpolate(v(a.elbow).sub(shoulder),v(b.elbow).sub(shoulder))),hand=elbow.clone().add(interpolate(v(a.hand).sub(v(a.elbow)),v(b.hand).sub(v(b.elbow))));return{elbow:elbow.toArray(),hand:hand.toArray()};}
  if(state.preset==='rest')return base;
  const sign=l?-1:1,dirs={raised:[sign*.08,1,0],lowered:[sign*.08,-1,.04],side:[sign,0,0],forward:[0,0,1]};let direction=v(dirs[state.preset]||[0,0,1]);
  if(state.preset==='point'){
   const target=ArmGestures.point(state,id=>live?.scene===scene()?live.positions.get(id):null);
   if(target){
    const yaw=new T.Quaternion().setFromAxisAngle(new T.Vector3(0,1,0),-(Number(o.facing)||0)*Math.PI/180),q=frame.quaternion||new T.Quaternion().setFromEuler(new T.Euler(...frame.bodyRotation)),sy=height(o)/1.8,sx=sy*((Number.isFinite(Number(o.w))&&Number(o.w)>0?Number(o.w):60)/60);
    const local=new T.Vector3((target.x-o.x)/PPM,target.z-elevation(o),(target.y-o.y)/PPM).applyQuaternion(yaw).sub(v(frame.bodyPosition)).applyQuaternion(q.clone().invert());local.set(local.x/sx,local.y/sy,local.z/sy);direction=local.sub(shoulder);
   }
  }
  if(direction.lengthSq()<1e-10)direction.set(0,0,1);direction.normalize();
  const upper=.29,lower=.27,bend=clamp(Number(state.bend)||0,0,135)*Math.PI/180,d=Math.sqrt(upper*upper+lower*lower+2*upper*lower*Math.cos(bend)),a=(upper*upper-lower*lower+d*d)/(2*d),h=Math.sqrt(Math.max(0,upper*upper-a*a));
  let normal=new T.Vector3(0,0,1).addScaledVector(direction,-direction.z);if(normal.lengthSq()<.001)normal=new T.Vector3(0,1,0).addScaledVector(direction,-direction.y);normal.normalize();
  return{elbow:shoulder.clone().addScaledVector(direction,a).addScaledVector(normal,h).toArray(),hand:shoulder.clone().addScaledVector(direction,d).toArray()};
 }
 function applyArms(frame,o){for(const side of ['left','right']){if(!o.arms?.[side])continue;const arm=armFrame(o.arms[side],side,frame,o),l=side==='left';frame[l?'le':'re']=arm.elbow;frame[l?'lh':'rh']=arm.hand;}return frame;}
 function poseRig(rig,o,moving=false,time=0){
  const frame=applyArms(o.poseTransition?frameForTransition(o.poseTransition,o):bodyFrame(o,moving,time),o);
  const {hip,neck,head,ls,le,lh,rs,re,rh,lk,la,rk,ra}=frame;
  rig.pelvis.position.copy(v(hip));segment(rig.torso,hip,neck);rig.torso.scale.y=v(neck).distanceTo(v(hip));rig.head.position.copy(v(head));
  rig.head.quaternion.copy(rig.torso.quaternion);
  const neckTop=v(head).add(new T.Vector3(0,-.12,0));segment(rig.neckMesh,neck,neckTop);
  for(const [hand,elbow] of [['lh','le'],['rh','re']])rig.joints[hand].quaternion.setFromUnitVectors(new T.Vector3(0,1,0),v(frame[hand]).sub(v(frame[elbow])).normalize());
  const positions={ls,le,lh,rs,re,rh,lk,la,rk,ra};for(const [name,p]of Object.entries(positions))rig.joints[name].position.copy(v(p));
  for(const [name,a,b]of [['lu',ls,le],['ll',le,lh],['ru',rs,re],['rl',re,rh],['lt',[-.12,...hip.slice(1)],lk],['lc',lk,la],['rt',[.12,...hip.slice(1)],rk],['rc',rk,ra]])segment(rig.segments[name],a,b);
  rig.feet[0].position.copy(v(la).add(new T.Vector3(0,-.025,.065)));rig.feet[1].position.copy(v(ra).add(new T.Vector3(0,-.025,.065)));
  rig.body.position.copy(v(frame.bodyPosition));rig.body.quaternion.copy(frame.quaternion||new T.Quaternion().setFromEuler(new T.Euler(...frame.bodyRotation)));
  rig.body.scale.set(height(o)/1.8*((Number.isFinite(Number(o.w))&&Number(o.w)>0?Number(o.w):60)/60),height(o)/1.8,height(o)/1.8);rig.body.userData.hip=hip;rig.body.userData.pose=o.pose;rig.body.userData.transition=o.poseTransition||null;
 }
 function scenery(root,o){
  const c=o.color||'#8c704c',w=o.w/PPM,d=o.h/PPM,h=height(o),leg='#3b3028';
  const fourLegs=(top,ww=w,dd=d)=>{for(const x of [-ww*.38,ww*.38])for(const z of [-dd*.38,dd*.38])box(root,leg,x,top/2,z,.07,top,.07);};
  switch(o.type){
   case 'chair':{const seat=StageSupport.surface(o);box(root,c,0,seat-.04,0,w,.08,d*.85);box(root,c,0,h*.79,-d*.44,w,h*.42,.075);fourLegs(Math.max(.02,seat-.08));break;}
   case 'table':case 'desk':box(root,c,0,h-.05,0,w,.1,d);fourLegs(h-.1);if(o.type==='desk')box(root,c,w*.28,h*.44,0,w*.32,h*.8,d*.86);break;
   case 'sofa':case 'bed':{const seat=StageSupport.surface(o),bottom=Math.min(h*.12,seat*.5);box(root,c,0,(seat+bottom)/2,0,w,seat-bottom,d);if(o.type==='sofa'){box(root,c,0,h*.79,-d*.4,w,h*.42,d*.2);for(const x of [-w*.45,w*.45])box(root,c,x,h*.6,0,w*.1,h*.65,d);}else box(root,'#ded8c9',-w*.32,h*.79,0,w*.24,.1,d*.8);break;}
   case 'door':for(const x of [-w*.46,w*.46])box(root,c,x,h/2,0,w*.08,h,.12);box(root,c,0,h-.05,0,w,.1,.12);break;
   case 'window':for(const x of [-w*.46,0,w*.46])box(root,c,x,h/2,0,.06,h,.1);for(const y of [.04,h/2,h-.04])box(root,c,0,y,0,w,.06,.1);break;
   case 'column':cylinder(root,c,0,h/2,0,w/2,h);break;
   case 'stairs':{const n=StageSupport.stepCount(o);for(let i=0;i<n;i++)box(root,c,0,h*(i+1)/(2*n),(o.stairDirection==='depth'?1:-1)*(d/2-d*(i+.5)/n),w,h*(i+1)/n,d/n);break;}
   case 'platform':if(o.platformShape==='circle'){const disk=cylinder(root,c,0,h/2,0,w/2,h);disk.scale.z=d/2;}else box(root,c,0,h/2,0,w,h,d);break;
   case 'cyclorama':box(root,c,0,h/2,0,w,h,d);break;
   case 'frontCurtain':case 'pendrillon':case 'frise':{const open=o.type==='frontCurtain'?clamp(Number(o.curtainOpen)||0,0,100)/100:0,panel=o.type==='frontCurtain'?w/2*(1-open*.9):w,starts=o.type==='frontCurtain'?[-w/2,w/2-panel]:[-w/2];box(root,'#626b78',0,h+.04,0,w,.07,.07);for(const x of starts){box(root,c,x+panel/2,h/2,0,panel,h,d);for(let i=0;i<8;i++)box(root,c,x+panel*(i+.5)/8,h/2,d*.52,panel/22,h,d*.4);}break;}
   case 'tree':cylinder(root,'#705039',0,h*.35,0,w*.08,h*.7);sphere(root,c,0,h*.73,0,w*.6,h*.3,d*.6);break;
   case 'car':box(root,c,0,h*.35,0,w,h*.5,d);box(root,'#8ab4c5',0,h*.7,0,w*.52,h*.4,d*.85);for(const x of [-w*.33,w*.33])for(const z of [-d*.45,d*.45]){const tire=cylinder(root,'#1b2027',x,h*.2,z,h*.2,.12);tire.rotation.x=Math.PI/2;}break;
   case 'light':{const light=new T.SpotLight(c,5,Math.max(w,d)*4,Math.PI/5,.6,1);light.position.set(0,h,0);light.target.position.set(0,0,0);root.add(light,light.target);sphere(root,c,0,h,0,.1,.1,.1);break;}
   case 'group':for(const x of [-w*.3,0,w*.3]){const person=new T.Group();person.position.x=x;root.add(person);const rig=buildRig(person,{...o,type:'actor',w:45});poseRig(rig,{...o,type:'actor',w:45,pose:'standing'});}break;
   default:box(root,c,0,h/2,0,w,h,d);
  }
 }
 function build(o){const root=new T.Group();root.userData.id=o.id;objects.add(root);const record={root,rig:null,signature:JSON.stringify([o.type,o.gender,o.skinColor,o.hairColor,o.color,o.w,o.h,height(o),o.name,o.characterName,o.platformShape,o.curtainOpen,o.stairSteps,o.stairDirection]),label:null};
  if(o.type==='actor')record.rig=buildRig(root,o);else scenery(root,o);
  record.label=label(root,o,height(o)+.3);
  const ring=new T.Mesh(new T.RingGeometry(Math.max(Number(o.w)||60,Number(o.h)||60)/PPM*.52,Math.max(Number(o.w)||60,Number(o.h)||60)/PPM*.52+.04,48),new T.MeshBasicMaterial({color:'#ffc354',side:T.DoubleSide}));ring.rotation.x=-Math.PI/2;ring.position.y=.025;ring.userData.privateGeometry=true;ring.userData.privateMaterial=true;root.add(ring);ring.userData.selectionHelper=true;record.selection=ring;records.set(o.id,record);return record;
 }
 function syncObjects(){needsRender=true;
  const sc=scene(),w=state.stage.width,d=state.stage.depth;const visible=sc.objects.filter(o=>layer(o.layer)?.visible!==false&&!(o.type==='light'&&state.lightingByScene?.[sc.id]));
  const ids=new Set(visible.map(o=>o.id));for(const [id,r]of records)if(!ids.has(id)){objects.remove(r.root);releaseTree(r.root);records.delete(id);}
  for(const original of visible){const motion=live?.scene===sc?live.positions.get(original.id):null;const o={...original,...(motion||{})};
   const signature=JSON.stringify([o.type,o.gender,o.skinColor,o.hairColor,o.color,o.w,o.h,height(o),o.name,o.characterName,o.platformShape,o.curtainOpen,o.stairSteps,o.stairDirection]);let r=records.get(o.id);
   if(r&&r.signature!==signature){objects.remove(r.root);releaseTree(r.root);records.delete(o.id);r=null;}if(!r)r=build(o);
   r.root.position.set(o.x/PPM-w/2,elevation(o),o.y/PPM-d/2);r.root.rotation.y=(o.type==='actor'?Number(o.facing)||0:-(Number(o.rotation)||0))*Math.PI/180;
   r.label.visible=$('labels3D').checked;
   if(r.rig){const before=previous.get(o.id),moving=!!motion&&!!before&&Math.hypot(o.x-before.x,o.y-before.y)>.001;poseRig(r.rig,o,moving,clock);r.root.userData.pose=o.pose;r.root.userData.facing=o.facing;}
   r.root.userData.selected=o.id===selectedId;r.selection.visible=o.id===selectedId;
  }
 }
 function rebuildEnvironment(){
  releaseTree(environment);const w=state.stage.width,d=state.stage.depth;
  const outline=svgEl('path',{d:stagePath()}),len=outline.getTotalLength(),shape=new T.Shape(),polygon=[];
  for(let i=0;i<=160;i++){const p=outline.getPointAtLength(len*i/160),x=p.x/PPM-w/2,y=d/2-p.y/PPM;polygon.push([x,-y]);if(i===0)shape.moveTo(x,y);else shape.lineTo(x,y);}shape.closePath();
  const floor=new T.Mesh(new T.ExtrudeGeometry(shape,{depth:.14,bevelEnabled:false}),material('#b9ad8b'));floor.rotation.x=-Math.PI/2;floor.position.y=-.14;floor.receiveShadow=true;floor.userData.privateGeometry=true;environment.add(floor);
  function gridAt(axis,value){
   const intersections=[];for(let i=0;i<polygon.length-1;i++){const a=polygon[i],b=polygon[i+1];if((a[axis]<=value&&b[axis]>value)||(b[axis]<=value&&a[axis]>value))intersections.push(a[1-axis]+(value-a[axis])/(b[axis]-a[axis])*(b[1-axis]-a[1-axis]));}
   intersections.sort((a,b)=>a-b);for(let i=0;i+1<intersections.length;i+=2){const a=intersections[i],b=intersections[i+1];line(environment,axis===0?[[value,.007,a],[value,.007,b]]:[[a,.007,value],[b,.007,value]],'#8d876d');}
  }
  if(state.stage.showGrid){for(let x=-w/2;x<=w/2;x+=1)gridAt(0,x);for(let z=-d/2;z<=d/2;z+=1)gridAt(1,z);}
  line(environment,polygon.map(([x,z])=>[x,.012,z]),'#514837');
 }
 function line(parent,points,color){const geo=new T.BufferGeometry().setFromPoints(points.map(v)),mat=new T.LineBasicMaterial({color});const l=new T.Line(geo,mat);l.userData.privateGeometry=true;l.userData.privateMaterial=true;parent.add(l);return l;}
 function syncPaths(){
  releaseTree(paths);if(layer('movement')?.visible===false)return;
  const entries=window.StageConstraints?ActorContinuity.prepare(compileMovementSchedule()):scene().paths.map(path=>({path}));
  for(const {path:p} of entries){if(!actionChannels(p).position||p.actionKind==='state')continue;
   const actor=scene().objects.find(o=>o.id===p.actorObjectId),profile=window.StageConstraints&&actor?StageConstraints.profile(p,actor):null;
   if(profile){const points=profile.points.map(q=>[q.x/PPM-state.stage.width/2,q.height+.025,q.y/PPM-state.stage.depth/2]);line(paths,points,p.color||'#d8a344');const bad=new Set(profile.issues.map(i=>i.t));let segment=[];for(let i=0;i<profile.points.length;i++){if(bad.has(profile.points[i].t))segment.push(points[i]);else if(segment.length){segment.push(points[i]);line(paths,segment,'#dc2626');segment=[];}}if(segment.length)line(paths,segment,'#dc2626');}
   else{const track=svgEl('path',{d:movementPathD(p)}),len=track.getTotalLength(),points=[];for(let i=0;i<=120;i++){const q=track.getPointAtLength(len*i/120);points.push([q.x/PPM-state.stage.width/2,.02,q.y/PPM-state.stage.depth/2]);}line(paths,points,p.color||'#d8a344');}
  }paths.visible=$('paths3D').checked;
 }
 function fields(){const o=selected();$('selected3DName').textContent=o?(o.characterName||o.name):'انقر مجسّمًا لاختياره';$('selected3DFields').hidden=!o;
  if(o){$('height3D').value=height(o);$('elevation3D').value=elevation(o);$('actor3DFields').hidden=o.type!=='actor';$('pose3D').value=o.pose||'standing';$('facing3D').value=o.facing||0;for(const id of ['height3D','elevation3D','pose3D','facing3D'])$(id).disabled=!!layer(o.layer)?.locked;}
  const select=$('movement3D');select.innerHTML='<option value="">اختر فعلًا</option>';for(const p of scene().paths){const op=document.createElement('option');op.value=p.id;op.textContent=movementDisplayName(p);select.append(op);}select.value=selectedPathId||'';
  $('preview3DTitle').textContent=scene().title;$('play3DMovementBtn').disabled=!selectedPathId;
 }
 function syncLighting(){needsRender=true;
  if(!renderer)return;
  const plan=state.lightingByScene?.[scene().id],fixtures=window.LightTimeline?LightTimeline.sample(plan||{},clock):[];
  const ids=new Set(fixtures.map(f=>f.id));for(const [id,r] of fixtureRecords)if(!ids.has(id)){lightingGroup.remove(r.light,r.target);r.light.shadow.map?.dispose();fixtureRecords.delete(id);}
  let shadowCount=0;
  for(const f of fixtures){let r=fixtureRecords.get(f.id);if(!r){const target=new T.Object3D(),light=new T.SpotLight();light.target=target;lightingGroup.add(light,target);r={light,target};fixtureRecords.set(f.id,r);}
   const aim=LightTimeline.aim(f,id=>{if(window.SharedStage?.inspect&&SharedStage.resolve(id,live?.positions))return SharedStage.resolve(id,live?.positions);const original=scene().objects.find(o=>o.id===id);if(!original)return null;const o={...original,...(live?.positions.get(id)||{})};return{...o,elevation:elevation(o),bodyHeight:o.pose==='crouching'?.8:o.pose==='sitting'?1.05:height(o)};},state.stage);
   const l=r.light;l.position.set(Number(f.x)-state.stage.width/2,aim.height,Number(f.y)-state.stage.depth/2);r.target.position.set(aim.x-state.stage.width/2,aim.z,aim.y-state.stage.depth/2);
   l.color.set(f.color||'#ffffff');l.intensity=aim.missing?0:LightTimeline.level(f)/100*12;l.angle=clamp((Number(f.beamAngle)||35)*Math.PI/360,.02,Math.PI/2-.01);l.penumbra=.4;l.decay=1;l.distance=Math.max(20,state.stage.width+state.stage.depth+10);l.castShadow=l.intensity>0&&shadowCount++<4;l.shadow.mapSize.set(512,512);l.shadow.bias=-.001;
  }
  const brightness=clamp(Number(plan?.ambientLight??scene().ambientLight??100),0,100)/100;ambient.intensity=brightness*.7;key.intensity=brightness*2;fill.intensity=brightness*.8;
 }
 function sync(){if(!renderer||!dialog.open)return;const sk=JSON.stringify([state.stage.type,state.stage.width,state.stage.depth,state.stage.showGrid]);if(sk!==stageKey){stageKey=sk;rebuildEnvironment();setCamera($('camera3D').value);}
  if(sceneKey!==scene().id){sceneKey=scene().id;live=null;clock=0;previous.clear();}
  syncObjects();syncPaths();fields();syncLighting();
 }
 function setCamera(mode){if(!camera)return;const w=state.stage.width,d=state.stage.depth,t=target();let p;
  if(mode==='audience'||mode==='left'||mode==='right')p=new T.Vector3(mode==='left'?-w*.55:mode==='right'?w*.55:0,1.65,d/2+Math.max(6,w*.85));
  else if(mode==='top')p=new T.Vector3(0,Math.max(w,d)*1.25,.001);
  else if(mode==='elevated')p=new T.Vector3(w*.65,w*.8,d*.95);
  if(p){const delta=p.sub(t);orbit={yaw:Math.atan2(delta.x,delta.z),pitch:Math.asin(delta.y/delta.length()),distance:delta.length()};}cameraPosition();
 }
 function cameraPosition(){needsRender=true;const t=target(),c=Math.cos(orbit.pitch);camera.position.set(t.x+Math.sin(orbit.yaw)*c*orbit.distance,t.y+Math.sin(orbit.pitch)*orbit.distance,t.z+Math.cos(orbit.yaw)*c*orbit.distance);camera.lookAt(t);}
 function resize(){needsRender=true;if(!renderer)return;const width=host.clientWidth,height=host.clientHeight;if(!width||!height)return;renderer.setSize(width,height,false);camera.aspect=width/height;camera.updateProjectionMatrix();}
 function tick(){if(!dialog.open){request=null;return;}if(needsRender){renderer.render(world,camera);needsRender=false;}$('preview3DStatus').textContent=($('statusText').textContent||'')+' · '+(scene().title||'');request=requestAnimationFrame(tick);}
 function pick(ev){if(document.body.classList.contains('shared-preview'))return;const bounds=renderer.domElement.getBoundingClientRect(),mouse=new T.Vector2((ev.clientX-bounds.left)/bounds.width*2-1,-(ev.clientY-bounds.top)/bounds.height*2+1),ray=new T.Raycaster();camera.updateMatrixWorld(true);world.updateMatrixWorld(true);ray.setFromCamera(mouse,camera);const hits=ray.intersectObjects(objects.children,true).filter(h=>{if(h.object.isSprite||h.object.userData.selectionHelper)return false;for(let o=h.object;o;o=o.parent)if(!o.visible)return false;return true;});let hit=hits[0]?.object;while(hit&&!hit.userData.id)hit=hit.parent;
  stopSimulation();selectedId=hit?.userData.id||null;selectedPathId=null;renderScene();
 }
 function init(){T=window.THREE;world=new T.Scene();world.background=new T.Color('#111a29');camera=new T.PerspectiveCamera(48,1,.05,150);renderer=new T.WebGLRenderer({antialias:true,preserveDrawingBuffer:true});renderer.setPixelRatio(Math.min(devicePixelRatio||1,2));renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;renderer.outputColorSpace=T.SRGBColorSpace;host.prepend(renderer.domElement);
  environment=new T.Group();objects=new T.Group();paths=new T.Group();lightingGroup=new T.Group();world.add(environment,objects,paths,lightingGroup);ambient=new T.AmbientLight('#e4edff',.7);fill=new T.HemisphereLight('#cadcff','#5b4932',.8);key=new T.DirectionalLight('#fff1d1',2);key.position.set(-3,8,6);key.castShadow=true;key.shadow.mapSize.set(2048,2048);Object.assign(key.shadow.camera,{left:-12,right:12,top:12,bottom:-12,near:.5,far:35});key.shadow.bias=-.0005;world.add(ambient,key,fill);
  new ResizeObserver(resize).observe(host);const canvas=renderer.domElement;canvas.style.touchAction='none';
  canvas.addEventListener('pointerdown',ev=>{pointer={x:ev.clientX,y:ev.clientY,yaw:orbit.yaw,pitch:orbit.pitch,moved:false};canvas.setPointerCapture(ev.pointerId);});
  canvas.addEventListener('pointermove',ev=>{if(!pointer)return;const dx=ev.clientX-pointer.x,dy=ev.clientY-pointer.y;if(Math.hypot(dx,dy)>5)pointer.moved=true;if(!pointer.moved)return;orbit.yaw=pointer.yaw-dx*.006;orbit.pitch=clamp(pointer.pitch+dy*.006,.01,Math.PI/2-.015);$('camera3D').value='orbit';cameraPosition();});
  canvas.addEventListener('pointerup',ev=>{if(pointer&&!pointer.moved)pick(ev);pointer=null;if(canvas.hasPointerCapture(ev.pointerId))canvas.releasePointerCapture(ev.pointerId);});canvas.addEventListener('pointercancel',()=>{pointer=null;});
  canvas.addEventListener('wheel',ev=>{ev.preventDefault();orbit.distance=clamp(orbit.distance*Math.exp(ev.deltaY*.001),2,50);cameraPosition();},{passive:false});
  canvas.addEventListener('webglcontextlost',ev=>{ev.preventDefault();$('preview3DError').hidden=false;$('preview3DError').textContent='توقف العرض الرسومي. أغلق المعاينة وأعد فتح التطبيق.';});
 }
 async function open(){if(document.body.classList.contains('auth-locked'))return;dialog.showModal();$('preview3DError').hidden=true;
  try{if(!window.THREE){if(!loading)loading=new Promise((resolve,reject)=>{const script=document.createElement('script');script.src='assets/vendor/three-r160.min.js';script.onload=resolve;script.onerror=()=>reject(new Error('تعذر تحميل محرك العرض المحلي'));document.head.append(script);});await loading;}
   if(!renderer)init();if(!dialog.open)return;resize();sync();setCamera($('camera3D').value);if(!request)tick();
  }catch(err){$('preview3DError').hidden=false;$('preview3DError').textContent='تعذر فتح المعاينة ثلاثية الأبعاد. '+err.message;console.error(err);}
 }
 function edit(key,value){stopSimulation();const o=selected();if(!o||layer(o.layer)?.locked)return;snap();o[key]=value;if(key==='elevation3D'&&o.type==='actor')StageSupport.detach(o);if(key==='pose')o.poseTransition=null;mark('عُدلت خصائص المجسّم');renderScene();}
 $('open3DPreviewBtn').onclick=open;$('close3DBtn').onclick=()=>dialog.close();dialog.addEventListener('close',()=>{if(request)cancelAnimationFrame(request);request=null;pointer=null;});
 $('camera3D').onchange=()=>setCamera($('camera3D').value);$('paths3D').onchange=()=>{if(paths){paths.visible=$('paths3D').checked;needsRender=true;}};$('labels3D').onchange=()=>{if(renderer)syncObjects();};
 $('height3D').onchange=()=>edit('height3D',clamp(Number($('height3D').value)||.05,.05,10));$('elevation3D').onchange=()=>edit('elevation3D',clamp(Number($('elevation3D').value)||0,0,10));$('pose3D').onchange=()=>edit('pose',$('pose3D').value);$('facing3D').onchange=()=>edit('facing',normalFacing(Number($('facing3D').value)));
 $('movement3D').onchange=()=>{const id=$('movement3D').value;stopSimulation();selectedId=null;selectedPathId=id||null;renderScene();};
 $('play3DSceneBtn').onclick=()=>simulateAllMovements();$('play3DMovementBtn').onclick=()=>simulateMovement();$('play3DShowBtn').onclick=()=>ScenePlayback.start(false);$('stop3DBtn').onclick=()=>stopSimulation();
 $('export3DBtn').onclick=()=>{if(!renderer)return;renderer.render(world,camera);const a=document.createElement('a');a.href=renderer.domElement.toDataURL('image/png');a.download=(scene().title||'خشبة')+'-3D.png';a.click();};
 new MutationObserver(()=>{if(document.body.classList.contains('auth-locked')&&dialog.open)dialog.close();}).observe(document.body,{attributes:true,attributeFilter:['class']});
 const baseRender=renderScene;renderScene=function(){baseRender();sync();};
 window.Stage3D={open,sync,height,elevation,
  movementFrame(sc,positions,sec){if(live?.scene!==sc)previous.clear();else previous=new Map(live.positions);live={scene:sc,positions:new Map(positions)};clock=sec;if(dialog.open&&renderer){syncObjects();syncLighting();}window.SharedLights2D?.paint(sec);},
  endMovement(){live=null;previous.clear();},
  inspect(){return{open:dialog.open,sceneId:sceneKey,camera:camera?.position.toArray(),rendered:!!renderer,lights:[...fixtureRecords].map(([id,r])=>({id,position:r.light.position.toArray(),target:r.target.position.toArray(),intensity:r.light.intensity,color:r.light.color.getHexString()})),items:[...records].map(([id,r])=>({id,appearance:r.rig?.appearance||null,position:r.root.position.toArray(),yaw:r.root.rotation.y,pose:r.root.userData.pose,height:height(scene().objects.find(o=>o.id===id)||{}),support:scene().objects.find(o=>o.id===id)?.support||null,hipWorld:r.rig?(r.root.updateWorldMatrix(true,true),r.rig.body.localToWorld(v(r.rig.body.userData.hip)).toArray()):null,arms:r.rig?Object.fromEntries(['ls','le','lh','rs','re','rh','lk','la','rk','ra'].map(name=>[name,(r.root.updateWorldMatrix(true,true),r.rig.joints[name].getWorldPosition(new T.Vector3()).toArray())])):null,hip:r.rig?.body.userData.hip,transition:r.rig?.body.userData.transition}))};}
 };
})();
