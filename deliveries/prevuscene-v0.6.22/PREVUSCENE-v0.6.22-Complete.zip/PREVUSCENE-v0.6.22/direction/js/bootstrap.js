'use strict';
// Public API and application bootstrap
function renderAll(){ensureState();state.stage.width=Math.max(1,Number(state.stage.width)||10);state.stage.depth=Math.max(1,Number(state.stage.depth)||6);state.stage.height=Math.max(1,Number(state.stage.height)||4);$('stageType').value=state.stage.type;$('stageWidth').value=state.stage.width;$('stageWidth').disabled=false;$('stageDepth').value=state.stage.depth;$('gridSize').value=state.stage.gridSize;$('backgroundOpacity').value=state.stage.backgroundOpacity;$('backgroundFit').value=state.stage.backgroundFit;renderSummary();renderLayers();renderActors();renderStage()}
window.MS2D={
 getState:()=>state,setState:v=>{state=v;ensureState();renderAll()},scene,selected:()=>selected(),getSelectedId:()=>selectedId,
 setSelectedId:id=>{selectedId=id;selectedPathId=null;renderScene()},snap,mark,renderAll,renderScene,fit,clone,
 selectScene,actorById,actById,m2p,p2m,layer,ensureState
};
renderAll();setTimeout(fit,80);
