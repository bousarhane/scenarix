(()=>{'use strict';
const $=id=>document.getElementById(id),api=window.MS2D;if(!api)return;
let ambientOrigin=null;
function sync(){const s=api.scene(),v=Number.isFinite(+s.ambientLight)?+s.ambientLight:100;$('ambientLight').value=v;$('ambientLightValue').textContent=v+'%'}
function setAmbient(v){api.snap();api.scene().ambientLight=Math.max(0,Math.min(100,+v));api.mark('تغيرت الإضاءة العامة');api.renderAll();sync()}
$('ambientLight').addEventListener('input',e=>{const s=api.scene();if(!ambientOrigin||ambientOrigin.id!==s.id)ambientOrigin={id:s.id,value:s.ambientLight};s.ambientLight=+e.target.value;$('ambientLightValue').textContent=e.target.value+'%';api.renderAll();});
$('ambientLight').addEventListener('change',e=>{const s=api.scene(),v=+e.target.value;if(ambientOrigin?.id===s.id)s.ambientLight=ambientOrigin.value;api.snap();s.ambientLight=v;ambientOrigin=null;api.mark('تغيرت الإضاءة العامة');api.renderAll();sync();});
$('stageBlackoutBtn').onclick=()=>setAmbient(0);$('stageFullLightBtn').onclick=()=>setAmbient(100);
$('addLightBtn').onclick=()=>{const st=api.getState(),s=api.scene();api.snap();const light={id:crypto.randomUUID(),type:'light',layer:'lighting',name:`إضاءة ${s.objects.filter(o=>o.type==='light').length+1}`,x:api.m2p(st.stage.width/2),y:api.m2p(st.stage.depth/2),w:api.m2p(2.4),h:api.m2p(2.4),rotation:0,color:'#ffd76a',notes:'',intensity:100};s.objects.push(light);api.setSelectedId(light.id);api.mark('أضيفت دائرة ضوء');api.renderAll()};
document.querySelector('[data-tab="lightingTab"]')?.addEventListener('click',()=>setTimeout(sync,0));sync();
})();
