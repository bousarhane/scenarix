(()=>{'use strict';
const $=id=>document.getElementById(id),api=window.MS2D;if(!api)return;
const now=()=>new Date().toLocaleString('ar-MA');
function scene(){return api.scene()}
function ensure(){window.MS2DBlocking?.ensure();const s=scene();s.tableaux=s.tableaux||[];s.versions=s.versions||[];s.journal=s.journal||[];}
function snapshotData(){const s=scene();return {objects:api.clone(s.objects),paths:api.clone(s.paths),ambientLight:s.ambientLight,capturedAt:new Date().toISOString()};}
function render(){ensure();const s=scene();
 $('tableauList').innerHTML=s.tableaux.length?'':'<div class="actor-registry-empty">لا توجد صور مسرحية محفوظة.</div>';
 s.tableaux.forEach((t,i)=>{const d=document.createElement('div');d.className='scene-state-card';d.innerHTML=`<div class="scene-state-head"><b>${htmlText(t.name)}</b><button data-a="restore">استعادة</button><button data-a="delete">حذف</button></div><small>${htmlText(t.createdLabel||'')} — ${t.objects.length} عنصر</small>`;d.querySelector('[data-a=restore]').onclick=()=>{api.snap();s.objects=api.clone(t.objects);s.paths=api.clone(t.paths||[]);if(t.ambientLight!=null)s.ambientLight=t.ambientLight;api.mark('استعيدت الصورة المسرحية');api.renderAll();render();};d.querySelector('[data-a=delete]').onclick=()=>{api.snap();s.tableaux.splice(i,1);api.mark('حُذفت الصورة المسرحية');render();};$('tableauList').append(d);});
 $('journalList').innerHTML=s.journal.length?'':'<div class="actor-registry-empty">لا توجد قرارات مسجلة.</div>';
 [...s.journal].reverse().forEach(j=>{const d=document.createElement('div');d.className='journal-card';d.innerHTML=`<b>${htmlText(j.dateLabel)}</b><p>${escapeHtml(j.text)}</p>`;$('journalList').append(d);});
 const actors=(api.getState().actors||[]);$('actorBookSelect').innerHTML=actors.map(a=>`<option value="${htmlText(a.id)}">${htmlText(a.characterName)}${a.actorName?' — '+htmlText(a.actorName):''}</option>`).join('')||'<option value="">لا توجد بطاقات</option>';
}
function escapeHtml(v){return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
$('captureTableauBtn').onclick=()=>{ensure();const name=prompt('اسم الصورة المسرحية:',`الصورة ${scene().tableaux.length+1}`);if(!name)return;api.snap();scene().tableaux.push({id:crypto.randomUUID(),name,createdLabel:now(),...snapshotData()});api.mark('حُفظت صورة مسرحية');render();};
$('saveSceneVersionBtn').onclick=()=>{ensure();const label=prompt('اسم النسخة الزمنية:',`نسخة ${scene().versions.length+1}`);if(!label)return;api.snap();scene().versions.push({id:crypto.randomUUID(),label,createdLabel:now(),...snapshotData()});api.mark('حُفظت نسخة زمنية للمشهد');alert(`تم حفظ ${label}`);};
$('addJournalBtn').onclick=()=>{const text=$('journalText').value.trim();if(!text)return;api.snap();scene().journal.push({id:crypto.randomUUID(),text,dateLabel:now(),date:new Date().toISOString()});$('journalText').value='';api.mark('أضيف قرار إخراجي');render();};
$('toggleRehearsalModeBtn').onclick=()=>{const st=api.getState();st.rehearsal=st.rehearsal||{};st.rehearsal.mode=!st.rehearsal.mode;document.body.classList.toggle('rehearsal-mode',st.rehearsal.mode);$('toggleRehearsalModeBtn').textContent=st.rehearsal.mode?'إنهاء البروفة':'وضع البروفة';setTimeout(api.fit,30);};
document.querySelector('[data-tab="rehearsalTab"]').addEventListener('click',()=>setTimeout(render,0));
window.MS2DRehearsal={render};render();
})();
