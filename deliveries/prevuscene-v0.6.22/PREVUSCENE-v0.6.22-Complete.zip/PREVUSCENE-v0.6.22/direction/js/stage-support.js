'use strict';
// Authored support relationships belong to the scene model, not to the preview.
const StageSupport=(()=>{
 const types=['chair','sofa','platform','bed','stairs'],seats=['chair','sofa','bed'];
 const defaults={chair:.9,sofa:.85,platform:.4,bed:.55,stairs:.8};
 const finite=(value,fallback)=>Number.isFinite(Number(value))&&Number(value)>0?Number(value):fallback;
 const height=o=>clamp(finite(o.height3D,defaults[o.type]||.6),.05,10);
 const floor=o=>clamp(Number(o.elevation3D)||0,0,10);
 function local(o,target){const a=(Number(target.rotation)||0)*Math.PI/180,dx=o.x-target.x,dy=o.y-target.y;return{x:dx*Math.cos(a)+dy*Math.sin(a),y:-dx*Math.sin(a)+dy*Math.cos(a)};}
 function world(binding,target){const a=(Number(target.rotation)||0)*Math.PI/180;return{x:target.x+binding.localX*Math.cos(a)-binding.localY*Math.sin(a),y:target.y+binding.localX*Math.sin(a)+binding.localY*Math.cos(a)};}
 function contains(target,o){const pt=local(o,target);if(target.platformShape==='circle')return (pt.x/(finite(target.w,150)/2+2))**2+(pt.y/(finite(target.h,150)/2+2))**2<=1;return Math.abs(pt.x)<=finite(target.w,60)/2+2&&Math.abs(pt.y)<=finite(target.h,60)/2+2;}
 const stepCount=o=>clamp(Math.round(Number(o.stairSteps)||5),3,5);
 function surface(target,o=target){const h=height(target);if(seats.includes(target.type))return clamp(finite(target.seatHeight3D,target.type==='chair'?h*.5:h*.74),.02,10);if(target.type==='stairs'){const pt=local(o,target),n=stepCount(target),step=clamp(Math.floor((.5+(target.stairDirection==='depth'?-1:1)*pt.y/finite(target.h,100))*n),0,n-1);return h*(step+1)/n;}return h;}
 function allowed(target,pose){return types.includes(target.type)&&(pose==='sitting'||!['chair','sofa'].includes(target.type));}
 function bind(o,target,pose=o.pose){if(!target||!allowed(target,pose))return null;const pt=local(o,target);return{targetId:target.id,mode:pose==='sitting'?'seat':'surface',localX:pt.x,localY:pt.y,actorX:o.x,actorY:o.y,targetX:target.x,targetY:target.y,targetRotation:Number(target.rotation)||0};}
 function target(binding){return binding?scene().objects.find(x=>x.id===binding.targetId&&types.includes(x.type)):null;}
 function base(o,binding=o.support){const t=target(binding);return t?floor(t)+(binding.mode==='surface'?surface(t,o):0):floor(o);}
 function transitionBase(state,o,depth=0){const a=state.fromState&&depth<12?transitionBase(state.fromState,o,depth+1):base(o,state.fromSupport||null),b=base(o,state.toSupport||null);return a+(b-a)*clamp(Number(state.progress)||0,0,1);}
 function elevation(o){if(Number.isFinite(o.terrain?.height))return o.terrain.height;return o.poseTransition&&('fromSupport'in o.poseTransition)?transitionBase(o.poseTransition,o):base(o);}
 function endBinding(p,o){const t=scene().objects.find(x=>x.id===p.endTargetId);const pos=actionChannels(p).position?movementEndPosition(p):{x:o.x,y:o.y};return t&&contains(t,pos)?bind({...o,...pos},t,p.endPose||o.pose):null;}
 function bodyBindings(p,o){
  let to=endBinding(p,o);
  // Keeping a bodily pose also keeps its support while the actor remains on it.
  // An authored new target or a different end pose still takes precedence.
  if(!to&&!p.endTargetId&&p.keepStartPose&&p.startSupport){const t=target(p.startSupport),pos=actionChannels(p).position?movementEndPosition(p):o;if(t&&allowed(t,p.endPose)&&contains(t,pos))to=bind({...o,...pos},t,p.endPose);}
  return{from:clone(p.startSupport||null),to};
 }
 function clearTransitionTarget(state,id){if(!state)return;for(const key of ['fromSupport','toSupport'])if(state[key]?.targetId===id)state[key]=null;if(state.seatTargetId===id)state.seatTargetId=null;clearTransitionTarget(state.fromState,id);}
 function detach(o){o.terrain=null;const id=o.support?.targetId;o.support=null;o.supportSchema=1;if(id)clearTransitionTarget(o.poseTransition,id);}
 function reconcile(sc=scene()){
  for(const o of sc.objects.filter(x=>x.type==='actor')){
   if(!o.support&&o.terrain&&Number.isFinite(o.terrain.actorX)&&Math.hypot(o.x-o.terrain.actorX,o.y-o.terrain.actorY)>.001)o.terrain=null;
   if(o.supportSchema!==1){if(!o.support&&o.pose==='sitting'&&!o.poseTransition){const p=[...sc.paths].reverse().find(p=>p.actorObjectId===o.id&&p.endPose==='sitting'&&sc.objects.some(t=>t.id===p.endTargetId&&allowed(t,'sitting')&&contains(t,o)));const t=sc.objects.find(t=>t.id===p?.endTargetId);if(t)o.support=bind(o,t);}o.supportSchema=1;}
   if(!o.support)continue;const b=o.support,t=sc.objects.find(x=>x.id===b.targetId);
   if(!t||!allowed(t,o.pose)&&!o.poseTransition){detach(o);continue;}
   const actorMoved=Math.hypot(o.x-b.actorX,o.y-b.actorY)>.001,targetMoved=Math.hypot(t.x-b.targetX,t.y-b.targetY)>.001||Number(t.rotation||0)!==b.targetRotation;
   if(targetMoved&&!actorMoved&&!layer(o.layer)?.locked){
    const before={...t,x:b.targetX,y:b.targetY,rotation:b.targetRotation};
    for(const p of sc.paths.filter(p=>p.actorObjectId===o.id&&p.pathShape==='stationary'&&(p.endTargetId===t.id||p.startSupport?.targetId===t.id))){const point={x:p.x1,y:p.y1};if(contains(before,point)){const pt=local(point,before),moved=world({localX:pt.x,localY:pt.y},t);p.x1=p.x2=moved.x;p.y1=p.y2=moved.y;}}
    Object.assign(o,world(b,t));o.facing=normalFacing((Number(o.facing)||0)-(Number(t.rotation)||0)+b.targetRotation);
   }
   if(!contains(t,o)){detach(o);continue;}
   o.support=bind(o,t,b.mode==='seat'?'sitting':o.pose);
  }
 }
 function atPosition(value){if(value.support){const t=target(value.support);value.support=t&&contains(t,value)?bind(value,t,value.support.mode==='seat'?'sitting':value.pose):null;}return value;}
 return{types,seats,stepCount,height,floor,local,world,contains,surface,allowed,bind,target,base,elevation,bodyBindings,detach,reconcile,atPosition};
})();
const supportRenderScene=renderScene;renderScene=function(){StageSupport.reconcile();supportRenderScene();};
