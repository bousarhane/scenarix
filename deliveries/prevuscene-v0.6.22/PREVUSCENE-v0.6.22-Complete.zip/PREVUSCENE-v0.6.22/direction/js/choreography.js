'use strict';
// Spatial path and bodily action are independent parts of a theatrical movement.
const oldMovementGeometry=movementGeometry;
movementGeometry=function(p){
 let points;
 if(p.pathShape==='stationary')return{d:`M${p.x1} ${p.y1}L${p.x1} ${p.y1}`,lx:p.x1,ly:p.y1};
 if(p.pathShape==='polyline'&&p.points?.length>=2)points=p.points;
 if(['circle','arc'].includes(p.pathShape)&&p.center){
  const dx=p.x1-p.center.x,dy=p.y1-p.center.y,r=Math.hypot(dx,dy),a=Math.atan2(dy,dx),sweep=(p.pathShape==='circle'?360:Number(p.sweep)||180)*(p.clockwise===false?-1:1)*Math.PI/180;
  const steps=Math.max(16,Math.ceil(Math.abs(sweep)*40));points=Array.from({length:steps+1},(_,i)=>{const angle=a+sweep*i/steps;return{x:p.center.x+r*Math.cos(angle),y:p.center.y+r*Math.sin(angle)};});
  points[0]={x:p.x1,y:p.y1};points[points.length-1]={x:p.x2,y:p.y2};
 }
 if(points)return{d:points.map((q,i)=>`${i?'L':'M'}${q.x} ${q.y}`).join(''),lx:points[Math.floor(points.length/2)].x,ly:points[Math.floor(points.length/2)].y};
 return oldMovementGeometry(p);
};
const oldShapeLabel=movementShapeLabel;movementShapeLabel=v=>({circle:'دائرة كاملة',arc:'قوس دائري',polyline:'متعدد النقاط',stationary:'فعل في المكان'}[v]||oldShapeLabel(v));
function choreoState(p,t,o,track,resolvePosition){
 const startPose=p.startPose||o.pose||'standing',endPose=p.endPose||startPose;
 let facing=Number.isFinite(p.startFacing)?p.startFacing:Number(o.facing)||0;
 const end=Number.isFinite(p.endFacing)?p.endFacing:facing,mode=p.facingMode||'fixed';
 if(mode==='target'){
  const target=resolvePosition?resolvePosition(p.lookTargetId):scene().objects.find(x=>x.id===p.lookTargetId);
  const dx=target?target.x-o.x:0,dy=target?target.y-o.y:0;
  const aim=Math.hypot(dx,dy)>.00001?Math.atan2(dx,dy)*180/Math.PI:end;
  facing+=(((aim-facing+540)%360)-180)*t;
 }
 if(mode==='turn'){const delta=((end-facing+540)%360)-180;facing+=delta*t;}
 if(track&&(mode==='tangent'||mode==='center')){
  const q=pathProgress(p,t),len=track.getTotalLength(),pt=track.getPointAtLength(q*len);let dx,dy;
  if(mode==='center'&&p.center){dx=p.center.x-pt.x;dy=p.center.y-pt.y;}
  else if(mode==='tangent'&&len>0){const sign=p.direction==='reverse'||(p.direction==='both'&&t>=.5)?-1:1;
   const a=track.getPointAtLength(Math.max(0,q*len-.5)),b=track.getPointAtLength(Math.min(len,q*len+.5));dx=(b.x-a.x)*sign;dy=(b.y-a.y)*sign;
  }
  if(Math.hypot(dx||0,dy||0)>.00001)facing=Math.atan2(dx,dy)*180/Math.PI;
 }
 const blend=bodyActionState(p,t,startPose,endPose,o);
 return{...blend,facing:((facing%360)+360)%360};
}
function applyChoreographyData(p,data){
 for(const key of ['startPose','endPose','startFacing','endFacing','facingMode','poseAt','sweep','clockwise','endTargetId','actionKind','poseInterpolation','poseEndAt','startBodyState','lookTargetId','orientationChoice','startSupport','startArms','armSide','gesturePreset','gestureTargetId','gestureTargetPoint','gestureTrack','gestureFinish','gestureReachAt','gestureReturnAt','gestureBend'])if(data[key]!=null)p[key]=data[key];
 if(data.points)p.points=clone(data.points);
 if(['circle','arc'].includes(p.pathShape)){
  p.center={x:p.x2,y:p.y2};const dx=p.x1-p.center.x,dy=p.y1-p.center.y;
  if(Math.hypot(dx,dy)<1){p.center.x-=50;}
  const angle=(p.pathShape==='circle'?360:Number(p.sweep)||180)*(p.clockwise===false?-1:1)*Math.PI/180;
  const sx=p.x1-p.center.x,sy=p.y1-p.center.y;
  p.x2=p.pathShape==='circle'?p.x1:p.center.x+sx*Math.cos(angle)-sy*Math.sin(angle);
  p.y2=p.pathShape==='circle'?p.y1:p.center.y+sx*Math.sin(angle)+sy*Math.cos(angle);
 }
 const target=scene().objects.find(o=>o.id===p.endTargetId);
 if(target&&!['circle','arc','stationary'].includes(p.pathShape)&&StageSupport.allowed(target,p.endPose)){if(!StageSupport.contains(target,{x:p.x2,y:p.y2})){p.x2=target.x;p.y2=target.y;}if(['polyline','freehand'].includes(p.pathShape)&&p.points?.length)p.points[p.points.length-1]={x:p.x2,y:p.y2};}
}
function nextMovementCode(){const numbers=scene().paths.map(p=>/^M(\d+)$/i.exec(p.code||'')).filter(Boolean).map(m=>Number(m[1]));return `M${String(Math.max(0,...numbers)+1).padStart(2,'0')}`;}
function commitChoreographyPath(end){
 if(!pathStart||!pendingMovement)return;
 snap();const data=pendingMovement,p={...clone(data),id:data.redrawId||crypto.randomUUID(),code:data.redrawCode||nextMovementCode(),x1:pathStart.x,y1:pathStart.y,x2:end.x,y2:end.y};
 delete p.redrawId;delete p.redrawCode;applyChoreographyData(p,data);
 const index=scene().paths.findIndex(x=>x.id===p.id);if(index<0)scene().paths.push(p);else scene().paths[index]=p;
 placeMovementActorAtEnd(p);selectedPathId=p.id;selectedId=null;pendingMovement=null;pathStart=null;tool='select';$('finishPolylineBtn').hidden=true;
 $('selectTool').classList.add('active');$('pathTool').classList.remove('active');mark('حُفظت الحركة وحالة نهايتها');renderScene();
}
function choreoFields(prefix){
 const field=document.createElement('fieldset');field.className='movement-timing-fieldset';field.innerHTML=`<legend>حالة الشخصية أثناء الحركة</legend>
 <div class="two"><label>وضعية البداية<select id="${prefix}StartPose"></select></label><label>وضعية النهاية<select id="${prefix}EndPose"></select></label></div>
 <div class="two"><label>اتجاه البداية °<input id="${prefix}StartFacing" type="number" min="0" max="360" step="any"></label><label>اتجاه النهاية °<input id="${prefix}EndFacing" type="number" min="0" max="360" step="any"></label></div>
 <small>0° نحو الجمهور، 90° يمين الرسم، 180° نحو العمق، 270° يسار الرسم. للوضع الأمامي اختر «واقف» و0°؛ وللجانبي المعاكس اختر «جانبي» و270°.</small>
 <label>اتجاه النظر أثناء الحركة<select id="${prefix}FacingMode"><option value="fixed">يبقى في اتجاه البداية</option><option value="turn">يدور نحو اتجاه النهاية</option><option value="tangent">يتبع المسار</option><option value="center">ينظر إلى مركز الدائرة</option></select></label>
 <label>تغيير الوضعية عند % من زمن الحركة<input id="${prefix}PoseAt" type="number" min="0" max="100" value="100"></label>
 <label>المقعد أو سطح الارتكاز في النهاية<select id="${prefix}EndTarget"><option value="">غير مرتبط</option></select></label>
 <div class="two"><label>زاوية القوس °<input id="${prefix}Sweep" type="number" min="1" max="359" value="180"></label><label>الدوران<select id="${prefix}Clockwise"><option value="yes">مع عقارب الساعة</option><option value="no">عكس عقارب الساعة</option></select></label></div>
 <small>اضغط واسحب على الخشبة ثم أفلت لاعتماد المسار. للرسم الحر اختر «رسم حر». الدائرة والقوس: اسحب نحو المركز. متعدد النقاط يدعم أيضًا إضافة نقاط بالنقر ثم «إنهاء المسار». الفعل في المكان لا يحتاج إلى رسم.</small>`;
 for(const suffix of ['StartPose','EndPose'])for(const op of $('objPose').options)$(prefix+suffix)?.append(op.cloneNode(true)); // populated after insertion below
 return field;
}
for(const prefix of ['newMove','move']){
 const field=choreoFields(prefix);if(prefix==='newMove')$('movementDialog').querySelector('menu').before(field);else $('movementProperties').append(field);
 for(const suffix of ['StartPose','EndPose'])for(const op of $('objPose').options)$(prefix+suffix).append(op.cloneNode(true));
 for(const [value,label] of [['circle','دائرة كاملة'],['arc','قوس دائري'],['polyline','متعدد النقاط'],['stationary','فعل في المكان']]){const op=document.createElement('option');op.value=value;op.textContent=label;$(prefix+'Shape').append(op);}
}
const finish=document.createElement('button');finish.id='finishPolylineBtn';finish.textContent='إنهاء المسار متعدد النقاط';finish.hidden=true;$('movementRegistry').before(finish);
finish.onclick=()=>{const points=pendingMovement?.points;if(points?.length>=2)commitChoreographyPath(points.at(-1));else alert('أضف نقطة واحدة على الأقل بعد نقطة البداية.');};
function fillChoreo(prefix,p,o){
 const pose=o?.pose||'standing',facing=Number(o?.facing)||0;
 for(const [suffix,value] of Object.entries({StartPose:p.startPose||pose,EndPose:p.endPose||pose,StartFacing:p.startFacing??facing,EndFacing:p.endFacing??facing,FacingMode:p.facingMode||'turn',PoseAt:p.poseAt??100,Sweep:p.sweep||180,Clockwise:p.clockwise===false?'no':'yes'}))$(prefix+suffix).value=value;
 const target=$(prefix+'EndTarget');target.innerHTML='<option value="">غير مرتبط</option>';for(const chair of scene().objects.filter(o=>StageSupport.allowed(o,p.endPose||pose))){const op=document.createElement('option');op.value=chair.id;op.textContent=chair.name;target.append(op);}target.value=p.endTargetId||(!p.id?o?.support?.targetId:null)||'';
}
function readChoreo(prefix){return{startPose:$(prefix+'StartPose').value,endPose:$(prefix+'EndPose').value,startFacing:normalFacing(Number($(prefix+'StartFacing').value)),endFacing:normalFacing(Number($(prefix+'EndFacing').value)),facingMode:$(prefix+'FacingMode').value,poseAt:clamp(Number($(prefix+'PoseAt').value),0,100),sweep:clamp(Number($(prefix+'Sweep').value)||180,1,359),clockwise:$(prefix+'Clockwise').value==='yes',endTargetId:$(prefix+'EndTarget').value||null};}
const oldOpen=enhancedOpenMovementDialog;enhancedOpenMovementDialog=function(){oldOpen();fillChoreo('newMove',{},selected());};
$('newMoveActor').addEventListener('change',()=>fillChoreo('newMove',{},scene().objects.find(o=>o.id===$('newMoveActor').value)));
const oldBegin=beginEnhancedMovementDraw;beginEnhancedMovementDraw=function(){if(oldBegin()===false||!pendingMovement)return false;Object.assign(pendingMovement,readChoreo('newMove'));
 if(pendingMovement.facingMode==='center'&&!['circle','arc'].includes(pendingMovement.pathShape)){pendingMovement.facingMode='fixed';}
 if(pendingMovement.pathShape==='stationary'){if(!pathStart){alert('اختر شخصية للفعل في المكان.');tool='select';pendingMovement=null;return false;}commitChoreographyPath(pathStart);}
 else if(pendingMovement.pathShape==='polyline'){pendingMovement.points=pathStart?[clone(pathStart)]:[];$('finishPolylineBtn').hidden=false;$('statusText').textContent='انقر نقاط المسار ثم أنهِه من تبويب الحركة';}
 else if(['circle','arc'].includes(pendingMovement.pathShape))$('statusText').textContent='انقر مركز الدوران؛ موقع الشخصية هو بداية المسار';
 return true;
};
const oldProps=renderMovementProperties;renderMovementProperties=function(){oldProps();const p=currentMovement();if(p)fillChoreo('move',p,scene().objects.find(o=>o.id===p.actorObjectId));};
for(const suffix of ['StartPose','EndPose','StartFacing','EndFacing','FacingMode','PoseAt','EndTarget','Sweep','Clockwise'])$('move'+suffix).addEventListener('change',()=>{
 const p=currentMovement();if(!p)return;
 // Stopping redraws the properties. Capture the user's edit before that redraw.
 const data=readChoreo('move');stopSimulation();snap();Object.assign(p,data);
 if(p.center){const center=clone(p.center); // recompute from the stored center, not the previous endpoint
 const angle=(p.pathShape==='circle'?360:p.sweep)*(p.clockwise?1:-1)*Math.PI/180,sx=p.x1-center.x,sy=p.y1-center.y;p.x2=p.pathShape==='circle'?p.x1:center.x+sx*Math.cos(angle)-sy*Math.sin(angle);p.y2=p.pathShape==='circle'?p.y1:center.y+sx*Math.sin(angle)+sy*Math.cos(angle);}
 placeMovementActorAtEnd(p);mark('عُدّلت حالة الحركة');renderScene();
});
$('createMovementBtn').onclick=enhancedOpenMovementDialog;$('pathTool').onclick=enhancedOpenMovementDialog;$('startMovementDrawBtn').onclick=beginEnhancedMovementDraw;
const oldRedraw=redrawEnhancedMovement;redrawEnhancedMovement=function(){const p=currentMovement();oldRedraw();if(p&&pendingMovement){Object.assign(pendingMovement,readChoreo('move'));if(p.pathShape==='polyline'){pendingMovement.points=[clone(pathStart)];$('finishPolylineBtn').hidden=false;}}};$('redrawMovementBtn').onclick=redrawEnhancedMovement;
svg.addEventListener('pointerdown',ev=>{
 if(tool!=='path'||!pendingMovement)return;
 if(layer('movement')?.locked)return;
 const point=stagePoint(ev);if(point.x<0||point.y<0||point.x>m2p(state.stage.width)||point.y>m2p(state.stage.depth))return;
 if(pendingMovement.pathShape==='polyline'){
  ev.stopImmediatePropagation();ev.preventDefault();if(!pathStart)pathStart={x:point.x,y:point.y};pendingMovement.points.push({x:point.x,y:point.y});$('statusText').textContent=`${pendingMovement.points.length} نقاط — انقر «إنهاء المسار»`;return;
 }
 if(ev.target.closest('.stage-object')&&pathStart){ev.stopImmediatePropagation();ev.preventDefault();commitChoreographyPath(point);}
},true);
window.addEventListener('keydown',ev=>{if(ev.key==='Escape')$('finishPolylineBtn').hidden=true;});

const choreoSelect=$('selectTool').onclick;$('selectTool').onclick=()=>{choreoSelect();$('finishPolylineBtn').hidden=true;};
