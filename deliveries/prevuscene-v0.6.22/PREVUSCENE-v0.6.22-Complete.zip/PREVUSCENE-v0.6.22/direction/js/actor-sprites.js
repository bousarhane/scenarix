'use strict';
// Approved editable vector artwork, cached as SVG templates then cloned for each actor.
const ACTOR_SPRITES=window.ActorVectorSources;
function actorSprite(...args){return ActorArtwork.sprite(...args);}
function actorIllustration(parent,o){return ActorArtwork.draw(parent,o,svgEl);}
function renderActorPosePicker(){
 const o=selected(),box=$('actorPosePicker'),directions=$('actorFacingPicker');box.innerHTML='';directions.innerHTML='';if(!o||o.type!=='actor')return;
 for(const [facing,label] of [[0,'نحو الجمهور'],[90,'يمين الرسم'],[180,'نحو العمق'],[270,'يسار الرسم']]){
  const button=document.createElement('button');button.type='button';button.textContent=label;button.dataset.facing=facing;
  const active=Number(o.facing||0)===facing;button.classList.toggle('active',active);button.setAttribute('aria-pressed',String(active));
  button.onclick=()=>{stopSimulation();snap();o.facing=facing;o.rotation=0;mark('عُدّل اتجاه الشخصية');renderScene();};directions.append(button);
 }
 $('objActorVisual').value=o.actorVisual||'illustrated';
 $('objGender').value=o.gender||'neutral';
 if(!ACTOR_SPRITES[o.gender])return;
 const poses=[['front','standing','أمامي',0],['back','standing','خلفي',180],['side','side','جانبي',90],['sitting','sitting','جلوس',null],['lying','lyingBack','استلقاء',null],['crouching','crouching','قرفصاء',null]];
 for(const [view,pose,label,facing] of poses){
  const button=document.createElement('button');button.type='button';button.title=label;button.setAttribute('aria-label',label);button.dataset.pose=pose;button.dataset.view=view;
  const active=o.pose===pose&&(facing==null||pose==='side'||Number(o.facing||0)===facing);button.classList.toggle('active',active);button.setAttribute('aria-pressed',String(active));
  button.append(actorSprite(o.gender,view,58,58));const caption=document.createElement('span');caption.textContent=label;button.append(caption);
  button.onclick=()=>{stopSimulation();snap();const keepSideFacing=pose==='side'&&o.pose==='side';o.pose=pose;o.poseTransition=null;if(facing!=null&&!keepSideFacing)o.facing=facing;o.rotation=0;mark('عُدّلت وضعية الشخصية');renderScene();};box.append(button);
 }
}
const originalActorProperties=renderProperties;renderProperties=function(){originalActorProperties();renderActorPosePicker();};
$('objActorVisual').addEventListener('change',()=>{const o=selected();if(!o||o.type!=='actor')return;snap();o.actorVisual=$('objActorVisual').value;mark('عُدّل تمثيل الشخصية');renderScene();});
// Preserve the existing library buttons and their drag/drop handlers.
for(const [type,gender] of [['actorMale','male'],['actorFemale','female']]){
 const img=document.querySelector(`[data-type="${type}"] img`);
 img.src=`assets/actors/${gender}/standing-front.svg`;
}
// Self-contained PNG export: embed each source sheet once in a private SVG copy.
function actorExportSVG(){
 const copy=svg.cloneNode(true);
 // Inline vector paths travel with the stage; no external artwork is needed for export.
 const style=svgEl('style');style.textContent=Array.from(document.styleSheets).map(sheet=>{try{return Array.from(sheet.cssRules).map(rule=>rule.cssText).join('\n');}catch{return '';}}).join('\n');copy.insertBefore(style,copy.firstChild);
 return new XMLSerializer().serializeToString(copy);
}
$('exportBtn').onclick=async()=>{
 let url;
 try{
  const xml=actorExportSVG();url=URL.createObjectURL(new Blob([xml],{type:'image/svg+xml'}));
  const image=new Image();await new Promise((resolve,reject)=>{image.onload=resolve;image.onerror=()=>reject(new Error('تعذر تجهيز صورة الخشبة'));image.src=url;});
  const canvas=document.createElement('canvas');canvas.width=svg.viewBox.baseVal.width*2;canvas.height=svg.viewBox.baseVal.height*2;
  const context=canvas.getContext('2d');context.fillStyle='#f7f3e8';context.fillRect(0,0,canvas.width,canvas.height);context.drawImage(image,0,0,canvas.width,canvas.height);
  const dataUrl=canvas.toDataURL('image/png');
  if(window.stageAPI)await window.stageAPI.exportPNG({dataUrl,defaultName:`${scene().title}.png`});
  else{const a=document.createElement('a');a.href=dataUrl;a.download=`${scene().title}.png`;a.click();}
 }catch(err){alert('تعذر تصدير الخشبة: '+err.message);}finally{if(url)URL.revokeObjectURL(url);}
};
