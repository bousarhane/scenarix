'use strict';
// PREVUSCENE v0.5.2 — interactive scene-wide movement timeline.

function movementTimingLabel(p){
  if((p.timingMode||'absolute')==='sequential') return 'بعد حركة';
  if(p.timingMode==='simultaneous') return 'متزامنة';
  return 'مستقلة';
}
function movementById(id){return (scene().paths||[]).find(p=>p.id===id)||null}
function movementDisplayName(p){return `${htmlText(p.code||'M')} — ${htmlText(movementActorLabel(p))}`}

function compileMovementSchedule(paths=scene().paths||[]){
  const map=new Map(paths.map(p=>[p.id,p])),memo=new Map(),visiting=new Set();
  function resolve(p){
    if(memo.has(p.id))return memo.get(p.id);
    if(visiting.has(p.id)){
      const cyc={path:p,start:0,end:Math.max(.1,Number(p.duration)||5),invalid:'cycle'};memo.set(p.id,cyc);return cyc;
    }
    visiting.add(p.id);
    const duration=Math.max(.1,Number(p.duration)||5),mode=p.timingMode||'absolute';
    let start=0,invalid='';
    if(mode==='absolute') start=Math.max(0,Number(p.absoluteStart)||0);
    else {
      const anchor=map.get(p.anchorMovementId);
      if(!anchor||anchor.id===p.id){invalid='missing-anchor';start=Math.max(0,Number(p.offset)||0)}
      else{
        const a=resolve(anchor);if(a.invalid)invalid=a.invalid;
        start=(mode==='simultaneous'?a.start:a.end)+(Number(p.offset)||0);
        start=Math.max(0,start);
      }
    }
    visiting.delete(p.id);
    const item={path:p,start:+start.toFixed(3),end:+(start+duration).toFixed(3),invalid};memo.set(p.id,item);return item;
  }
  return paths.map(resolve).sort((a,b)=>a.start-b.start||a.end-b.end);
}

function populateMovementAnchorSelect(id,currentPathId=null,value=null){
  const el=$(id);if(!el)return;
  const paths=(scene().paths||[]).filter(p=>p.id!==currentPathId);
  el.innerHTML='<option value="">— اختر حركة —</option>';
  for(const p of paths){const op=document.createElement('option');op.value=p.id;op.textContent=movementDisplayName(p);el.append(op)}
  if(value&&[...el.options].some(o=>o.value===value))el.value=value;
}
function updateTimingVisibility(prefix){
  const mode=$(prefix+'TimingMode')?.value||'absolute';
  const aw=$(prefix+'AnchorWrap'),abs=$(prefix+'AbsoluteWrap');
  if(aw)aw.hidden=mode==='absolute';if(abs)abs.hidden=mode!=='absolute';
}
function populatePlaybackActors(){
  const el=$('movementPlaybackActor');if(!el)return;const current=el.value;
  el.innerHTML='<option value="">اختر ممثلًا</option>';
  const ids=[...new Set((scene().paths||[]).map(p=>p.actorObjectId).filter(Boolean))];
  for(const id of ids){const o=scene().objects.find(x=>x.id===id);if(!o)continue;const op=document.createElement('option');op.value=id;op.textContent=o.characterName||o.name||'شخصية';el.append(op)}
  if([...el.options].some(o=>o.value===current))el.value=current;
}

function timingAnchorWouldCycle(pathId,anchorId){
  if(!anchorId)return false;
  const map=new Map((scene().paths||[]).map(p=>[p.id,p]));
  let cur=anchorId,guard=0;
  while(cur&&guard++<200){
    if(cur===pathId)return true;
    const p=map.get(cur);if(!p||p.timingMode==='absolute')return false;
    cur=p.anchorMovementId||null;
  }
  return false;
}
function timelineDisplayDuration(schedule){
  const actual=Math.max(0,...schedule.map(x=>x.end));
  return Math.max(10,Math.ceil((actual*1.18+2)*2)/2);
}
function inferTimelineTiming(path,desiredStart,schedule,snapSeconds){
  const others=schedule.filter(x=>x.path.id!==path.id&&!timingAnchorWouldCycle(path.id,x.path.id));
  if(!others.length){path.timingMode='absolute';path.anchorMovementId=null;path.offset=0;path.absoluteStart=+Math.max(0,desiredStart).toFixed(2);return 'توقيت مستقل'}
  const nearestStart=[...others].sort((a,b)=>Math.abs(a.start-desiredStart)-Math.abs(b.start-desiredStart))[0];
  const nearestEnd=[...others].sort((a,b)=>Math.abs(a.end-desiredStart)-Math.abs(b.end-desiredStart))[0];
  if(nearestStart&&Math.abs(nearestStart.start-desiredStart)<=snapSeconds){
    path.timingMode='simultaneous';path.anchorMovementId=nearestStart.path.id;path.offset=0;path.absoluteStart=0;
    return `متزامنة مع ${nearestStart.path.code||'حركة'}`;
  }
  if(nearestEnd&&Math.abs(nearestEnd.end-desiredStart)<=snapSeconds){
    path.timingMode='sequential';path.anchorMovementId=nearestEnd.path.id;path.offset=0;path.absoluteStart=0;
    return `بعد ${nearestEnd.path.code||'حركة'}`;
  }
  const previousEnds=others.filter(x=>x.end<=desiredStart).sort((a,b)=>b.end-a.end);
  if(previousEnds.length){
    const a=previousEnds[0],gap=Math.max(0,desiredStart-a.end);
    path.timingMode='sequential';path.anchorMovementId=a.path.id;path.offset=+gap.toFixed(2);path.absoluteStart=0;
    return gap<.01?`بعد ${a.path.code||'حركة'}`:`بعد ${a.path.code||'حركة'} + ${gap.toFixed(1)}ث`;
  }
  const previousStarts=others.filter(x=>x.start<=desiredStart).sort((a,b)=>b.start-a.start);
  if(previousStarts.length){
    const a=previousStarts[0],gap=Math.max(0,desiredStart-a.start);
    path.timingMode='simultaneous';path.anchorMovementId=a.path.id;path.offset=+gap.toFixed(2);path.absoluteStart=0;
    return gap<.01?`متزامنة مع ${a.path.code||'حركة'}`:`مع بداية ${a.path.code||'حركة'} + ${gap.toFixed(1)}ث`;
  }
  path.timingMode='absolute';path.anchorMovementId=null;path.offset=0;path.absoluteStart=+Math.max(0,desiredStart).toFixed(2);
  return `توقيت مستقل ${path.absoluteStart.toFixed(1)}ث`;
}
function attachTimelineDrag(bar,track,item,schedule,displayTotal){
  const path=item.path,duration=Math.max(.1,item.end-item.start);
  bar.addEventListener('pointerdown',ev=>{
    if(ev.button!==0)return;
    ev.preventDefault();ev.stopPropagation();selectedPathId=path.id;selectedId=null;snap();
    const rect=track.getBoundingClientRect(),startX=ev.clientX,initialStart=item.start;
    const maxStart=Math.max(0,displayTotal-duration);let moved=false,lastStart=initialStart;
    bar.classList.add('dragging');bar.setPointerCapture?.(ev.pointerId);
    const onMove=e=>{
      const dx=e.clientX-startX;if(Math.abs(dx)>3)moved=true;
      lastStart=clamp(initialStart+(dx/Math.max(1,rect.width))*displayTotal,0,maxStart);
      bar.style.left=(lastStart/displayTotal*100)+'%';
      const relation=inferTimelineTimingPreview(path,lastStart,schedule,Math.max(.12,displayTotal/Math.max(1,rect.width)*10));
      $('statusText').textContent=`${path.code||'M'} — ${lastStart.toFixed(1)}ث · ${relation}`;
    };
    const finish=e=>{
      bar.removeEventListener('pointermove',onMove);bar.removeEventListener('pointerup',finish);bar.removeEventListener('pointercancel',cancel);
      bar.classList.remove('dragging');try{bar.releasePointerCapture?.(ev.pointerId)}catch(_e){}
      if(!moved){renderScene();return}
      const relation=inferTimelineTiming(path,lastStart,compileMovementSchedule(),Math.max(.12,displayTotal/Math.max(1,rect.width)*10));
      mark(`حُرّكت ${path.code||'الحركة'} على Timeline — ${relation}`);renderScene();
    };
    const cancel=()=>{bar.removeEventListener('pointermove',onMove);bar.removeEventListener('pointerup',finish);bar.removeEventListener('pointercancel',cancel);bar.classList.remove('dragging');renderScene()};
    bar.addEventListener('pointermove',onMove);bar.addEventListener('pointerup',finish);bar.addEventListener('pointercancel',cancel);
  });
}
function inferTimelineTimingPreview(path,desiredStart,schedule,snapSeconds){
  const copy={...path};return inferTimelineTiming(copy,desiredStart,schedule,snapSeconds);
}
function renderMovementTimeline(){
  const box=$('movementTimeline'),dur=$('movementTimelineDuration');if(!box)return;
  box.innerHTML='';const schedule=compileMovementSchedule();const actualTotal=Math.max(0,...schedule.map(x=>x.end)),displayTotal=timelineDisplayDuration(schedule);if(dur)dur.textContent=`${actualTotal.toFixed(1)} ث`;
  if(!schedule.length){box.innerHTML='<div class="movement-timeline-empty">لا توجد حركات بعد.</div>';return}
  const scale=document.createElement('div');scale.className='movement-timeline-scale';
  const scaleLabel=document.createElement('div');scaleLabel.className='movement-timeline-scale-label';scaleLabel.textContent='اسحب شريط الحركة أفقيًا لضبط التزامن أو التتابع';
  const ruler=document.createElement('div');ruler.className='movement-timeline-ruler';
  const tickStep=displayTotal<=15?1:displayTotal<=40?5:10;
  for(let t=0;t<=displayTotal+.001;t+=tickStep){const tick=document.createElement('span');tick.style.left=(t/displayTotal*100)+'%';tick.textContent=`${t}`;ruler.append(tick)}
  scale.append(scaleLabel,ruler);box.append(scale);
  const groups=new Map();
  for(const item of schedule){const key=(item.path.actorObjectId||'_none')+'|'+actionKind(item.path);if(!groups.has(key))groups.set(key,[]);groups.get(key).push(item)}
  for(const [groupKey,items] of groups){
    const actorId=items[0].path.actorObjectId;
    const actor=scene().objects.find(o=>o.id===actorId),row=document.createElement('div');row.className='movement-timeline-row';
    const label=document.createElement('div');label.className='movement-timeline-label';label.textContent=actor?(actor.characterName||actor.name):'غير مرتبط';const kindLabel=document.createElement('small');kindLabel.textContent=actionKindLabel(items[0].path);label.append(kindLabel);label.title=label.textContent;
    const track=document.createElement('div');track.className='movement-timeline-track';
    track.style.setProperty('--timeline-step',`${tickStep/displayTotal*100}%`);
    for(const item of items){
      const p=item.path,b=document.createElement('div');b.className='movement-timeline-bar'+(p.id===selectedPathId?' selected':'');
      b.style.left=(item.start/displayTotal*100)+'%';b.style.width=((item.end-item.start)/displayTotal*100)+'%';b.style.background=p.color||'#c98212';
      b.title=`${movementDisplayName(p)} | ${item.start.toFixed(1)} → ${item.end.toFixed(1)} ث — اسحب لتغيير البداية`;
      b.innerHTML=`<span>${htmlText(p.code||'M')}</span><small>${item.start.toFixed(1)}</small>`;
      attachTimelineDrag(b,track,item,schedule,displayTotal);track.append(b);
    }
    row.append(label,track);box.append(row)
  }
}

// Replace the compact registry with timing-aware cards.
renderMovements=function(){
  const box=$('movementRegistry');if(!box)return;box.innerHTML='';const paths=scene().paths||[],schedule=compileMovementSchedule(),times=new Map(schedule.map(x=>[x.path.id,x]));
  populatePlaybackActors();
  if(!paths.length)box.innerHTML='<div class="actor-registry-empty">لا توجد حركات في هذا المشهد.</div>';
  for(const p of paths){const t=times.get(p.id),d=document.createElement('div');d.className='movement-card'+(p.id===selectedPathId?' active':'');d.innerHTML=`<div class="movement-card-head"><b>${htmlText(p.code)} — ${htmlText(movementActorLabel(p))}</b><span class="movement-card-time">${t?t.start.toFixed(1):'0.0'}–${t?t.end.toFixed(1):(Number(p.duration)||0).toFixed(1)} ث</span></div><small>${htmlText(actionKindLabel(p))}${actionChannels(p).position?' · '+htmlText(movementTypeLabel(p.type))+' · '+htmlText(movementShapeLabel(p.pathShape)):''} <span class="movement-timing-badge">${htmlText(movementTimingLabel(p))}</span>${p.trigger?' · '+htmlText(p.trigger):''}</small>${t?.invalid?'<div class="movement-sim-status">⚠ راجع مرجع التوقيت</div>':''}`;d.onclick=()=>{selectedPathId=p.id;selectedId=null;renderScene()};box.append(d)}
  renderMovementTimeline();
};

const _renderMovementProperties=renderMovementProperties;
renderMovementProperties=function(){
  _renderMovementProperties();const p=currentMovement();if(!p)return;
  $('moveTimingMode').value=p.timingMode||'absolute';populateMovementAnchorSelect('moveAnchorMovement',p.id,p.anchorMovementId);$('moveOffset').value=Number(p.offset)||0;$('moveAbsoluteStart').value=Number(p.absoluteStart)||0;updateTimingVisibility('move');
  const t=compileMovementSchedule().find(x=>x.path.id===p.id);$('moveCompiledTime').textContent=t?`الزمن المحسوب: ${t.start.toFixed(1)} → ${t.end.toFixed(1)} ثانية${t.invalid?' — مرجع زمني يحتاج مراجعة':''}`:'';
};

function enhancedOpenMovementDialog(){
  fillMovementActorSelect('newMoveActor',true);const selectedActor=selected()&&selected().type==='actor'?selected().id:'';$('newMoveActor').value=selectedActor;
  const paths=scene().paths||[],last=paths[paths.length-1]||null;populateMovementAnchorSelect('newMoveAnchorMovement',null,last?.id||null);
  $('newMoveTimingMode').value=last?'sequential':'absolute';$('newMoveOffset').value=0;$('newMoveAbsoluteStart').value=last?compileMovementSchedule().at(-1)?.end||0:0;updateTimingVisibility('newMove');$('movementDialog').showModal();
}

function beginEnhancedMovementDraw(){
  stopSimulation();
  const mode=$('newMoveTimingMode').value,anchor=$('newMoveAnchorMovement').value||null;
  if(mode!=='absolute'&&!anchor){alert('اختر الحركة المرجعية للتتابع أو التزامن.');return false;}
  pendingMovement={actorObjectId:$('newMoveActor').value||null,type:$('newMoveType').value,duration:+$('newMoveDuration').value||5,speed:$('newMoveSpeed').value,trigger:$('newMoveTrigger').value,notes:$('newMoveNotes').value,color:$('newMoveColor').value,pathShape:$('newMoveShape').value,direction:$('newMoveDirection').value,curve:+$('newMoveCurve').value,timingMode:mode,anchorMovementId:anchor,offset:+$('newMoveOffset').value||0,absoluteStart:+$('newMoveAbsoluteStart').value||0};
  tool='path';const startActor=scene().objects.find(o=>o.id===pendingMovement.actorObjectId);pathStart=startActor?{x:startActor.x,y:startActor.y}:null;$('pathTool').classList.add('active');$('selectTool').classList.remove('active');$('statusText').textContent=pendingMovement.actorObjectId?'انقر نقطة نهاية الحركة؛ البداية هي موقع الشخصية':'انقر نقطة البداية ثم النهاية';
  return true;
}

function redrawEnhancedMovement(){
  stopSimulation();
  const p=currentMovement();if(!p)return;pendingMovement={redrawId:p.id,redrawCode:p.code,actorObjectId:p.actorObjectId,type:p.type,duration:p.duration,speed:p.speed,trigger:p.trigger,notes:p.notes,color:p.color,pathShape:p.pathShape,direction:p.direction,curve:p.curve,timingMode:p.timingMode,anchorMovementId:p.anchorMovementId,offset:p.offset,absoluteStart:p.absoluteStart};selectedPathId=null;tool='path';const redrawActor=scene().objects.find(o=>o.id===pendingMovement.actorObjectId);pathStart={x:p.x1,y:p.y1};$('statusText').textContent=redrawActor?'حدد نقطة نهاية الحركة':'أعد تحديد بداية الحركة ونهايتها';renderScene();
}

function pathProgress(p,t){if(p.direction==='reverse')return 1-t;if(p.direction==='both')return t<.5?t*2:(1-t)*2;return t}
// Playback owns temporary coordinates; completion commits them to the scene model.
// Keep the stored path origin intact so replay does not rewrite choreography.
let movementPlayback=null;
function movementEndPosition(p){
  return pathProgress(p,1)===0?{x:p.x1,y:p.y1}:{x:p.x2,y:p.y2};
}
function removeSceneMovements(ids,sc=scene()){
  const removed=new Set(ids),schedule=compileMovementSchedule(sc.paths||[]);
  // Preserve surviving authored times when a timing anchor disappears.
  for(const item of schedule){const p=item.path;if(!removed.has(p.id)&&removed.has(p.anchorMovementId)){p.timingMode='absolute';p.absoluteStart=item.start;p.offset=0;p.anchorMovementId=null;}}
  for(const o of sc.objects.filter(o=>o.type==='actor'))for(const e of o.stateChanges||[]){
    const id=e.atMovementId||e.afterMovementId;if(!removed.has(id)||removed.has(e.forActionId))continue;
    const anchor=schedule.find(a=>a.path.id===id);if(anchor)e.time=e.atMovementId?anchor.start:anchor.end;
    delete e.atMovementId;delete e.afterMovementId;
  }
  sc.paths=sc.paths.filter(p=>!removed.has(p.id));
}
function deleteMovement(){
  const p=currentMovement();if(!p||layer('movement')?.locked)return;
  stopSimulation();snap();removeSceneMovements([p.id]);selectedPathId=null;
  mark('حُذف الفعل وحُفظ توقيت الأفعال التالية');renderScene();
}
$('deleteMovementBtn').onclick=deleteMovement;
function placeMovementActorAtEnd(p){
  const actor=scene().objects.find(o=>o.id===p.actorObjectId);
  if(actor){const track=svgEl('path',{d:movementPathD(p)});const channels=actionChannels(p),body=choreoState(p,1,{...actor,...(channels.position?movementEndPosition(p):{})},track);if(channels.position)Object.assign(actor,movementEndPosition(p));if(channels.pose)Object.assign(actor,{pose:body.pose,poseTransition:body.poseTransition,support:body.support,supportSchema:1});if(channels.facing)actor.facing=body.facing;if(channels.leftArm||channels.rightArm){actor.arms=clone(actor.arms||{});for(const side of ['left','right'])if(channels[side+'Arm'])actor.arms[side]=ArmGestures.sample(p,1,actor,side);}}
}
function animateMovementSchedule(entries,{normalize=false,isolated=false,label='قراءة الحركة',minDuration=0,allowEmpty=false,preserveSequence=false,onComplete=null,onProgress=null}={}){
  if(!entries.length&&!allowEmpty&&!window.ActorContinuity?.events(scene(),compileMovementSchedule()).length)return alert('لا توجد حركات قابلة للتشغيل.');
  stopSimulation(true,{preserveSequence});
  let items=entries.map(x=>({...x,path:clone(x.path)}));
  const context=window.ActorContinuity?.playback(items,normalize,isolated);if(context)items=context.items;
  if(normalize){const min=Math.min(...items.map(x=>x.start));items=items.map(x=>({...x,start:x.start-min,end:x.end-min}))}
  const originScene=scene(),total=Math.max(.1,Number(minDuration)||0,!isolated&&!normalize?(window.LightTimeline?.duration(state.lightingByScene?.[originScene.id])||0):0,...items.map(x=>x.end)),byActor=new Map();
  for(const i of items){
    if(!originScene.objects.some(o=>o.id===i.path.actorObjectId))continue;
    i.track=svgEl('path',{d:movementPathD(i.path)});
    if(!byActor.has(i.path.actorObjectId))byActor.set(i.path.actorObjectId,[]);
    byActor.get(i.path.actorObjectId).push(i);
  }
  if(window.StageConstraints&&!StageConstraints.allow(items,originScene,context?.sources)){if(preserveSequence)window.ScenePlayback?.cancel();return false;}
  if(!byActor.size&&!allowEmpty)return alert('الحركات المختارة غير مرتبطة بممثلين موجودين.');
  const session={scene:originScene,positions:new Map(),originals:new Map(),drawings:new Map()};
  for(const [id] of byActor){const o=originScene.objects.find(o=>o.id===id);session.originals.set(id,{object:o,source:context?.sources.get(id)||o,x:o.x,y:o.y});}
  movementPlayback=session;
  const resolvePosition=(id,sec)=>{const o=originScene.objects.find(x=>x.id===id);return o?(byActor.has(id)?sampleActorPosition(byActor.get(id),sec,session.originals.get(id)?.source||o):{x:o.x,y:o.y}):null;};
  const startClock=performance.now();
  const tick=now=>{
    if(movementPlayback!==session)return;
    // Undo, loading a project or replacing a scene invalidates this playback.
    if(!state.scenes.includes(originScene)||scene()!==originScene){stopSimulation(false);return}
    const sec=Math.min(total,(now-startClock)/1000);
    for(const [id,list] of byActor){
      const original=session.originals.get(id),o=original.object;
      if(!originScene.objects.includes(o)||o.x!==original.x||o.y!==original.y)continue;
      const sampled=sampleActorActions(list,sec,original.source||o,resolvePosition),pt={x:sampled.x,y:sampled.y},bodily={pose:sampled.pose,facing:sampled.facing,poseTransition:sampled.poseTransition,support:sampled.support,terrain:sampled.terrain,arms:sampled.arms,gait:sampled.gait};
      session.positions.set(id,sampled);
      const g=layerGroup('actors')?.querySelector(`[data-id="${id}"]`);
      if(g){
        const drawing={...o,...pt,...bodily,armTargetResolver:id=>resolvePosition(id,sec)},targets=[];
        const armTargets=arm=>{if(!arm)return;if(arm.preset==='point')targets.push(ArmGestures.point(arm,drawing.armTargetResolver));armTargets(arm.from);armTargets(arm.to);};Object.values(bodily.arms||{}).forEach(armTargets);
        const signature=JSON.stringify([bodily.pose,bodily.facing,bodily.poseTransition,bodily.support,bodily.arms,targets,targets.length?pt:null]),previous=session.drawings.get(id);
        let drawingElement=g;
        // A stable bodily drawing survives spatial frames. Move its group and
        // animate small gait overlays rather than rebuilding the approved SVG artwork.
        if(previous?.element===g&&previous.signature===signature)window.ActorGait?.update(g,drawing);
        else{drawingElement=shape(drawing);g.replaceWith(drawingElement);session.drawings.set(id,{element:drawingElement,signature});}
        drawingElement.classList.add('simulation-running');drawingElement.setAttribute('transform',`translate(${pt.x} ${pt.y}) rotate(${o.rotation||0})`);
      }
    }
    window.Stage3D?.movementFrame(originScene,session.positions,sec);
    $('statusText').textContent=`${label}: ${sec.toFixed(1)} / ${total.toFixed(1)} ث`;
    if(onProgress)onProgress(sec,total);
    if(sec<total)simulationFrame=requestAnimationFrame(tick);
    else{stopSimulation(true,{preserveSequence});$('statusText').textContent='انتهت الحركة — ثُبّتت الشخصيات في مواقعها النهائية';if(onComplete)onComplete();}
  };
  // Paint the opening state immediately, including on a busy or slow device.
  tick(startClock);
}

simulateMovement=function(){const p=currentMovement();if(!p)return alert('اختر حركة أولا.');animateMovementSchedule([{path:p,start:0,end:Math.max(.1,Number(p.duration)||5)}],{normalize:false,isolated:true,label:'الحركة المحددة'})};
function simulateAllMovements(){animateMovementSchedule(compileMovementSchedule(),{normalize:false,label:'كل الحركات',allowEmpty:!!state.lightingByScene?.[scene().id]})}
function simulateActorMovements(){const actorId=$('movementPlaybackActor').value;if(!actorId)return alert('اختر ممثلًا أولا.');const schedule=compileMovementSchedule(),selected=schedule.filter(x=>x.path.actorObjectId===actorId);const entries=selected.length?selected:(window.ActorContinuity?.events(scene(),schedule)||[]).filter(x=>x.path.actorObjectId===actorId);if(!entries.length)return alert('لا توجد أفعال أو نقاط حالة لهذا الممثل.');animateMovementSchedule(entries,{normalize:true,label:'حركات الممثل'})}
stopSimulation=function(render=true,{preserveSequence=false}={}){
  if(!preserveSequence)window.ScenePlayback?.cancel();
  if(simulationFrame){cancelAnimationFrame(simulationFrame);simulationFrame=null}
  const session=movementPlayback;movementPlayback=null;
  if(render&&session&&state.scenes.includes(session.scene)){
    const changes=[];
    for(const [id,pt] of session.positions){const initial=session.originals.get(id),o=initial.object;
      if(session.scene.objects.includes(o)&&o.x===initial.x&&o.y===initial.y&&(o.x!==pt.x||o.y!==pt.y||o.pose!==pt.pose||o.facing!==pt.facing||JSON.stringify(o.poseTransition||null)!==JSON.stringify(pt.poseTransition||null)||JSON.stringify(o.support||null)!==JSON.stringify(pt.support||null)||JSON.stringify(o.arms||{})!==JSON.stringify(pt.arms||{})||JSON.stringify(o.terrain||null)!==JSON.stringify(pt.terrain||null)))changes.push({o,pt});
    }
    if(changes.length){snap();for(const {o,pt} of changes){Object.assign(o,pt);delete o.gait;}mark('ثُبّتت مواقع الشخصيات بعد الحركة');}
  }
  window.ActorContinuity?.observe(session?.scene||scene());
  window.Stage3D?.endMovement();
  if(render){renderScene();$('statusText').textContent='توقفت الحركة — احتُفظ بالمواقع التي بلغتها الشخصيات';}
};

// Override/create UI hooks after legacy ui.js has initialized them.
$('createMovementBtn').onclick=enhancedOpenMovementDialog;
$('startMovementDrawBtn').onclick=beginEnhancedMovementDraw;
$('redrawMovementBtn').onclick=redrawEnhancedMovement;
$('simulateMovementBtn').onclick=simulateMovement;
$('simulateAllMovementsBtn').onclick=simulateAllMovements;
$('simulateActorMovementsBtn').onclick=simulateActorMovements;
$('stopSimulationBtn').onclick=()=>stopSimulation();
$('newMoveTimingMode').addEventListener('change',()=>updateTimingVisibility('newMove'));
$('moveTimingMode').addEventListener('change',()=>{const p=currentMovement();if(!p)return;snap();p.timingMode=$('moveTimingMode').value;if(p.timingMode!=='absolute'&&!p.anchorMovementId){const candidates=(scene().paths||[]).filter(x=>x.id!==p.id);p.anchorMovementId=candidates.at(-1)?.id||null}mark('عُدلت علاقة الحركة الزمنية');renderScene()});
$('moveAnchorMovement').addEventListener('change',()=>{const p=currentMovement();if(!p)return;snap();p.anchorMovementId=$('moveAnchorMovement').value||null;mark('عُدلت الحركة المرجعية');renderScene()});
$('moveOffset').addEventListener('change',()=>{const p=currentMovement();if(!p)return;snap();p.offset=+$('moveOffset').value||0;mark('عُدلت إزاحة الحركة');renderScene()});
$('moveAbsoluteStart').addEventListener('change',()=>{const p=currentMovement();if(!p)return;snap();p.absoluteStart=Math.max(0,+$('moveAbsoluteStart').value||0);mark('عُدل توقيت الحركة');renderScene()});

// Initial refresh after handlers are in place.
renderMovements();
