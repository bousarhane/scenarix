'use strict';
// Top-view actor figure and pose rendering
function actorFigure(parent,o){
 if(typeof actorIllustration==='function'&&actorIllustration(parent,o))return;
 const g=svgEl('g',{class:'actor-orientation',transform:`rotate(${-Number(o.facing||0)})`});parent.append(g);
 const c=o.color||'#168bc2',gender=o.gender||'neutral',pose=o.pose||'standing';
 const facing=0;
 const addFacing=()=>{const rr=Math.max(o.w,o.h)*.34,ex=Math.sin(facing)*(rr+22),ey=Math.cos(facing)*(rr+22);g.append(svgEl('line',{x1:0,y1:0,x2:ex,y2:ey,class:'actor-facing-line'}));g.append(svgEl('circle',{cx:ex,cy:ey,r:5,fill:'#fff'}))};
 const line=(x1,y1,x2,y2,w=8)=>g.append(svgEl('line',{x1,y1,x2,y2,stroke:c,'stroke-width':w,'stroke-linecap':'round'}));
 const head=(cx,cy,r)=>g.append(svgEl('circle',{cx,cy,r,fill:c,stroke:'#fff','stroke-width':3}));
 const bodyRect=(x,y,w,h,rx)=>g.append(svgEl('rect',{x,y,width:w,height:h,rx,fill:c,stroke:'#fff','stroke-width':3}));
 const bodyEllipse=(cx,cy,rx,ry)=>g.append(svgEl('ellipse',{cx,cy,rx,ry,fill:c,stroke:'#fff','stroke-width':3}));
 if(pose==='sitting'){
   const r=Math.max(11,Math.min(20,o.w*.17));
   head(0,-o.h*.18,r);bodyRect(-o.w*.24,-o.h*.02,o.w*.48,o.h*.24,o.w*.08);
   line(-o.w*.18,o.h*.18,-o.w*.34,o.h*.33);line(o.w*.18,o.h*.18,o.w*.34,o.h*.33);
   line(-o.w*.18,o.h*.32,-o.w*.34,o.h*.32);line(o.w*.18,o.h*.32,o.w*.34,o.h*.32);
 }else if(pose==='floorSitting'){
   const r=Math.max(10,Math.min(18,o.w*.16));
   head(0,-o.h*.2,r);bodyEllipse(0,o.h*.02,o.w*.2,o.h*.18);
   line(-o.w*.12,o.h*.14,-o.w*.34,o.h*.28);line(o.w*.12,o.h*.14,o.w*.34,o.h*.28);
   line(-o.w*.34,o.h*.28,-o.w*.1,o.h*.35);line(o.w*.34,o.h*.28,o.w*.1,o.h*.35);
   line(-o.w*.18,-o.h*.02,-o.w*.34,o.h*.08,7);line(o.w*.18,-o.h*.02,o.w*.34,o.h*.08,7);
 }else if(pose==='side'){
   const r=Math.max(11,Math.min(20,o.w*.16));
   head(-o.w*.16,-o.h*.18,r);bodyRect(-o.w*.12,-o.h*.06,o.w*.25,o.h*.42,o.w*.07);
   line(0,o.h*.3,-o.w*.15,o.h*.49);line(o.w*.06,o.h*.3,o.w*.2,o.h*.49);
   line(0,0,o.w*.28,o.h*.06,7);line(-o.w*.02,o.h*.05,-o.w*.24,o.h*.1,7);
 }else if(pose==='kneeling'){
   const r=Math.max(10,Math.min(18,o.w*.16));
   head(0,-o.h*.24,r);bodyRect(-o.w*.2,-o.h*.08,o.w*.4,o.h*.3,o.w*.08);
   line(-o.w*.1,o.h*.18,-o.w*.24,o.h*.32);line(o.w*.1,o.h*.18,o.w*.24,o.h*.32);
   line(-o.w*.24,o.h*.32,-o.w*.03,o.h*.37);line(o.w*.24,o.h*.32,o.w*.03,o.h*.37);
   line(-o.w*.18,0,-o.w*.36,o.h*.08,7);line(o.w*.18,0,o.w*.36,o.h*.08,7);
 }else if(pose==='crouching'){
   const r=Math.max(10,Math.min(18,o.w*.16));
   head(0,-o.h*.14,r);bodyEllipse(0,o.h*.02,o.w*.23,o.h*.16);
   line(-o.w*.16,o.h*.1,-o.w*.34,o.h*.26);line(o.w*.16,o.h*.1,o.w*.34,o.h*.26);
   line(-o.w*.34,o.h*.26,-o.w*.17,o.h*.4);line(o.w*.34,o.h*.26,o.w*.17,o.h*.4);
   line(-o.w*.18,-o.h*.02,-o.w*.34,o.h*.06,7);line(o.w*.18,-o.h*.02,o.w*.34,o.h*.06,7);
 }else if(pose==='bending'||pose==='bent'){
   const r=Math.max(10,Math.min(18,o.w*.16));
   head(o.w*.16,-o.h*.06,r);bodyEllipse(0,o.h*.02,o.w*.24,o.h*.13);
   line(-o.w*.1,o.h*.1,-o.w*.2,o.h*.43);line(o.w*.1,o.h*.1,o.w*.2,o.h*.43);
   line(o.w*.16,0,o.w*.38,o.h*.12,7);line(-o.w*.06,0,-o.w*.28,o.h*.1,7);
 }else if(['lyingBack','lyingFront','lyingSide','lying'].includes(pose)){
   const side=pose==='lyingSide';
   if(side){
     head(-o.w*.34,0,Math.max(10,Math.min(17,o.h*.2)));bodyRect(-o.w*.2,-o.h*.12,o.w*.45,o.h*.24,o.h*.08);
     line(o.w*.2,-o.h*.05,o.w*.4,-o.h*.16,7);line(o.w*.2,o.h*.05,o.w*.42,o.h*.16,7);
     line(-o.w*.03,-o.h*.08,-o.w*.18,-o.h*.24,6);
   }else{
     head(0,-o.h*.28,Math.max(10,Math.min(18,o.w*.15)));bodyEllipse(0,0,o.w*.2,o.h*.2);
     line(-o.w*.12,o.h*.15,-o.w*.22,o.h*.42);line(o.w*.12,o.h*.15,o.w*.22,o.h*.42);
     line(-o.w*.18,-o.h*.02,-o.w*.36,o.h*.1,7);line(o.w*.18,-o.h*.02,o.w*.36,o.h*.1,7);
     if(pose==='lyingFront')g.append(svgEl('circle',{cx:0,cy:-o.h*.28,r:4,fill:'#111'}));
   }
 }else if(pose==='moving'){
   const r=Math.max(10,Math.min(18,o.w*.16));
   head(-o.w*.03,-o.h*.24,r);bodyRect(-o.w*.18,-o.h*.08,o.w*.36,o.h*.3,o.w*.07);
   line(-o.w*.06,o.h*.18,-o.w*.28,o.h*.46);line(o.w*.08,o.h*.18,o.w*.32,o.h*.35);
   line(-o.w*.15,0,o.w*.12,o.h*.08,7);line(o.w*.15,0,-o.w*.1,o.h*.13,7);
 }else{
   const headY=-o.h*.27,headR=Math.max(12,Math.min(22,o.w*.18));
   head(0,headY,headR);
   if(gender==='female'){
     g.append(svgEl('path',{d:`M${-o.w*.18} ${-o.h*.06} Q0 ${-o.h*.14} ${o.w*.18} ${-o.h*.06} L${o.w*.3} ${o.h*.28} H${-o.w*.3}Z`,fill:c,stroke:'#fff','stroke-width':3,'stroke-linejoin':'round'}))
   }else bodyRect(-o.w*.2,-o.h*.1,o.w*.4,o.h*.42,o.w*.08);
   line(-o.w*.15,o.h*.27,-o.w*.22,o.h*.48);line(o.w*.15,o.h*.27,o.w*.22,o.h*.48);
   line(-o.w*.18,0,-o.w*.38,o.h*.12,7);line(o.w*.18,0,o.w*.38,o.h*.12,7);
 }
 addFacing();
 const sym=svgEl('text',{x:0,y:3,class:'actor-symbol'});sym.textContent=o.symbol||String(o.characterName||o.name||'ش').slice(0,2);parent.append(sym);
 const labels={standing:'واقف',side:'جانبي',sitting:'جالس على كرسي',floorSitting:'جالس أرضًا',kneeling:'راكع',crouching:'قرفصاء',bending:'منحنٍ',bent:'منحنٍ',lyingBack:'على الظهر',lyingFront:'على البطن',lyingSide:'على الجانب',lying:'مستلقي',moving:'حركة'};
 const poseLabel=svgEl('text',{x:0,y:o.h*.62,class:'pose-label'});poseLabel.textContent=labels[pose]||'';parent.append(poseLabel)
}
