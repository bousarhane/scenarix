'use strict';
// Spatial validation and vertical travel share one actor-centred path profile.
// The profile changes support/elevation only. Timing, pose, arms and facing stay authored.
const StageConstraints=(()=>{
 const heights={chair:.9,table:.75,desk:.75,sofa:.85,bed:.55,door:2.2,window:1.2,wall:2.5,column:2.5,stairs:.8,platform:.4,frontCurtain:4,pendrillon:4,frise:.6,cyclorama:4,tree:3,car:1.5,screen:2,prop:.5};
 const solid=['chair','table','desk','sofa','bed','wall','column','stairs','platform','tree','car','screen','prop','door','window','cyclorama'];
 const surfaces=['platform','stairs','bed'];
 const cache=new Map();let renderKey='',report=[];
 const dimension=(v,f)=>Number.isFinite(Number(v))&&Number(v)>0?Number(v):f;
 const height=o=>clamp(dimension(o.height3D,heights[o.type]||.6),.05,10);
 const enabled=o=>typeof o.blocksPassage==='boolean'?o.blocksPassage:solid.includes(o.type);
 const target=(id,sc)=>sc.objects.find(o=>o.id===id);
 const radius=o=>clamp(dimension(o.clearance3D,.22),.05,1)*PPM;
 function bodyHeight(o,sc){const h=clamp(dimension(o.height3D,1.72),.05,10),seat=target(o.support?.targetId,sc);if(o.pose==='sitting')return (seat&&o.support?.mode==='seat'?StageSupport.surface(seat,o):.45)+h*.5;return h*({floorSitting:.55,crouching:.67,kneeling:.76,bending:.73,lyingBack:.3,lyingFront:.3,lyingSide:.4}[o.pose]||1);}
 function overlaps(o,pt,r){
  const q=StageSupport.local(pt,o),w=dimension(o.w,60)/2,d=dimension(o.h,60)/2;
  if(o.platformShape==='circle')return(q.x/(w+r))**2+(q.y/(d+r))**2<1;
  // Rounded rectangle expansion, rather than expanding the bounding box corners.
  return Math.hypot(Math.max(0,Math.abs(q.x)-w),Math.max(0,Math.abs(q.y)-d))<r;
 }
 function panels(o){if(o.type!=='frontCurtain')return[o];const w=dimension(o.w,800),panel=w/2*(1-clamp(Number(o.curtainOpen)||0,0,100)/100*.9),a=(Number(o.rotation)||0)*Math.PI/180;return[-1,1].map(sign=>({...o,w:panel,x:o.x+sign*(w-panel)/2*Math.cos(a),y:o.y+sign*(w-panel)/2*Math.sin(a)}));}
 function supportHeight(binding,pt,sc){const t=target(binding?.targetId,sc);return t?StageSupport.floor(t)+(binding.mode==='surface'?StageSupport.surface(t,pt):0):null;}
 function binding(t,pt,pose='standing'){return t?StageSupport.bind({...pt,pose},t,pose):null;}
 function seatingTarget(p,sc){
  if(actionChannels(p).pose&&p.endPose==='sitting')return target(p.endTargetId,sc);
  const schedule=compileMovementSchedule(sc.paths),entry=schedule.find(i=>i.path.id===p.id);
  if(!entry)return null;
  // Only the next position/body action of this actor can authorize a seating approach.
  const next=schedule.filter(i=>i.path.actorObjectId===p.actorObjectId&&i.path.id!==p.id&&i.start>=entry.end-.001&&(actionChannels(i.path).position||actionChannels(i.path).pose)).sort((a,b)=>a.start-b.start)[0];
  return next&&actionChannels(next.path).pose&&next.path.endPose==='sitting'&&!actionChannels(next.path).position?target(next.path.endTargetId,sc):null;
 }
 function profile(p,o,sc=scene()){
  const key=JSON.stringify([sc.id,p,sc.paths.map(p=>[p.id,p.actorObjectId,p.actionKind,p.endPose,p.endTargetId,p.timingMode,p.anchorMovementId,p.offset,p.absoluteStart,p.duration]),o.initialState||[o.x,o.y,o.pose,o.support,o.terrain],o.clearance3D,o.height3D,o.elevation3D,sc.objects.filter(x=>x.type!=='actor').map(x=>[x.id,x.type,x.x,x.y,x.w,x.h,x.rotation,x.height3D,x.elevation3D,x.seatHeight3D,x.stairSteps,x.stairDirection,x.platformShape,x.blocksPassage,x.curtainOpen])]);
  const old=cache.get(key);if(old)return old;
  const track=svgEl('path',{d:movementPathD(p)}),length=track.getTotalLength(),n=Math.max(1,Math.ceil(length*(p.direction==='both'?2:1)/2)),points=[];
  for(let i=0;i<=n;i++){const t=i/n,q=track.getPointAtLength(length*pathProgress(p,t));points.push({t,x:q.x,y:q.y});}
  const opening=ActorContinuity.base(o),from=p.startSupport===undefined?opening.support:p.startSupport,start=target(from?.targetId,sc),mode=p.travelMode||'walk',dest=target(p.travelTargetId,sc);
  const ground=Number(p.startTerrain?.height??opening.terrain?.height),base=Number.isFinite(ground)?ground:(supportHeight(from,points[0],sc)??StageSupport.floor(opening));
  const footprint=radius(o),issues=[],add=(pt,t,reason)=>issues.push({pathId:p.id,code:p.code||'المسار',objectId:t?.id,objectName:t?.name||'حافة السطح',reason,t:pt.t,x:pt.x,y:pt.y});
  let first=-1,last=-1,contactFirst=-1,contactLast=-1;
  const crossing=mode==='ascend'?dest:mode==='descend'?start:null;
  if(crossing)for(let i=0;i<points.length;i++){if(StageSupport.contains(crossing,points[i])){if(first<0)first=i;last=i;}if(overlaps(crossing,points[i],footprint)){if(contactFirst<0)contactFirst=i;contactLast=i;}}
  if(mode!=='walk'){
   if(p.direction==='both')add(points[0],crossing,'اجعل الصعود والنزول حركتين مستقلتين');
   if(!crossing||!surfaces.includes(crossing.type))add(points[0],crossing,mode==='ascend'?'اختر درجًا أو منصة للصعود':'النزول يحتاج سطح ارتكاز في البداية');
   else if(mode==='ascend'&&(first<0||!StageSupport.contains(crossing,points.at(-1))||StageSupport.contains(crossing,points[0])))add(points.at(-1),crossing,'يبدأ الصعود خارج العنصر وينتهي فوقه');
   else if(mode==='descend'&&(!StageSupport.contains(crossing,points[0])||StageSupport.contains(crossing,points.at(-1))))add(points.at(-1),crossing,'يبدأ النزول فوق العنصر وينتهي خارجه');
   if(crossing?.type==='stairs'&&first>=0){
    const edge=points[mode==='ascend'?first:last],q=StageSupport.local(edge,crossing),low=StageSupport.surface(crossing,edge),bottom=StageSupport.height(crossing)/StageSupport.stepCount(crossing);
    const atLowSide=(crossing.stairDirection==='depth'?q.y:-q.y)>dimension(crossing.h,100)/2-4;
    if(!atLowSide||low>bottom+.001||Math.abs(StageSupport.floor(crossing)+(mode==='ascend'?low:0)-(mode==='ascend'?base:0))>.35)add(edge,crossing,'استعمل طرف الدرج المنخفض؛ لا تعبر جانبه أو خلفه');
   }
  }
  const seat=seatingTarget(p,sc),seatApproach=seat&&StageSupport.allowed(seat,'sitting')&&StageSupport.contains(seat,points.at(-1));
  let seatContact=points.length;if(seatApproach){seatContact=points.length-1;while(seatContact>0&&overlaps(seat,points[seatContact-1],footprint))seatContact--;}
  let prevHeight=base;
  for(let i=0;i<points.length;i++){
   const pt=points[i];let z=base,support=null;
   const same=sc.objects.filter(t=>surfaces.includes(t.type)&&StageSupport.contains(t,pt)&&Math.abs(StageSupport.floor(t)+StageSupport.surface(t,pt)-base)<.035);
   if(start&&StageSupport.contains(start,pt)){z=from.mode==='seat'?base:StageSupport.floor(start)+StageSupport.surface(start,pt);support=start;}
   else if(same.length)support=same[0];
   if(mode==='ascend'&&crossing&&first>=0){
    if(crossing.type==='stairs'){
     if(i>=first){z=StageSupport.floor(crossing)+StageSupport.surface(crossing,pt);support=crossing;}
     else{const entry=StageSupport.floor(crossing)+StageSupport.surface(crossing,points[first]),q=clamp((pt.t-(points[first].t-Math.min(.25,20/Math.max(1,length))))/Math.min(.25,20/Math.max(1,length)),0,1);z=base+(entry-base)*q;}
    }else{
     const top=StageSupport.floor(crossing)+StageSupport.surface(crossing,pt),end=points[Math.max(0,contactFirst)].t,span=Math.min(end,60/Math.max(1,length)),q=span?clamp((pt.t-end+span)/span,0,1):1;z=base+(top-base)*q;if(i>=first)support=crossing;
    }
   }else if(mode==='descend'&&crossing&&last>=0){
    if(i<=last){z=StageSupport.floor(crossing)+StageSupport.surface(crossing,pt);support=crossing;}
    else{const begin=points[Math.max(last,contactLast)].t,span=Math.min(1-begin,(crossing.type==='stairs'?20:60)/Math.max(1,length)),q=span?clamp((pt.t-begin)/span,0,1):1,edge=StageSupport.floor(crossing)+StageSupport.surface(crossing,points[last]);z=edge*(1-q);}
   }
   if(mode==='ascend'&&crossing&&first>=0&&i>=first&&!StageSupport.contains(crossing,pt))add(pt,crossing,'قسّم الصعود ثم السير أو النزول إلى حركات مستقلة');
   if(mode==='descend'&&crossing&&last>=0&&i<=last&&!StageSupport.contains(crossing,pt))add(pt,crossing,'قسّم النزول والصعود إلى حركات مستقلة');
   if(mode==='walk'&&start&&from.mode==='surface'&&!support)add(pt,start,'حافة مرتفعة: أضف نزولًا أو سطحًا متصلًا بالارتفاع نفسه');
   if(support?.type==='stairs'&&i&&Math.abs(z-prevHeight)>.35)add(pt,support,'ارتفاع الدرجة يتجاوز 35 سم');
   prevHeight=z;pt.height=z;pt.support=support?binding(support,pt,support.id===start?.id&&from?.mode==='seat'?'sitting':'standing'):null;
   for(const obstacle of sc.objects){
    if(obstacle.type==='actor'||!enabled(obstacle)||obstacle.id===support?.id||crossing?.type==='stairs'&&obstacle.id===crossing.id)continue;
    const floor=StageSupport.floor(obstacle),top=floor+(obstacle.type==='stairs'?StageSupport.surface(obstacle,pt):height(obstacle));
    if(z>=top-.025||z+bodyHeight({...o,...pt,pose:p.startPose||opening.pose,support:pt.support||opening.support},sc)<=floor+.025)continue;
    if(seatApproach&&obstacle.id===seat.id&&i>=seatContact)continue;
    if(panels(obstacle).some(part=>overlaps(part,pt,footprint)))add(pt,obstacle,'المسار يخترق العنصر');
   }
  }
  if(mode==='ascend'&&dest&&points.at(-1).height<=base+.025)add(points.at(-1),dest,'السطح النهائي ليس أعلى من البداية');
  const value={points,issues,mode,from,base,controlled:!!start||mode!=='walk'};cache.set(key,value);if(cache.size>64)cache.delete(cache.keys().next().value);return value;
 }
 function seatedOffset(value,sc,depth=0){
  const seat=(pose,support)=>{const t=target(support?.targetId,sc);return pose==='sitting'&&support?.mode==='seat'&&t?StageSupport.surface(t,value):0;};
  const transition=value.poseTransition;
  if(!transition||depth>12)return seat(value.pose,value.support);
  const from=transition.fromState?seatedOffset({...value,poseTransition:transition.fromState},sc,depth+1):seat(transition.from,transition.fromSupport),to=seat(transition.to,transition.toSupport),t=clamp(Number(transition.progress)||0,0,1);
  return from+(to-from)*t;
 }
 function sample(list,sec,o,result){
  const item=chooseChannelAction(list,sec,'position');if(!item||item.path.actionKind==='state'||item.path.pathShape==='stationary')return result;
  const value=profile(item.path,o),t=clamp((sec-item.start)/Math.max(.001,item.end-item.start),0,1);
  if(!value.controlled||value.from?.mode==='seat'&&value.mode==='walk')return result;
  const idx=t*(value.points.length-1),i=Math.min(value.points.length-2,Math.floor(idx)),a=value.points[i],b=value.points[i+1],f=idx-i,z=a.height+(b.height-a.height)*f;
  const pt=f<.5?a:b,targetObject=target(pt.support?.targetId,scene());
  // Vertical travel owns elevation/support; it never changes the body's pose or facing.
  if(!(targetObject&&result.support?.targetId===targetObject.id))result.support=targetObject&&StageSupport.contains(targetObject,result)?binding(targetObject,result):null;
  const rootHeight=z-seatedOffset(result,scene()),nativeHeight=StageSupport.elevation({...result,terrain:null});
  result.terrain=Math.abs(nativeHeight-rootHeight)<.025?null:{height:rootHeight,actorX:result.x,actorY:result.y};
  return result;
 }
 function validate(entries,sc=scene(),sources){return entries.filter(i=>i.path.actionKind!=='state'&&actionChannels(i.path).position&&i.path.pathShape!=='stationary').flatMap(i=>{const o=sources?.get(i.path.actorObjectId)||target(i.path.actorObjectId,sc);return o?profile(i.path,o,sc).issues.map(issue=>({...issue,time:i.start+(i.end-i.start)*issue.t})):[];});}
 function message(issue){return `${issue.code} · ${issue.objectName}: ${issue.reason}`;}
 function allow(entries,sc=scene(),sources){const issues=validate(entries,sc,sources);if(!issues.length)return true;selectedPathId=issues[0].pathId;selectedId=null;renderScene();$('statusText').textContent=message(issues[0]);alert('تعذر بدء القراءة قبل تصحيح المسار:\n'+message(issues[0])+'\nعدّل المسار، أو اختر صعودًا / نزولًا، أو راجع خاصية «يمنع المرور» للعنصر.');return false;}
 function paint(value,parent){if(!value.issues.length)return;const bad=new Set(value.issues.map(i=>i.t));let d='',active=false;for(const pt of value.points){if(bad.has(pt.t)){d+=(active?'L':'M')+pt.x+' '+pt.y;active=true;}else{if(active)d+='L'+pt.x+' '+pt.y;active=false;}}parent.append(svgEl('path',{d,fill:'none',stroke:'#dc2626','stroke-width':6,'stroke-opacity':.85,'pointer-events':'none',class:'spatial-conflict'}));}
 function preview(p,parent){const o=target(p.actorObjectId,scene());if(o)paint(profile(p,o),parent);}
 function render(){
  if(movementPlayback)return;
  const sc=scene(),key=JSON.stringify([sc.id,sc.paths,sc.objects]);
  if(key!==renderKey){renderKey=key;const entries=ActorContinuity.prepare(compileMovementSchedule(),sc);report=validate(entries,sc);window.StageConstraints.lastEntries=entries;}
  let group=$('spatialConflicts');group?.remove();group=svgEl('g',{id:'spatialConflicts','pointer-events':'none'});layerGroup('movement').append(group);
  for(const item of window.StageConstraints.lastEntries||[]){const o=target(item.path.actorObjectId,sc);if(o&&actionChannels(item.path).position&&item.path.actionKind!=='state'&&item.path.pathShape!=='stationary')paint(profile(item.path,o),group);}
  const messages=[...new Map(report.map(i=>[i.pathId+'|'+i.objectId+'|'+i.reason,i])).values()];
  $('spatialStatus').hidden=!messages.length;$('spatialStatus').textContent=messages.length?`${messages.length} تعارض في المسارات — صحّح الأجزاء الحمراء قبل القراءة`:'';
  $('movementSpatialStatus').textContent=messages.filter(i=>i.pathId===selectedPathId).map(message).join('\n');
 }
 return{enabled,radius,profile,sample,validate,allow,preview,render,issues:()=>report};
})();
window.StageConstraints=StageConstraints;
(function(){
 const status=document.createElement('p');status.id='spatialStatus';status.setAttribute('role','status');status.style.cssText='color:#b91c1c;margin:4px 8px;font-size:13px';document.querySelector('.directing-tools').after(status);
 const details=document.createElement('p');details.id='movementSpatialStatus';details.style.cssText='white-space:pre-line;color:#b91c1c';$('movementProperties').querySelector('h2').after(details);
 const controls=document.createElement('fieldset');controls.id='passageFields';controls.innerHTML='<legend>المرور حول العنصر</legend><label><input id="blocksPassage" type="checkbox"> يمنع المرور داخل حجمه</label><small>يُراعى ارتفاع العنصر. إخفاء طبقة في المخطط لا يزيل العائق من المشهد.</small>';$('sceneryControls').after(controls);
 const clearance=document.createElement('label');clearance.id='actorClearanceLabel';clearance.innerHTML='مسافة خلوص الممثل بالمتر<input id="actorClearance" type="number" min="0.05" max="1" step="0.01" value="0.22"><small>المسافة من مركز الممثل إلى العائق؛ لا تعتمد على حجم الأيقونة.</small>';$('actorSupportFields').append(clearance);
 const props=renderProperties;renderProperties=function(){props();const o=selected();controls.hidden=!o||['actor','group','note','light'].includes(o.type);if(o){$('blocksPassage').checked=StageConstraints.enabled(o);$('blocksPassage').disabled=!!layer(o.layer)?.locked;$('actorClearance').value=o.clearance3D||.22;$('actorClearance').disabled=!!layer(o.layer)?.locked;}};
 for(const [id,key] of [['blocksPassage','blocksPassage'],['actorClearance','clearance3D']])$(id).onchange=()=>{const o=selected(),el=$(id);if(!o||layer(o.layer)?.locked||!el.checkValidity())return;const value=id==='blocksPassage'?el.checked:Number(el.value);stopSimulation();snap();o[key]=value;mark('عُدّلت حدود المرور');renderScene();};
 for(const prefix of ['newMove','move']){
  const field=document.createElement('fieldset');field.id=prefix+'TravelFields';field.innerHTML=`<legend>السطح والارتفاع</legend><label>الانتقال<select id="${prefix}TravelMode"><option value="walk">سير على الأرض أو سطح الارتكاز</option><option value="ascend">صعود إلى درج / منصة</option><option value="descend">نزول من سطح الارتكاز إلى الأرض</option></select></label><label id="${prefix}TravelTargetLabel">عنصر الصعود<select id="${prefix}TravelTarget"></select></label><small>الصعود عبر الطرف المنخفض للدرج. الصعود المباشر إلى منصة يمثل تسلقًا يختاره المخرج.</small>`;
  $(prefix+'GeometryOptions').append(field);
  const update=()=>{$(prefix+'TravelTargetLabel').hidden=$(prefix+'TravelMode').value!=='ascend';};
  $(prefix+'TravelMode').onchange=()=>{update();if(prefix==='move')TheatricalActions.saveActionEdit();};$(prefix+'TravelTarget').onchange=()=>{if(prefix==='move')TheatricalActions.saveActionEdit();};
  update();
 }
 const fill=fillChoreo;fillChoreo=function(prefix,p,o){fill(prefix,p,o);$(prefix+'TravelMode').value=p.travelMode||'walk';const select=$(prefix+'TravelTarget');select.replaceChildren(new Option('اختر العنصر',''));for(const t of scene().objects.filter(t=>['platform','stairs','bed'].includes(t.type)))select.append(new Option(t.name,t.id));select.value=p.travelTargetId||'';$(prefix+'TravelTargetLabel').hidden=$(prefix+'TravelMode').value!=='ascend';};
 const read=readChoreo;readChoreo=function(prefix){return{...read(prefix),travelMode:$(prefix+'TravelMode').value,travelTargetId:$(prefix+'TravelTarget').value||null};};
 const apply=applyChoreographyData;applyChoreographyData=function(p,data){apply(p,data);p.travelMode=data.travelMode||'walk';p.travelTargetId=data.travelTargetId||null;};
 const place=placeMovementActorAtEnd;placeMovementActorAtEnd=function(p){place(p);const o=scene().objects.find(o=>o.id===p.actorObjectId);if(!o||!actionChannels(p).position||p.pathShape==='stationary')return;const entry=ActorContinuity.prepare(compileMovementSchedule()).find(i=>i.path.id===p.id);if(entry){const result=StageConstraints.sample([entry],entry.end,o,{...ActorContinuity.stateOf(o),...movementEndPosition(entry.path)});o.support=result.support;o.terrain=result.terrain||null;}};
 const redraw=redrawEnhancedMovement;redrawEnhancedMovement=function(){const p=currentMovement();redraw();if(p&&pendingMovement)Object.assign(pendingMovement,{travelMode:p.travelMode||'walk',travelTargetId:p.travelTargetId||null,startTerrain:clone(p.startTerrain||null)});};$('redrawMovementBtn').onclick=redrawEnhancedMovement;
 const render=renderScene;renderScene=function(){if(!movementPlayback)for(const o of scene().objects)if(o.type==='actor'&&!o.support&&o.terrain&&Number.isFinite(o.terrain.actorX)&&Math.hypot(o.x-o.terrain.actorX,o.y-o.terrain.actorY)>.001)o.terrain=null;render();StageConstraints.render();};

 // Restore feedback without replacing any existing actor or scenic asset.
 renderProperties();StageConstraints.render();
})();
