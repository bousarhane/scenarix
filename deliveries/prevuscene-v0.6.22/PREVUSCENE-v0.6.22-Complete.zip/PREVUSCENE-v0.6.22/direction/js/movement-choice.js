'use strict';
// Two entry points into the existing theatrical action engine.
(function(){
 const dialog=document.createElement('dialog');dialog.id='movementChoiceDialog';dialog.className='movement-choice-dialog';
 dialog.innerHTML='<h2>الحركة</h2><p>ماذا تريد أن يفعل الممثل؟</p><div class="movement-choice-buttons"><button type="button" id="chooseTranslationBtn"><b>انتقال</b><span>رسم حركة من مكان إلى آخر</span></button><button type="button" id="choosePostureBtn"><b>وضع</b><span>تغيير الجسم أو الاتجاه في المكان</span></button></div><menu><button type="button" id="cancelMovementChoiceBtn">إلغاء</button></menu>';
 document.body.append(dialog);$('cancelMovementChoiceBtn').onclick=()=>dialog.close();
 const fields=new Map(),kindControl=prefix=>$(prefix+'ActionKind');
 for(const prefix of ['newMove','move']){
  kindControl(prefix).append(new Option('وضع واستدارة','posture'));kindControl(prefix).closest('label').hidden=true;
  const panel=document.createElement('div');panel.className='movement-entry-controls';
  panel.innerHTML=`<div class="movement-entry-buttons" role="group" aria-label="طبيعة الحركة"><button type="button" id="${prefix}TranslationBtn">انتقال</button><button type="button" id="${prefix}PostureBtn">وضع</button></div><p id="${prefix}EntryHint" class="hint"></p><label id="${prefix}PostureModeWrap">الفعل في المكان<select id="${prefix}PostureMode"><option value="pose">تغيير الوضعية الجسدية</option><option value="turn">استدارة إلى اتجاه آخر</option><option value="target">التوجّه نحو ممثل أو عنصر</option><option value="posture">تغيير الوضعية والاستدارة معًا</option><option value="hold">تريث</option><option value="gesture">حركة الذراعين</option></select></label><label id="${prefix}TranslationBodyWrap" class="movement-optional-body"><input id="${prefix}TranslationBody" type="checkbox"> تغيير الوضعية والاتجاه أثناء الانتقال</label>`;
  kindControl(prefix).closest('label').before(panel);fields.set(prefix,panel);
  const facing=document.createElement('div');facing.id=prefix+'OrientationWrap';facing.innerHTML=`<label>نحو أي اتجاه؟<select id="${prefix}OrientationChoice"><option value="0">نحو الجمهور — أمام</option><option value="90">يمين الرسم</option><option value="180">نحو عمق الخشبة — خلف</option><option value="270">يسار الرسم</option><option value="custom">زاوية محددة</option><option value="target">نحو ممثل أو عنصر</option><option value="fixed">الاحتفاظ باتجاه البداية</option><option value="tangent">اتجاه مسار الانتقال</option><option value="center">نحو مركز الدائرة</option></select></label><label id="${prefix}LookTargetWrap">الممثل أو العنصر المقصود<select id="${prefix}LookTarget"><option value="">اختر من الخشبة</option></select></label>`;
  $(prefix+'FacingMode').append(new Option('يتوجه نحو عنصر','target'));$(prefix+'FacingMode').closest('label').before(facing);
  $(prefix+'TranslationBtn').onclick=()=>configure(prefix,'translate',true);
  $(prefix+'PostureBtn').onclick=()=>configure(prefix,$(prefix+'PostureMode').value||'pose',true);
  $(prefix+'PostureMode').onchange=()=>configure(prefix,$(prefix+'PostureMode').value,true);
  $(prefix+'TranslationBody').onchange=()=>configure(prefix,$(prefix+'TranslationBody').checked?'compound':'translate',true);
  $(prefix+'OrientationChoice').onchange=()=>{applyOrientation(prefix);refresh(prefix);save(prefix);};
  $(prefix+'LookTarget').onchange=()=>{updateTargetAngle(prefix);save(prefix);};
  const body=$(prefix+'StartPose').closest('fieldset'),timing=$(prefix+'TimingMode').closest('fieldset');timing.before(body);
  const geometry=document.createElement('div');geometry.id=prefix+'GeometryOptions';geometry.append($(prefix+'Sweep').closest('.two'));const pathHint=body.querySelectorAll(':scope > small')[1];if(pathHint)geometry.append(pathHint);body.before(geometry);
  $(prefix+'EndFacing').addEventListener('input',()=>{$(prefix+'OrientationChoice').value='custom';});
  $(prefix+'FacingMode').addEventListener('change',()=>{syncOrientation(prefix);refresh(prefix);});
  $(prefix+'Shape').addEventListener('change',()=>refresh(prefix));
 }
 function spatial(prefix){return kindControl(prefix).value==='translate'||(kindControl(prefix).value==='compound'&&$(prefix+'Shape').value!=='stationary');}
 function save(prefix){if(prefix==='move')TheatricalActions.saveActionEdit();}
 function fillTargets(prefix,value){
  const actorId=$(prefix+'Actor').value,select=$(prefix+'LookTarget');select.replaceChildren(new Option('اختر من الخشبة',''));
  for(const o of scene().objects.filter(o=>o.id!==actorId))select.append(new Option(`${o.type==='actor'?'ممثل':'عنصر'} — ${o.characterName||o.name||o.type}`,o.id));
  if(value&&!Array.from(select.options).some(o=>o.value===value)){const option=new Option('الهدف غير موجود في هذا المشهد',value);option.disabled=true;select.append(option);}
  select.value=value||'';
 }
 function syncOrientation(prefix,preferred){
  const mode=$(prefix+'FacingMode').value,end=normalFacing(Number($(prefix+'EndFacing').value));
  $(prefix+'OrientationChoice').value=mode==='turn'?(preferred==='custom'?'custom':([0,90,180,270].includes(end)?String(end):'custom')):mode;
 }
 function updateTargetAngle(prefix){
  const actor=scene().objects.find(o=>o.id===$(prefix+'Actor').value),target=scene().objects.find(o=>o.id===$(prefix+'LookTarget').value);
  if(actor&&target&&Math.hypot(target.x-actor.x,target.y-actor.y)>.00001)$(prefix+'EndFacing').value=normalFacing(Math.atan2(target.x-actor.x,target.y-actor.y)*180/Math.PI);
 }
 function applyOrientation(prefix){
  const choice=$(prefix+'OrientationChoice').value;
  $(prefix+'FacingMode').value=['target','fixed','tangent','center'].includes(choice)?choice:'turn';
  if(['0','90','180','270'].includes(choice))$(prefix+'EndFacing').value=choice;
  if(choice==='target')updateTargetAngle(prefix);
 }
 function refresh(prefix){
  const isSpatial=spatial(prefix),kind=kindControl(prefix).value,channels=actionChannels({actionKind:kind}),orientation=$(prefix+'OrientationChoice').value;
  $(prefix+'TranslationBtn').setAttribute('aria-pressed',String(isSpatial));$(prefix+'PostureBtn').setAttribute('aria-pressed',String(!isSpatial));
  if(!isSpatial){for(const suffix of ['Shape','Direction','Curve','Speed'])$(prefix+suffix).closest(['Curve','Speed'].includes(suffix)?'label':'.two').hidden=true;$(prefix+'Type').closest('label').hidden=true;}
  $(prefix+'PostureModeWrap').hidden=isSpatial;$(prefix+'TranslationBodyWrap').hidden=!isSpatial;
  $(prefix+'EntryHint').textContent=isSpatial?'ارسم المسار على الخشبة؛ نقطة البداية هي موقع الممثل.':'الموقع ثابت؛ يتغير الجسم أو الاتجاه خلال المدة التي تحددها.';
  $(prefix+'OrientationWrap').hidden=!channels.facing;$(prefix+'LookTargetWrap').hidden=!channels.facing||orientation!=='target';
  $(prefix+'FacingMode').closest('label').hidden=true;
  $(prefix+'EndFacing').closest('label').hidden=!channels.facing||orientation!=='custom';
  for(const value of ['fixed','tangent','center'])Array.from($(prefix+'OrientationChoice').options).find(o=>o.value===value).disabled=!isSpatial;
  const field=$(prefix+'StartPose').closest('fieldset');field.querySelector('legend').textContent='وضعية الجسم واتجاهه';
  // Path instructions belong to the translation editor only.
  field.querySelectorAll(':scope > small').forEach(node=>{node.hidden=!channels.facing;});
  $(prefix+'GeometryOptions').hidden=!isSpatial;
  if(prefix==='newMove')$('movementDialog').querySelector('h2').textContent=isSpatial?'انتقال الممثل':'وضع الممثل في المكان';
 }
 function configure(prefix,requested,edited){
  const target=requested==='target',kind=target?'turn':requested;
  kindControl(prefix).value=kind;
  if(['pose','turn','posture','hold','gesture'].includes(kind)){
   if($(prefix+'Shape').value!=='stationary')$(prefix+'Shape').dataset.lastSpatial=$(prefix+'Shape').value;
   $(prefix+'Shape').value='stationary';$(prefix+'PostureMode').value=target?'target':kind;
   if(kind==='pose'||kind==='posture'){$(prefix+'PoseInterpolation').value='smooth';$(prefix+'PoseAt').value=0;$(prefix+'PoseEndAt').value=100;}
   if(kind==='pose'||kind==='hold'||kind==='gesture')$(prefix+'FacingMode').value='fixed';
   if(kind==='turn'||kind==='posture')$(prefix+'FacingMode').value=target?'target':'turn';
   if(kind==='turn')$(prefix+'EndPose').value=$(prefix+'StartPose').value;
  }else{
   if($(prefix+'Shape').value==='stationary')$(prefix+'Shape').value=$(prefix+'Shape').dataset.lastSpatial||'curve';
   $(prefix+'TranslationBody').checked=kind==='compound';
  }
  TheatricalActions.updateControls(prefix);syncOrientation(prefix);refresh(prefix);if(edited)save(prefix);
 }
 const fill=fillChoreo;fillChoreo=function(prefix,p,o){
  fill(prefix,p,o);fillTargets(prefix,p.lookTargetId);
  const kind=actionKind(p);$(prefix+'PostureMode').value=kind==='compound'&&p.pathShape==='stationary'?'posture':kind==='turn'&&p.facingMode==='target'?'target':['pose','turn','posture','hold','gesture'].includes(kind)?kind:'pose';
  $(prefix+'TranslationBody').checked=kind==='compound';syncOrientation(prefix,p.orientationChoice);refresh(prefix);
 };
 const read=readChoreo;readChoreo=function(prefix){return{...read(prefix),orientationChoice:$(prefix+'OrientationChoice').value,lookTargetId:$(prefix+'FacingMode').value==='target'?$(prefix+'LookTarget').value||null:null};};
 const begin=beginEnhancedMovementDraw;beginEnhancedMovementDraw=function(){
  if(actionChannels({actionKind:kindControl('newMove').value}).facing&&$('newMoveFacingMode').value==='target'){
   const target=scene().objects.find(o=>o.id===$('newMoveLookTarget').value);
   if(!target||target.id===$('newMoveActor').value){alert('اختر ممثلًا آخر أو عنصرًا موجودًا على الخشبة للتوجّه نحوه.');return false;}
   updateTargetAngle('newMove');
  }
  return begin();
 };
 // Explicit form lifecycle: cancelling never validates; only active fields gate starting.
 const editor=$('movementDialog'),form=editor.querySelector('form'),start=$('startMovementDrawBtn'),cancel=form.querySelector('button[value="cancel"]');
 form.noValidate=true;cancel.type='button';cancel.id='cancelMovementDrawBtn';
 cancel.onclick=()=>editor.close('cancel');
 start.type='submit';start.onclick=null;
 form.addEventListener('submit',ev=>{
  ev.preventDefault();
  for(const input of Array.from(form.elements)){
   if(input.willValidate&&input.getClientRects().length&&!input.checkValidity()){input.reportValidity();return;}
  }
  if(beginEnhancedMovementDraw()===true)editor.close('default');
 });
 // Retain the chosen entry when changing actor; initialise the body from the new actor.
 let actorEntry=null;
 $('newMoveActor').addEventListener('change',()=>{actorEntry=kindControl('newMove').value==='turn'&&$('newMoveFacingMode').value==='target'?'target':kindControl('newMove').value;},true);
 $('newMoveActor').addEventListener('change',()=>configure('newMove',actorEntry||'translate',false));
 function openChoice(){stopSimulation();dialog.showModal();}
 const open=enhancedOpenMovementDialog;
 function openEditor(kind){dialog.close();open();configure('newMove',kind,false);}
 $('chooseTranslationBtn').onclick=()=>openEditor('translate');$('choosePostureBtn').onclick=()=>openEditor('pose');
 $('createMovementBtn').onclick=openChoice;$('pathTool').onclick=openChoice;
 window.MovementChoice={open:openChoice};
})();
