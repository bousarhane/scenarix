'use strict';
// A theatrical action may own position, bodily pose, facing, or a combination.
function actionKind(p){return ['translate','pose','turn','hold','posture','gesture','compound'].includes(p.actionKind)?p.actionKind:'compound';}
function actionChannels(p){if(p.actionKind==='state'){const k=p.stateKeys||[];return{position:k.includes('x')||k.includes('y'),pose:k.some(k=>['pose','poseTransition','support','terrain'].includes(k)),facing:k.includes('facing'),leftArm:k.includes('leftArm'),rightArm:k.includes('rightArm')};}const kind=actionKind(p);return{position:kind==='translate'||kind==='compound',pose:kind==='pose'||kind==='posture'||kind==='compound',facing:kind==='turn'||kind==='posture'||kind==='compound',leftArm:kind==='gesture'&&p.armSide!=='right',rightArm:kind==='gesture'&&p.armSide!=='left'};}
function actionKindLabel(p){if(actionKind(p)==='gesture')return ArmGestures.label(p);if(p.facingMode==='target'&&actionChannels(p).facing)return actionChannels(p).position&&p.pathShape!=='stationary'?'انتقال وتوجّه نحو عنصر':actionChannels(p).pose?'وضع نحو عنصر':'توجّه نحو عنصر';if(actionKind(p)==='compound'&&p.pathShape==='stationary')return 'وضع واستدارة';return{translate:'انتقال مكاني',pose:'وضعية جسدية',turn:'استدارة',hold:'تريث',posture:'وضع واستدارة',compound:'انتقال مع وضع'}[actionKind(p)];}
function bodyActionState(p,t,startPose,endPose,o){
 const supports=StageSupport.bodyBindings(p,o);
 const at=clamp(Number(p.poseAt??100),0,100)/100;
 if(p.poseInterpolation!=='smooth')return{pose:t>=at?endPose:startPose,poseTransition:t<at?(p.startBodyState||null):null,support:t>=at?supports.to:supports.from};
 const end=Math.max(at,clamp(Number(p.poseEndAt??100),0,100)/100);
 if(t>=end)return{pose:endPose,poseTransition:null,support:supports.to};
 if(t<=at)return{pose:startPose,poseTransition:p.startBodyState||null,support:supports.from};
 const progress=(t-at)/Math.max(.000001,end-at),eased=progress*progress*(3-2*progress);
 return{pose:progress<.5?startPose:endPose,support:supports.to||supports.from,poseTransition:{from:startPose,to:endPose,progress:eased,fromState:p.startBodyState||null,seatTargetId:p.endTargetId||null,fromSupport:supports.from,toSupport:supports.to}};
}
function chooseChannelAction(list,sec,channel){
 const candidates=list.filter(item=>actionChannels(item.path)[channel]);if(!candidates.length)return null;
 const priority=(a,b)=>b.start-a.start||Number(actionKind(a.path)==='compound')+Number(a.path.actionKind==='state')-Number(actionKind(b.path)==='compound')-Number(b.path.actionKind==='state')||(Number(b.path.stateOrder)||0)-(Number(a.path.stateOrder)||0);
 return candidates.filter(x=>sec>=x.start).sort(priority)[0]||null;
}
function sampleActorPosition(list,sec,o){
 const item=chooseChannelAction(list,sec,'position');if(!item){const base=window.ActorContinuity?.base(o,list)||o;return{x:base.x,y:base.y};}
 if(item.path.actionKind==='state')return{x:item.path.stateValue.x,y:item.path.stateValue.y};
 const t=clamp((sec-item.start)/Math.max(.001,item.end-item.start),0,1),q=pathProgress(item.path,t);
 if(t===1)return movementEndPosition(item.path);
 const point=item.track.getPointAtLength(item.track.getTotalLength()*q);
 // SVGPoint has prototype getters; return plain coordinates so cloning/spreading
 // into actor state cannot silently fall back to the actor's displayed endpoint.
 return{x:point.x,y:point.y};
}
function actionSample(item,sec,o,resolvePosition){
 if(item.path.actionKind==='state')return{t:1,...clone(item.path.stateValue)};
 const t=clamp((sec-item.start)/Math.max(.001,item.end-item.start),0,1),q=pathProgress(item.path,t),pt=t===1?movementEndPosition(item.path):item.track.getPointAtLength(item.track.getTotalLength()*q);
 const at=clamp(sec,item.start,item.end),source=resolvePosition?{...o,...resolvePosition(o.id,at)}:o;
 return{t,x:pt.x,y:pt.y,...choreoState(item.path,t,source,item.track,resolvePosition? id=>resolvePosition(id,at):null)};
}
function sampleActorActions(list,sec,o,resolvePosition){
 const base=window.ActorContinuity?.base(o,list)||o;
 const result={x:base.x,y:base.y,pose:base.pose||'standing',facing:Number(base.facing)||0,poseTransition:base.poseTransition||null,support:clone(base.support||null),arms:clone(base.arms||{}),terrain:clone(base.terrain||null)};
 for(const channel of ['position','pose','facing']){
  const item=chooseChannelAction(list,sec,channel);if(!item)continue;
  const value=actionSample(item,sec,o,resolvePosition);
  if(channel==='position'){result.x=value.x;result.y=value.y;}
  else if(channel==='pose'){result.pose=value.pose;result.poseTransition=value.poseTransition;result.support=value.support;result.terrain=value.terrain||null;}
  else result.facing=value.facing;
 }
 for(const side of ['left','right']){const item=chooseChannelAction(list,sec,side+'Arm');if(item?.path.actionKind==='state'){if(Object.hasOwn(item.path.stateValue.arms||{},side))result.arms[side]=clone(item.path.stateValue.arms[side]);else delete result.arms[side];}else if(item)result.arms[side]=ArmGestures.sample(item.path,clamp((sec-item.start)/Math.max(.001,item.end-item.start),0,1),o,side,resolvePosition? id=>resolvePosition(id,sec):null);}
 StageSupport.atPosition(result);
 return window.StageConstraints ? StageConstraints.sample(list,sec,o,result) : result;
}
(function(){
 const bodyFields=new Map();
 for(const prefix of ['newMove','move']){
  const label=document.createElement('label');label.className='action-kind-field';label.innerHTML=`طبيعة الفعل<select id="${prefix}ActionKind"><option value="compound">انتقال مع وضعية / استدارة</option><option value="translate">انتقال مكاني فقط</option><option value="pose">تغيير وضعية جسدية في المكان</option><option value="turn">استدارة في المكان</option><option value="hold">تريث في المكان</option></select><small>الانتقال يغيّر الموقع، والوضعية تغيّر الجسم، والاستدارة تغيّر الاتجاه. يمكن توقيتها متتابعة أو متزامنة.</small>`;
  $(prefix+'Actor').closest('label').before(label);
  const field=$(prefix+'StartPose').closest('fieldset');bodyFields.set(prefix,field);
  const mode=document.createElement('label');mode.innerHTML=`كيفية تغيير الوضعية<select id="${prefix}PoseInterpolation"><option value="step">تبديل عند اللحظة المحددة</option><option value="smooth">تغيير تدريجي خلال المدة</option></select>`;
  const end=document.createElement('label');end.innerHTML=`اكتمال الوضعية عند % من مدة الفعل<input id="${prefix}PoseEndAt" type="number" min="0" max="100" value="100">`;
  $(prefix+'PoseAt').closest('label').before(mode);$(prefix+'PoseAt').closest('label').after(end);
  $(prefix+'ActionKind').onchange=()=>{
   const kind=$(prefix+'ActionKind').value;
   if(['pose','turn','posture','hold','gesture'].includes(kind)){$(prefix+'Shape').dataset.lastSpatial=$(prefix+'Shape').value!=='stationary'?$(prefix+'Shape').value:($(prefix+'Shape').dataset.lastSpatial||'straight');$(prefix+'Shape').value='stationary';}
   else if($(prefix+'Shape').value==='stationary')$(prefix+'Shape').value=$(prefix+'Shape').dataset.lastSpatial||'straight';
   if(kind==='pose'||kind==='posture'){$(prefix+'PoseInterpolation').value='smooth';$(prefix+'PoseAt').value=0;$(prefix+'PoseEndAt').value=100;$(prefix+'FacingMode').value='fixed';}
   if(kind==='turn'){$(prefix+'FacingMode').value='turn';$(prefix+'EndPose').value=$(prefix+'StartPose').value;}
   updateControls(prefix);if(prefix==='move')saveActionEdit();
  };
  $(prefix+'PoseInterpolation').onchange=()=>{if($(prefix+'PoseInterpolation').value==='smooth'&&Number($(prefix+'PoseAt').value)===100)$(prefix+'PoseAt').value=0;updateControls(prefix);if(prefix==='move')saveActionEdit();};
  $(prefix+'PoseEndAt').onchange=()=>{if(prefix==='move')saveActionEdit();};
  $(prefix+'Shape').addEventListener('change',()=>updateControls(prefix));
 }
 function updateControls(prefix){
  const kind=$(prefix+'ActionKind').value,spatial=['compound','translate'].includes(kind),pose=['compound','pose','posture'].includes(kind),facing=['compound','turn','posture'].includes(kind);
  for(const suffix of ['Shape','Direction','Curve','Speed'])$(prefix+suffix).closest(['Curve','Speed'].includes(suffix)?'label':'.two').hidden=!spatial;
  $(prefix+'Type').closest('label').hidden=!spatial;
  bodyFields.get(prefix).hidden=!pose&&!facing;
  $(prefix+'StartPose').closest('.two').hidden=!pose;$(prefix+'StartFacing').closest('.two').hidden=!facing;
  $(prefix+'FacingMode').closest('label').hidden=!facing||kind==='turn';
  $(prefix+'PoseInterpolation').closest('label').hidden=!pose;$(prefix+'PoseAt').closest('label').hidden=!pose;$(prefix+'EndTarget').closest('label').hidden=!pose;
  const smooth=$(prefix+'PoseInterpolation').value==='smooth';$(prefix+'PoseEndAt').closest('label').hidden=!pose||!smooth;
  $(prefix+'PoseAt').closest('label').firstChild.textContent=smooth?'بداية تغيير الوضعية عند % من مدة الفعل':'تغيير الوضعية عند % من مدة الفعل';
  $(prefix+'Sweep').closest('.two').hidden=!spatial||!['circle','arc'].includes($(prefix+'Shape').value);
  if(prefix==='newMove')$('startMovementDrawBtn').textContent=spatial&&$(prefix+'Shape').value!=='stationary'?'ابدأ رسم الانتقال':'إضافة الفعل في المكان';
  else $('redrawMovementBtn').hidden=!spatial||$(prefix+'Shape').value==='stationary';
 }
 const baseFill=fillChoreo;fillChoreo=function(prefix,p,o){baseFill(prefix,p,o);$(prefix+'ActionKind').value=actionKind(p);$(prefix+'PoseInterpolation').value=p.poseInterpolation||'step';$(prefix+'PoseEndAt').value=p.poseEndAt??100;bodyFields.get(prefix)._startBodyState=clone(p.startBodyState||(!p.id?o?.poseTransition:null)||null);bodyFields.get(prefix)._startPose=$(prefix+'StartPose').value;updateControls(prefix);};
 const baseRead=readChoreo;readChoreo=function(prefix){const data=baseRead(prefix),kind=$(prefix+'ActionKind').value;return{...data,actionKind:kind,poseInterpolation:$(prefix+'PoseInterpolation').value,poseEndAt:Math.max(data.poseAt,clamp(Number($(prefix+'PoseEndAt').value),0,100)),startBodyState:bodyFields.get(prefix)._startPose===data.startPose?clone(bodyFields.get(prefix)._startBodyState||null):null,facingMode:kind==='turn'?(data.facingMode==='target'?'target':'turn'):kind==='pose'||kind==='hold'?'fixed':data.facingMode};};
 function saveActionEdit(){const p=currentMovement();if(!p)return;const data=readChoreo('move'),shape=$('moveShape').value;stopSimulation();snap();Object.assign(p,data);if(['pose','turn','posture','hold','gesture'].includes(actionKind(p))){if(p.pathShape!=='stationary'){const actor=scene().objects.find(o=>o.id===p.actorObjectId);if(actor){p.x1=actor.x;p.y1=actor.y;}}p.pathShape='stationary';p.x2=p.x1;p.y2=p.y1;delete p.points;delete p.center;}else p.pathShape=shape;placeMovementActorAtEnd(p);mark('عُدل الفعل المسرحي');renderScene();}
 const begin=beginEnhancedMovementDraw;beginEnhancedMovementDraw=function(){
  const kind=$('newMoveActionKind').value,o=scene().objects.find(o=>o.id===$('newMoveActor').value);
  if(kind!=='compound'&&!o){alert('اختر شخصية لهذا الفعل.');return false;}
  if(['pose','turn','posture','hold','gesture'].includes(kind))$('newMoveShape').value='stationary';
  const target=scene().objects.find(x=>x.id===$('newMoveEndTarget').value);
  if(['pose','posture'].includes(kind)&&$('newMoveEndPose').value==='sitting'&&target&&!StageSupport.contains(target,o)){alert('تغيير الوضعية لا ينقل الشخصية إلى المقعد أو السطح. ضعها فوق المقعد أو السطح أو أضف انتقالًا قبله.');return false;}
  return begin();
 };
 window.TheatricalActions={updateControls,saveActionEdit};
 $('startMovementDrawBtn').onclick=beginEnhancedMovementDraw;
 const redraw=redrawEnhancedMovement;redrawEnhancedMovement=function(){const p=currentMovement();redraw();if(p&&pendingMovement)Object.assign(pendingMovement,{actionKind:p.actionKind,poseInterpolation:p.poseInterpolation,poseEndAt:p.poseEndAt,startBodyState:clone(p.startBodyState||null),lookTargetId:p.lookTargetId||null});};$('redrawMovementBtn').onclick=redrawEnhancedMovement;
})();
