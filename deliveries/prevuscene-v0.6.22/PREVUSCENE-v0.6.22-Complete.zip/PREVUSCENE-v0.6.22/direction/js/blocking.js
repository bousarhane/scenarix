(()=>{'use strict';
const $=id=>document.getElementById(id), api=window.MS2D;if(!api)return;
function ensure(){const st=api.getState();st.version=10.4;st.rehearsal=st.rehearsal||{mode:false};for(const sc of st.scenes){sc.tableaux=Array.isArray(sc.tableaux)?sc.tableaux:[];sc.versions=Array.isArray(sc.versions)?sc.versions:[];sc.journal=Array.isArray(sc.journal)?sc.journal:[];sc.cues=Array.isArray(sc.cues)?sc.cues:[];for(const o of sc.objects||[])if(o.type==='actor'){o.intention=o.intention||'';o.lookTarget=o.lookTarget||'';}}}
ensure();
function syncForm(){const o=api.selected();const show=o&&o.type==='actor';$('objIntention').disabled=!show;$('objLookTarget').disabled=!show;if(show){$('objIntention').value=o.intention||'';$('objLookTarget').value=o.lookTarget||'';}}
function bind(id,key){$(id).addEventListener('change',()=>{const o=api.selected();if(!o||o.type!=='actor')return;api.snap();o[key]=$(id).value;api.mark('عُدلت بيانات البلوكينغ');api.renderScene();});}
bind('objIntention','intention');bind('objLookTarget','lookTarget');
$('stageSvg').addEventListener('click',()=>setTimeout(syncForm,0));document.getElementById('objectList').addEventListener('click',()=>setTimeout(syncForm,0));
window.MS2DBlocking={ensure,syncForm};
})();
