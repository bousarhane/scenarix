# PREVUSCENE Direction 0.6.14

This directory contains the directing workspace and its approved assets.
Install, run and package the complete application from its root folder:

```sh
npm install
npm start
```

For browser use, open the root `index.html` or this directory's `index.html`.
See `../README-AR.txt` and `../VALIDATION-AR.txt` for the current behavior and verification.
The local npm commands and Electron entry point forward to the root; they do not build a second application.
