/* Await encrypted persistence before crossing file:// document boundaries. */
(function(){'use strict';
 window.addEventListener('load',()=>{
  const back=document.getElementById('prevusceneHubButton');if(!back)return;
  back.addEventListener('click',async ev=>{
   ev.preventDefault();const bridge=window.PREVUSCENEBridge;await bridge?.ready;
   const ctx=bridge?.readContext();if(!ctx?.projectId){window.location.href=back.href;return;}
   ev.preventDefault();
   try{
    window.LPF?.save();const data={...bridge.readContext(),source:'lighting'};
    if(data.directionState){data.directionState.lightingByScene=data.lightingByScene||{};data.directionState.currentSceneId=data.currentScene.id;}
    bridge.writeContext(data);const carrier=await bridge.flush();
    window.location.href='../direction/index.html#prevuscene='+encodeURIComponent(carrier);
   }catch(err){alert('تعذر حفظ الربط: '+err.message);}
  });
 });
})();
