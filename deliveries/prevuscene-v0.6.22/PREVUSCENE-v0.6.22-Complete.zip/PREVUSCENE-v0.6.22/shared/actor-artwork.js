(function(){'use strict';
const ACTOR_SPRITES=window.ActorVectorSources;
const actorVectorTemplates=new Map();
function actorSprite(gender,key,width,height){
 const cacheKey=gender+':'+key;
 if(!actorVectorTemplates.has(cacheKey)){
  const doc=new DOMParser().parseFromString(ACTOR_SPRITES[gender][key],'image/svg+xml');
  actorVectorTemplates.set(cacheKey,document.importNode(doc.documentElement,true));
 }
 const node=actorVectorTemplates.get(cacheKey).cloneNode(true);
 for(const [name,value] of Object.entries({width,height,x:-width/2,y:-height/2,preserveAspectRatio:'xMidYMid meet',overflow:'hidden',class:'actor-sprite','data-view':key,'data-gender':gender,'pointer-events':'none'}))node.setAttribute(name,value);
 return node;
}
function actorIllustration(parent,o,svgEl){
 if(o.actorVisual==='diagram'||!ACTOR_SPRITES[o.gender])return false;
 const pose=o.pose||'standing',facing=((Number(o.facing)||0)%360+360)%360;
 let view;if(pose==='standing')view=facing>=135&&facing<225?'back':facing>=45&&facing<315?'side':'front';
 else view={side:'side',sitting:'sitting',crouching:'crouching',lyingBack:'lying',lying:'lying'}[pose];
 if(!view)return false; // Keep truthful existing symbols for poses absent from the sheets.
 const picture=actorSprite(o.gender,view,o.w,o.h);if(view==='lying'){picture.setAttribute('width',Math.max(o.w,o.h)*1.2);picture.setAttribute('x',-Math.max(o.w,o.h)*.6);}
 const mirror=facing>=180&&(view==='side'||view==='sitting'||view==='crouching');
 if(mirror)picture.setAttribute('transform','scale(-1 1)');parent.append(picture);
 // Keep the reference point and direction distinct from the upright illustration.
 parent.append(svgEl('circle',{cx:0,cy:0,r:4,fill:o.color||'#168bc2',stroke:'#fff','stroke-width':1.5,class:'actor-position-dot'}));
 const direction=svgEl('g',{class:'actor-orientation',transform:`rotate(${-facing})`});parent.append(direction);
 const tip=Math.max(o.w,o.h)*.5+13;
 direction.append(svgEl('path',{d:`M0 0L0 ${tip}M-5 ${tip-8}L0 ${tip}L5 ${tip-8}`,fill:'none',stroke:o.color||'#168bc2','stroke-width':3,'stroke-linecap':'round','stroke-linejoin':'round',class:'illustrated-facing'}));
 const badge=svgEl('text',{x:0,y:o.h*.62+8,class:'actor-symbol illustrated-symbol'});badge.textContent=o.symbol||String(o.characterName||o.name||'ش').slice(0,2);parent.append(badge);
 const label=svgEl('text',{x:0,y:o.h*.62+24,class:'pose-label illustrated-pose-label'});label.textContent={standing:'واقف',side:'جانبي',sitting:'جالس',crouching:'قرفصاء',lyingBack:'مستلقي على الظهر',lying:'مستلقي'}[pose]||'';parent.append(label);
 return true;
}
window.ActorArtwork={sprite:actorSprite,draw:actorIllustration};
})();
