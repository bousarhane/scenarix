/* Shared context stays in memory; persistent carriers contain AES-GCM ciphertext only. */
(function(){
 'use strict';
 const KEY='PREVUSCENE_SHARED_CONTEXT_V2',LEGACY='PREVUSCENE_SHARED_CONTEXT_V1',PREFIX='PREVUSCENE_CONTEXT::',SESSION='prevuscene.bridge.key.v2';
 const clone=v=>v==null?null:JSON.parse(JSON.stringify(v));
 const encode=b=>{let s='';for(const n of new Uint8Array(b))s+=String.fromCharCode(n);return btoa(s);};
 const decode=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
 let current=null,envelope=null,key=null,keyMaterial=null,queue=Promise.resolve(),generation=0;
 function owner(){try{return JSON.parse(sessionStorage.getItem('prevuscene.auth.session.v1')||'null')?.id||null;}catch{return null;}}
 async function getKey(create){let auth;try{auth=JSON.parse(sessionStorage.getItem('prevuscene.auth.session.v1')||'null');}catch{}let raw=auth?.rawKey||sessionStorage.getItem(SESSION);if(!raw&&create){raw=encode(crypto.getRandomValues(new Uint8Array(32)));sessionStorage.setItem(SESSION,raw);}if(!raw)return null;if(key&&keyMaterial===raw)return key;key=await crypto.subtle.importKey('raw',decode(raw),'AES-GCM',false,['encrypt','decrypt']);keyMaterial=raw;return key;}
 function carrier(){return envelope?encode(new TextEncoder().encode(JSON.stringify(envelope))):null;}
 async function hydrate(){
  const startingGeneration=generation;
  try{
   localStorage.removeItem(LEGACY);
   const candidates=[localStorage.getItem(KEY)];let explicit=null;
   if(window.name.startsWith(PREFIX)){const named=window.name.slice(PREFIX.length);try{const value=JSON.parse(named);if(value.encrypted)candidates.push(named);else window.name='';}catch{window.name='';}}
   if(location.hash.startsWith('#prevuscene=')){try{explicit=new TextDecoder().decode(decode(decodeURIComponent(location.hash.slice(12))));candidates.push(explicit);}catch{}history.replaceState(null,'',location.pathname+location.search);}
   const secret=await getKey(false);if(!secret)return;
   const valid=[];
   for(const raw of candidates.filter(Boolean))try{const saved=JSON.parse(raw);if(saved.format!=='PREVUSCENE-BRIDGE'||!saved.encrypted)continue;
    const data=JSON.parse(new TextDecoder().decode(await crypto.subtle.decrypt({name:'AES-GCM',iv:decode(saved.iv)},secret,decode(saved.ciphertext))));
    if(data.ownerId&&data.ownerId!==owner())continue;valid.push({data,saved,explicit:raw===explicit});
   }catch{}
   if(startingGeneration!==generation)return;
   const requested=valid.find(v=>v.explicit)?.data.projectId;
   const latest=valid.filter(v=>!requested||v.data.projectId===requested).sort((a,b)=>(Date.parse(b.data.updatedAt)||0)-(Date.parse(a.data.updatedAt)||0))[0];
   current=latest?.data||null;envelope=latest?.saved||null;
  }catch{if(startingGeneration===generation){current=null;envelope=null;}}
 }

 const ready=hydrate();
 function writeContext(ctx){
  const data={...clone(ctx),schemaVersion:1,updatedAt:new Date().toISOString()};data.ownerId=owner()||data.ownerId||null;current=data;
  const snapshot=clone(data),version=generation;
  queue=queue.catch(()=>{}).then(async()=>{
   await ready;if(version!==generation)return;const secret=await getKey(true),iv=crypto.getRandomValues(new Uint8Array(12));
   const ciphertext=await crypto.subtle.encrypt({name:'AES-GCM',iv},secret,new TextEncoder().encode(JSON.stringify(snapshot)));
   if(version!==generation)return;envelope={format:'PREVUSCENE-BRIDGE',encrypted:true,version:2,iv:encode(iv),ciphertext:encode(ciphertext)};
   const raw=JSON.stringify(envelope);localStorage.setItem(KEY,raw);window.name=PREFIX+raw;
  });queue.catch(err=>console.error('تعذر حفظ سياق الربط المشفر',err.message));return clone(data);
 }
 function readContext(){if(current?.ownerId&&current.ownerId!==owner())return null;return clone(current);}
 function updateContext(patch){return writeContext({...current,...clone(patch)});}
 function clear(){generation++;current=null;envelope=null;key=null;keyMaterial=null;sessionStorage.removeItem(SESSION);localStorage.removeItem(KEY);localStorage.removeItem(LEGACY);if(window.name.startsWith(PREFIX))window.name='';}
 window.PREVUSCENEBridge={KEY,ready,writeContext,readContext,updateContext,clear,async reload(){await ready;await queue;if(!readContext())await hydrate();return readContext();},async flush(){await ready;await queue;return carrier();}};
})();
