(function(){'use strict';
 const copy=v=>JSON.parse(JSON.stringify(v)),bound=(v,a,b)=>Math.max(a,Math.min(b,v));
 const seconds=v=>Math.max(0,parseFloat(v)||0);
 const level=f=>bound(Number(f.intensity??f.footprintIntensity??65)||0,0,100);
 function blend(a,b,t){const ids=new Set([...a,...b].map(f=>f.id)),am=new Map(a.map(f=>[f.id,f])),bm=new Map(b.map(f=>[f.id,f]));return [...ids].map(id=>{const from=am.get(id),to=bm.get(id),f=copy(to||from);f.intensity=(from?level(from):0)*(1-t)+(to?level(to):0)*t;
   if(from&&to){for(const k of ['x','y','height3D','targetX','targetY','targetHeight','beamAngle'])if(Number.isFinite(from[k])&&Number.isFinite(to[k]))f[k]=from[k]+(to[k]-from[k])*t;
    if(/^#[\da-f]{6}$/i.test(from.color||'')&&/^#[\da-f]{6}$/i.test(to.color||''))f.color='#'+[1,3,5].map(i=>Math.round(parseInt(from.color.slice(i,i+2),16)*(1-t)+parseInt(to.color.slice(i,i+2),16)*t).toString(16).padStart(2,'0')).join('');}
   return f;});}
 function sample(plan={},time=0){plan=plan||{};let current=copy(plan.initialFixtures||plan.fixtures||[]);
  const cues=(plan.cues||[]).filter(c=>Array.isArray(c.fixtures)).map((c,i)=>({...c,index:i,start:seconds(c.start)})).sort((a,b)=>a.start-b.start||a.index-b.index);
  function at(c,from,t){const fade=seconds(c.fadeIn),p=fade?bound((t-c.start)/fade,0,1):1;let value=blend(from,c.fixtures,p);const hold=seconds(c.duration),out=seconds(c.fadeOut);if(hold&&t>c.start+fade+hold)value=blend(value,[],out?bound((t-c.start-fade-hold)/out,0,1):1);return value;}
  let active=null,from=current;
  for(const c of cues){if(c.start>time)break;if(active)current=at(active,from,c.start);from=current;active=c;}
  const sampled=active?at(active,from,time):current;
  for(const f of sampled)if(Object.hasOwn(plan.liveLevels||{},f.id))f.intensity=f.footprintIntensity=bound(Number(plan.liveLevels[f.id])||0,0,100);
  const master=bound(Number(plan.masterLevel??100)||0,0,100)/100;for(const f of sampled)f.intensity=f.footprintIntensity=level(f)*master;
  if(!Array.isArray(plan.fixtures))return sampled;
  const layout=new Map(plan.fixtures.map(f=>[f.id,f]));return sampled.filter(f=>layout.has(f.id)).map(f=>{const source=layout.get(f.id);for(const key of ['x','y','height3D','mounting','type','symbol','label','channel','universe','dmxStart'])if(Object.hasOwn(source,key))f[key]=source[key];return f;});
 }
 function duration(plan={}){return Math.max(0,...(plan?.cues||[]).filter(c=>c.fixtures).map(c=>seconds(c.start)+seconds(c.fadeIn)+seconds(c.duration)+seconds(c.fadeOut)));}
 function aim(f,resolve,stage){
  const h=Number.isFinite(Number(f.height3D))?Number(f.height3D):(f.mounting==='floor'?.12:Number(stage.height)||4);
  const target=f.targetMode==='element'&&f.targetObjectId?resolve(f.targetObjectId):null;
  if(target)return {x:target.x/100,y:target.y/100,z:(Number(target.elevation)||0)+(target.type==='actor'?(Number(target.bodyHeight)||1.72)*.65:(Number(target.height3D)||.6)/2),missing:false,height:h};
  const angle=(Number(f.rotation)||0)*Math.PI/180,down=f.directionMode==='douche';
  return {x:down?Number(f.x):Number.isFinite(f.targetX)?f.targetX:Number(f.x)+Math.sin(angle)*(Number(f.beamLength)||5),y:down?Number(f.y):Number.isFinite(f.targetY)?f.targetY:Number(f.y)+Math.cos(angle)*(Number(f.beamLength)||5),z:Number(f.targetHeight)||0,missing:f.targetMode==='element'&&!target,height:h};
 }
 window.LightTimeline={sample,duration,aim,level,seconds};
})();
