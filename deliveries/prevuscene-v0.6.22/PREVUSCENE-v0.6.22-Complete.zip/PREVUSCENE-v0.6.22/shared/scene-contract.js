(function(){'use strict';
 const copy=v=>JSON.parse(JSON.stringify(v));
 function projectContext(project,sceneId=project.currentSceneId){
  const s=project.scenes.find(s=>s.id===sceneId)||project.scenes[0];
  if(!s)throw new Error('المشروع بلا مشاهد');
  return {schemaVersion:1,source:'direction',projectId:project.projectId,directionState:copy(project),project:copy(project.project),stage:copy(project.stage),lightingByScene:copy(project.lightingByScene||{}),
   currentScene:{id:s.id,title:s.title,actTitle:project.acts.find(a=>a.id===s.actId)?.title||'',duration:s.duration,ambientLight:s.ambientLight},
   references:s.objects.filter(o=>!['light','note'].includes(o.type)).map(o=>({...copy(o),id:'dir_'+o.id,sourceId:o.id,sourceLayer:o.layer,sourceObject:copy(o),referenceLocked:true,importedFromDirection:true,kind:'scenic',referenceKind:o.type==='actor'?'actor':'scenography',label:o.characterName||o.name||o.type,x:o.x/100,y:o.y/100,width:(Number(o.w)||60)/100,height:(Number(o.h)||60)/100,rotation:o.type==='actor'?o.facing:o.rotation})),
   movementReferences:s.paths.map(p=>({...copy(p),id:'move_'+p.id,sourceId:p.id,x1:p.x1/100,y1:p.y1/100,x2:p.x2/100,y2:p.y2/100,curve:(p.curve||0)/100,points:p.points?.map(q=>({x:q.x/100,y:q.y/100})),center:p.center?{x:p.center.x/100,y:p.center.y/100}:null})),
   lightingTargets:s.objects.filter(o=>o.type==='light').map(o=>({id:'target_'+o.id,sourceId:o.id,label:o.name,x:o.x/100,y:o.y/100,radius:(o.w||100)/200,color:o.color,intensity:o.intensity}))};
 }
 window.SceneContract={projectContext,copy};
})();
